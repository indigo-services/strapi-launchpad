/**
 * HubSpot Analytics Tracking Code Build Number 1.4045
 * Copyright 2026 HubSpot, Inc.  http://www.hubspot.com
 */
var _hsq = _hsq || [];
_hsq.push(["setPortalId", 6893032]);
_hsq.push(["trackPageView"]);
try {
  const amplitudeUnifiedScript = document.createElement("script");
  (amplitudeUnifiedScript.src =
    "https://cdn.amplitude.com/script/b2903bdddb544d4b712bee3739f3cafd.js"),
    document.head.appendChild(amplitudeUnifiedScript),
    amplitudeUnifiedScript.addEventListener("load", () => {
      let e = document.createElement("script");
      (e.src = "https://cdn.amplitude.com/integrations/hubspot.js"),
        document.head.appendChild(e),
        e.addEventListener("load", () => {
          window.amplitude.add(window.sessionReplay.plugin({ sampleRate: 1 })),
            window.amplitude.init("b2903bdddb544d4b712bee3739f3cafd", {
              fetchRemoteConfig: !0,
              autocapture: true,
            });
        });
    });
} catch (e) {
  _hsq.push(["log", "customJsError", e]);
}
_hsq.push(["setLegacy", false]);
_hsq.push(["addHashedCookieDomain", "233546881"]);
_hsq.push(["addHashedCookieDomain", "32546273"]);
_hsq.push(["addHashedCookieDomain", "224894981"]);
_hsq.push(["addHashedCookieDomain", "20629287"]);
_hsq.push(["addHashedCookieDomain", "251652889"]);
_hsq.push(["enableAutomaticLinker", true]);
_hsq.push([
  "embedHubSpotScript",
  "https://js-na1.hs-scripts.com/6893032.js",
  "hs-script-loader",
]);
_hsq.push(["initEventVisualizerScript"]);
_hsq.push(["setTrackingDomain", "track.hubspot.com"]);
/** _anon_wrapper_ **/ (function () {
  /*! For license information please see hsa-prod.js.LICENSE.txt */
  (hstc = hstc || {}).JS_VERSION = 1.1;
  hstc.ANALYTICS_HOST = "track.hubspot.com";
  (hstc = hstc || {}).Math = {
    uuid: function () {
      if (window.navigator.userAgent.indexOf("googleweblight") > -1)
        return hstc.Math._mathRandomUuid();
      var t = window.crypto || window.msCrypto;
      return void 0 !== t &&
        void 0 !== t.getRandomValues &&
        void 0 !== window.Uint16Array
        ? hstc.Math._cryptoUuid()
        : hstc.Math._mathRandomUuid();
    },
    _mathRandomUuid: function () {
      var t = new Date().getTime();
      return "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function (e) {
        var n = (t + 16 * Math.random()) % 16 | 0;
        t = Math.floor(t / 16);
        return ("x" === e ? n : (3 & n) | 8).toString(16);
      });
    },
    _cryptoUuid: function () {
      var t = window.crypto || window.msCrypto,
        e = new Uint16Array(8);
      t.getRandomValues(e);
      var n = function (t) {
        for (var e = t.toString(16); e.length < 4; ) e = "0" + e;
        return e;
      };
      return (
        n(e[0]) +
        n(e[1]) +
        n(e[2]) +
        n(e[3]) +
        n(e[4]) +
        n(e[5]) +
        n(e[6]) +
        n(e[7])
      );
    },
  };
  Math.uuid =
    Math.uuid ||
    function () {
      hstc.utils.logError(new Error("Attempt to use Math.uuid()"));
      return hstc.Math.uuid();
    };
  (hstc = hstc || {}).debug = !1;
  hstc.log = function () {
    try {
      var t = new hstc.cookies.Cookie(),
        e = "hs_dbg",
        n = document.location.hash.indexOf("#hsdbg") > -1;
      if (hstc.debug || n || "1" === t.get(e)) {
        var i = window.console;
        i && "function" == typeof i.log && i.log.apply(i, arguments);
        if (document.location.hash.indexOf("#hsdbg") > -1) {
          hstc.__logs = hstc.__logs || [];
          hstc.__logs.push.apply(hstc.__logs, arguments);
        }
        t.set(e, 1);
      }
    } catch (t) {}
  };
  (hstc = hstc || {}).global = {};
  hstc.global.Context = function (t, e, n, i, r, o, s) {
    this.doc = t || document;
    this.nav = e || navigator;
    this.scr = n || screen;
    this.win = i || window;
    this.loc = r || this.win.location;
    this.top = o || top;
    this.parent = s || parent;
  };
  hstc.global.Context.prototype.getDocument = function () {
    return this.doc;
  };
  hstc.global.Context.prototype.getNavigator = function () {
    return this.nav;
  };
  hstc.global.Context.prototype.getScreen = function () {
    return this.scr;
  };
  hstc.global.Context.prototype.getWindow = function () {
    return this.win;
  };
  hstc.global.Context.prototype.getLocation = function () {
    return this.loc;
  };
  hstc.global.Context.prototype.getHostName = function () {
    try {
      return this.loc.hostname;
    } catch (t) {
      return this.doc.domain;
    }
  };
  hstc.global.Context.prototype.getPathName = function () {
    return this.loc.pathname;
  };
  hstc.global.Context.prototype.getTop = function () {
    return this.top;
  };
  hstc.global.Context.prototype.getParent = function () {
    return this.parent;
  };
  hstc.global.Context.prototype.getReferrer = function () {
    var t = "";
    try {
      t = this.top.document.referrer;
    } catch (e) {
      if (parent)
        try {
          t = this.parent.document.referrer;
        } catch (e) {
          t = "";
        }
    }
    "" === t && (t = this.doc.referrer);
    return t || this.win.__hsReferrer || "";
  };
  hstc.global.Context.prototype.getCharacterSet = function () {
    return this.doc.characterSet
      ? this.doc.characterSet
      : this.doc.charset
      ? this.doc.charset
      : "";
  };
  hstc.global.Context.prototype.getLanguage = function () {
    return this.nav.language
      ? this.nav.language
      : this.nav.browserLanguage
      ? this.nav.browserLanguage
      : "";
  };
  hstc.global.Context.prototype.getOrigin = function () {
    return this.loc.origin
      ? this.loc.origin
      : this.loc.protocol +
          "//" +
          this.getHostName() +
          (this.loc.port ? ":" + this.loc.port : "");
  };
  hstc.global.Context.prototype.getCurrentHref = function (t) {
    return t
      ? this.getOrigin().toLowerCase() + t.toLowerCase()
      : this.loc.href.toLowerCase();
  };
  (hstc = hstc || {}).utils = {};
  hstc.utils.tostr = Object.prototype.toString;
  hstc.utils.getNextWeekStart = function (t) {
    var e = t || new Date(),
      n = e.getDay(),
      i = e.getDate() + (0 == n ? 7 : 7 - n);
    return hstc.utils.clearTimePart(new Date(e.setDate(i)));
  };
  hstc.utils.getNextMonthStart = function (t) {
    for (var e = t || new Date(), n = e.getMonth(); n == e.getMonth(); ) {
      0;
      e.setDate(e.getDate() + 1);
    }
    return hstc.utils.clearTimePart(e);
  };
  hstc.utils.clearTimePart = function (t) {
    t.setHours(0);
    t.setMinutes(0);
    t.setSeconds(0);
    t.setMilliseconds(0);
    return t;
  };
  hstc.utils.truncateString = function (t, e) {
    return t ? (t.length > e ? t.substr(0, e) : t) : "";
  };
  hstc.utils.search2dArray = function (t, e, n, i) {
    for (var r = 0; r < t.length; r++) {
      var o = t[r];
      if (
        o &&
        hstc.utils.isArray(o) &&
        -1 !== hstc.utils.inArray(o[e - 1], n)
      ) {
        i(o, r);
        t.splice(r--, 1);
      }
    }
  };
  hstc.utils.removeSingleCallValueFromHsq = function (t, e) {
    for (var n = 0; n < t.length; n++) {
      var i = t[n];
      if (i && hstc.utils.isArray(i) && i[0] === e) {
        t.splice(n--, 1);
        return 2 == i.length ? i[1] : null;
      }
    }
  };
  hstc.utils.removeDomain = function (t) {
    return "/" + t.split("//")[1].split("/").slice(1).join("/");
  };
  hstc.utils.removeItem = function (t, e, n) {
    var i = t.slice((n || e) + 1 || this.length);
    this.length = e < 0 ? t.length + e : e;
    return t.push.apply(t, i);
  };
  hstc.utils.isArray = function (t) {
    return "[object Array]" === hstc.utils.tostr.call(t);
  };
  hstc.utils.inArray = function (t, e) {
    for (var n = 0, i = e.length; n < i; n++) if (e[n] === t) return n;
    return -1;
  };
  hstc.utils.extend = function () {
    var t,
      e = arguments[0] || {},
      n = 1,
      i = arguments.length,
      r = !1;
    if ("boolean" == typeof e) {
      r = e;
      e = arguments[1] || {};
      n = 2;
    }
    "object" == typeof e || hstc.utils.isFunction(e) || (e = {});
    if (i == n) {
      e = this;
      --n;
    }
    for (; n < i; n++)
      if (null != (t = arguments[n]))
        for (var o in t) {
          var s = e[o],
            a = t[o];
          e !== a &&
            (r && a && "object" == typeof a && !a.nodeType
              ? (e[o] = hstc.utils.extend(
                  r,
                  s || (null !== a.length ? [] : {}),
                  a
                ))
              : void 0 !== a && (e[o] = a));
        }
    return e;
  };
  hstc.utils.each = function (t, e) {
    var n,
      i = 0,
      r = t.length;
    if (void 0 === r) {
      for (n in t) if (!1 === e.call(t[n], n, t[n])) break;
    } else for (var o = t[0]; i < r && !1 !== e.call(o, i, o); o = t[++i]);
    return t;
  };
  hstc.utils.isDefined = function (t) {
    return void 0 !== t;
  };
  hstc.utils.addEventListener = function (t, e, n, i) {
    if (t.addEventListener) {
      t.addEventListener(e, n, i);
      return !0;
    }
    if (t.attachEvent) return t.attachEvent("on" + e, n);
    t["on" + e] = n;
  };
  hstc.utils.removeEventListener = function (t, e, n, i) {
    if (t.removeEventListener) {
      t.removeEventListener(e, n, i);
      return !0;
    }
    if (t.detachEvent) return t.detachEvent("on" + e, n);
    t.removeAttribute("on" + e);
  };
  hstc.utils.preventDefault = function (t) {
    t.preventDefault ? t.preventDefault() : (t.returnValue = !1);
  };
  hstc.utils.loadImage = function (t, e, n) {
    var i = new Date(),
      r = new Image(1, 1);
    expireDateTime = i.getTime() + e;
    r.onload = function () {
      n && n();
    };
    r.src = t;
  };
  hstc.utils.isEmpty = function (t) {
    return null == t || "-" == t || "" == t;
  };
  hstc.utils.isEmptyObject = function (t) {
    for (var e in t) return !1;
    return !0;
  };
  hstc.utils.safeString = function (t) {
    return hstc.utils.isEmpty(t) ? "" : t;
  };
  hstc.utils.makeLowerCase = function (t) {
    return hstc.utils.safeString(t).toLowerCase();
  };
  hstc.utils.encodeParam = function (t, e) {
    var n = encodeURIComponent;
    return n instanceof Function ? (e ? encodeURI(t) : n(t)) : escape(t);
  };
  hstc.utils.decodeParam = function (t, e) {
    var n,
      i = decodeURIComponent;
    t = t.split("+").join(" ");
    if (i instanceof Function)
      try {
        n = e ? decodeURI(t) : i(t);
      } catch (e) {
        n = unescape(t);
      }
    else n = unescape(t);
    return n;
  };
  hstc.utils.isFunction = function (t) {
    return "[object Function]" === hstc.utils.tostr.call(t);
  };
  hstc.utils.utcnow = function () {
    return new Date().getTime();
  };
  hstc.utils.hashString = function (t) {
    for (var e = 0, n = t.length - 1; n >= 0; n--) {
      var i = t.charCodeAt(n);
      e =
        0 !== (i = 266338304 & (e = ((e << 6) & 268435455) + i + (i << 14)))
          ? e ^ (i >> 21)
          : e;
    }
    return e;
  };
  hstc.utils.extractDomain = function (t) {
    var e = t.split(".");
    e.length > 2 && (e = e.slice(1));
    return "." + e.join(".");
  };
  hstc.utils.createElement = function (t) {
    var e = document.createDocumentFragment(),
      n = document.createElement("div");
    n.innerHTML = t;
    for (; n.firstChild; ) e.appendChild(n.firstChild);
    return e;
  };
  sanitizeKey = function (t) {
    return t &&
      ["__proto__", "constructor", "prototype"].indexOf(t.toLowerCase()) > -1
      ? t.toUpperCase()
      : t;
  };
  hstc.utils.deparam = function (t, e) {
    var n = Object.create(null),
      i = { true: !0, false: !1, null: null };
    t = hstc.utils.trim(hstc.utils.safeString(t));
    (hstc.utils.startsWith(t, "?") || hstc.utils.startsWith(t, "#")) &&
      (t = t.slice(1));
    hstc.utils.each(t.split("+").join(" ").split("&"), function (t, r) {
      var o,
        s = r.split("="),
        a = hstc.utils.decodeParam(s[0]),
        c = n,
        u = 0,
        l = a.split("]["),
        h = l.length - 1;
      if (/\[/.test(l[0]) && /\]$/.test(l[h])) {
        l[h] = l[h].replace(/\]$/, "");
        h = (l = l.shift().split("[").concat(l)).length - 1;
      } else h = 0;
      if (2 === s.length) {
        o = hstc.utils.decodeParam(s[1]);
        e &&
          (o =
            o && !isNaN(o)
              ? +o
              : "undefined" === o
              ? void 0
              : void 0 !== i[o]
              ? i[o]
              : o);
        if (h)
          for (; u <= h; u++) {
            a = "" === l[u] ? c.length : l[u];
            c = c[(a = sanitizeKey(a))] =
              u < h ? c[a] || (l[u + 1] && isNaN(l[u + 1]) ? {} : []) : o;
          }
        else {
          a = sanitizeKey(a);
          hstc.utils.isArray(n[a])
            ? n[a].push(o)
            : void 0 !== n[a]
            ? (n[a] = [n[a], o])
            : (n[a] = o);
        }
      } else a && (n[a] = e ? void 0 : "");
    });
    return n;
  };
  hstc.utils.param = function (t, e) {
    var n = [];
    e = e || "&";
    function i(t, e) {
      n[n.length] = hstc.utils.encodeParam(t) + "=" + hstc.utils.encodeParam(e);
    }
    for (var r in t)
      hstc.utils.isArray(t[r])
        ? hstc.utils.each(t[r], function () {
            i(r, this);
          })
        : i(r, hstc.utils.isFunction(t[r]) ? t[r]() : t[r]);
    return n.join(e).replace(/%20/g, "+");
  };
  hstc.utils.updateQueryStringParameter = function (t, e, n) {
    var i = new RegExp("([?|&])" + e + "=.*?(&|#|$)(.*)", "gi");
    if (i.test(t))
      return n
        ? t.replace(i, "$1" + e + "=" + n + "$2$3")
        : t.replace(i, "$1$3").replace(/(&|\?)$/, "");
    if (n) {
      var r = t.indexOf("#"),
        o = t.indexOf("?"),
        s = -1 !== o && (-1 === r || o < r) ? "&" : "?",
        a = t.split("#");
      t = a[0] + s + e + "=" + n;
      a[1] && (t += "#" + a[1]);
      return t;
    }
    return t;
  };
  hstc.utils.trim = function (t) {
    return (t || "").replace(/^\s+|\s+$/g, "");
  };
  hstc.utils.startsWith = function (t, e) {
    return null != e && t.substr(0, e.length) == e;
  };
  hstc.utils.endsWith = function (t, e) {
    var n = t.length - e.length;
    return n >= 0 && t.lastIndexOf(e) === n;
  };
  hstc.utils.mergeObject = function (t, e) {
    t = t || {};
    if (!e) return e;
    for (var n in e) t[n] = e[n];
    return t;
  };
  hstc.utils.hasClass = function (t, e) {
    if (t && t.className)
      return hstc.utils.inArray(e, t.className.split(" ")) > -1;
  };
  hstc.utils.stripNumericBrackets = function (t) {
    return (t || "").replace(/(^.+?)\[(.+?)\]/, "$1_$2");
  };
  hstc.utils.parseCurrency = function (t, e) {
    if ("number" == typeof t) return t;
    var n = t.match(/([^\d]*)([\d\.,]+)([^\d\.,]*)/);
    if (n) {
      var i,
        r = n[2],
        o = r.split("."),
        s = r.split(",");
      i =
        o.length > 2 ||
        (2 == o.length &&
          o[1].length > 2 &&
          (0 === s.length || o[0].length < s[0].length)) ||
        (2 == s.length && 2 == s[1].length)
          ? s
          : o;
      var a = (decimalPart = 0);
      if (i.length > 1) {
        decimalPart = i.pop();
        a = i.join("");
      } else a = i.join("");
      a = a.replace(/[\.,]/g, "");
      var c = parseInt(a);
      decimalPart &&
        (c += parseFloat(decimalPart) / Math.pow(10, decimalPart.length));
      return c;
    }
    return null;
  };
  hstc.utils.logError = function (t, e) {
    e = e || "";
    var n = {
      w: hstc.utils.utcnow(),
      m: t.message || t.toString ? t.toString() : "-",
      j: hstc.JS_VERSION,
    };
    t.name && (n.n = t.name);
    t.fileName && (n.f = t.fileName);
    t.lineNumber && (n.l = t.lineNumber);
    try {
      n.x = t.stack || t.stacktrace || "";
    } catch (t) {}
    hstc.log("Encountered a JS error");
    hstc.log(n);
    var i = "https://" + (e || hstc.ANALYTICS_HOST) + "/__pto.gif?";
    hstc.utils.loadImage(i + hstc.utils.param(n));
  };
  hstc.utils.objectsAreEqual = function (t, e) {
    return eq(t, e, []);
  };
  hstc.utils.eq = function (t, e, n) {
    if (t === e) return 0 !== t || 1 / t == 1 / e;
    if (null == t || null == e) return t === e;
    t._chain && (t = t._wrapped);
    e._chain && (e = e._wrapped);
    if (t.isEqual && _.isFunction(t.isEqual)) return t.isEqual(e);
    if (e.isEqual && _.isFunction(e.isEqual)) return e.isEqual(t);
    var i = toString.call(t);
    if (i != toString.call(e)) return !1;
    switch (i) {
      case "[object String]":
        return t == String(e);
      case "[object Number]":
        return t != +t ? e != +e : 0 == t ? 1 / t == 1 / e : t == +e;
      case "[object Date]":
      case "[object Boolean]":
        return +t == +e;
      case "[object RegExp]":
        return (
          t.source == e.source &&
          t.global == e.global &&
          t.multiline == e.multiline &&
          t.ignoreCase == e.ignoreCase
        );
    }
    if ("object" != typeof t || "object" != typeof e) return !1;
    for (var r = n.length; r--; ) if (n[r] == t) return !0;
    n.push(t);
    var o = 0,
      s = !0;
    if ("[object Array]" == i) {
      if ((s = (o = t.length) == e.length))
        for (; o-- && (s = o in t == o in e && eq(t[o], e[o], n)); );
    } else {
      if (
        "constructor" in t != "constructor" in e ||
        t.constructor != e.constructor
      )
        return !1;
      for (var a in t)
        if (_.has(t, a)) {
          o++;
          if (!(s = _.has(e, a) && eq(t[a], e[a], n))) break;
        }
      if (s) {
        for (a in e) if (_.has(e, a) && !o--) break;
        s = !o;
      }
    }
    n.pop();
    return s;
  };
  hstc.utils.checkHashedDomain = function (t, e, n = !0) {
    return 0 == t.length || -1 == t.substring(1).indexOf(".")
      ? ""
      : 0 != t.indexOf(".") &&
        hstc.utils.inArray("" + this.hashString("." + t), e) > -1
      ? "." + t
      : hstc.utils.inArray("" + this.hashString(t), e) > -1
      ? t
      : this.checkHashedDomain(
          t.substring(t.substring(1).indexOf(".") + (n ? 1 : 2)),
          e
        );
  };
  hstc.utils.isValidHubUrl = function (t) {
    return /^https:\/\/(app|local)(-[a-z]{2}[0-9]{1})?\.hubspot(qa)?\.com\/?$/.test(
      t
    );
  };
  hstc.utils.resolveInitialUrl = function (t) {
    var e = window.location.origin,
      n = "__hsInitialUrl",
      i =
        window[n] &&
        "string" == typeof window[n] &&
        hstc.utils.parseURL(window[n], e),
      r = t && hstc.utils.parseURL(t, e);
    if (i && i.search && r) {
      var o = i.searchParams,
        s = r.searchParams;
      o.forEach((t, e) => {
        s.has(e) || s.set(e, t);
      });
      t = /^https?:\/\//.test(t)
        ? r.toString()
        : r.pathname + r.search + (r.hash || i.hash || "");
    }
    return t;
  };
  hstc.utils.getParentNodeModuleId = function (t) {
    for (var e = ""; t && !e.includes("hs_cos_wrapper_"); )
      e = (t = t.parentElement) && t.id ? t.id : "";
    return e && e.replace(/^hs_cos_wrapper_|_$/g, "");
  };
  hstc.utils.parseURL = function (t, e) {
    try {
      return new URL(t, e);
    } catch (t) {
      hstc.utils.logError(t);
      return null;
    }
  };
  (hstc = hstc || {}).cookies = {};
  hstc.cookies.Cookie = function (t) {
    this.context = t || new hstc.global.Context();
    this.currentDomain = null;
    this.domains = [];
    this.hashedDomains = [];
    this.secureCookie = !1;
  };
  hstc.cookies.Cookie.prototype.addDomain = function (t) {
    this.addHashedDomain(t);
  };
  hstc.cookies.Cookie.prototype.addHashedDomain = function (t) {
    -1 != t.indexOf(".") && (t = "" + hstc.utils.hashString(t));
    var e = hstc.utils.checkHashedDomain(
      this.context.getHostName(),
      t.split(),
      !1
    );
    e.length > 0 &&
      (!this.currentDomain || e.length < this.currentDomain.length) &&
      (this.currentDomain = e);
    this.hashedDomains.push(t);
  };
  hstc.cookies.Cookie.prototype.getDomains = function () {
    return this.domains;
  };
  hstc.cookies.Cookie.prototype.getHashedDomains = function () {
    return this.hashedDomains;
  };
  hstc.cookies.Cookie.prototype.set = function (t, e, n) {
    var i,
      r,
      o = !1;
    (n = n || {}).minsToExpire
      ? (i = new Date()).setTime(i.getTime() + 1e3 * n.minsToExpire * 60)
      : n.daysToExpire
      ? (i = new Date()).setTime(
          i.getTime() + 1e3 * n.daysToExpire * 60 * 60 * 24
        )
      : n.expiryDate && n.expiryDate.toGMTString
      ? (i = n.expiryDate)
      : n.expiryDate && (i = new Date(n.expiryDate));
    if (void 0 !== i) {
      r = i.toGMTString();
      o = !0;
    }
    this._set(t, n.alreadyEncoded ? e : hstc.utils.encodeParam(e, !0), {
      expires: o ? ";expires=" + r : "",
      expiresTime: o ? i : null,
      path: ";path=" + (n.path ? n.path : "/"),
      domain:
        !this.cookiesToSubdomain && this.currentDomain
          ? ";domain=" + this.currentDomain
          : "",
      secure: this.secureCookie || n.secure ? ";secure" : "",
      sameSite: ";SameSite=Lax",
    });
  };
  hstc.cookies.Cookie.prototype._set = function (t, e, n) {
    var i = n.expires + n.path + n.domain + n.sameSite + n.secure;
    this._writeCookie(t + "=" + e + i);
    var r = this.get(t);
    if (
      (!r || r != e) &&
      "" != n.domain &&
      (!n.expiresTime || n.expiresTime - new Date() > 0)
    ) {
      i = n.expires + n.path + n.sameSite + n.secure;
      this._writeCookie(t + "=" + e + i);
    }
  };
  hstc.cookies.Cookie.prototype._writeCookie = function (t) {
    this.context.getDocument().cookie = t;
  };
  hstc.cookies.Cookie.prototype.get = function (t) {
    var e = new RegExp("(^|;)[ ]*" + t + "=([^;]*)").exec(
      this.context.getDocument().cookie
    );
    return e ? hstc.utils.decodeParam(e[2], !0) : "";
  };
  hstc.cookies.Cookie.prototype.has = function () {
    return (
      hstc.utils.isDefined(this.context.getNavigator().cookieEnabled) ||
      ("cookie" in this.context.getDocument() &&
        this.context.getDocument().cookie.length > 0)
    );
  };
  hstc.cookies.Cookie.prototype.remove = function (t) {
    this.set(t, "", { expiryDate: "1970-01-01T00:00:01-00:00" });
  };
  hstc.cookies.Cookie.prototype.setCookiesToSubdomain = function (t) {
    this.cookiesToSubdomain = t;
  };
  hstc.cookies.Cookie.prototype.getCookiesToSubdomain = function () {
    return this.cookiesToSubdomain;
  };
  hstc.cookies.Cookie.prototype.setSecureCookie = function () {
    this.secureCookie = !0;
  };
  (hstc = hstc || {}).identities = {};
  hstc.identities.Identity = function (t) {
    this.raw = t;
  };
  hstc.identities.Identity.prototype.get = function () {
    return this.raw;
  };
  hstc.identities.Identity.prototype.equals = function (t) {
    return hstc.utils.objectsAreEqual(this, t);
  };
  hstc.identities.Identity.prototype.merge = function (t) {
    this.raw = hstc.utils.mergeObject(this.raw, t);
  };
  (hstc = hstc || {}).browser = function (t) {
    var e = (t = t || new hstc.global.Context()).getNavigator(),
      n = e.userAgent.toLowerCase(),
      i = {
        init: function () {
          this.browser = this.searchString(this.dataBrowser) || "";
          this.version =
            this.searchVersion(e.userAgent) ||
            this.searchVersion(e.appVersion) ||
            "";
          this.OS = this.searchString(this.dataOS) || "";
        },
        searchString: function (t) {
          for (var e = 0; e < t.length; e++) {
            var n = t[e].string,
              i = t[e].prop;
            this.versionSearchString = t[e].versionSearch || t[e].identity;
            if (n) {
              if (-1 !== n.indexOf(t[e].subString)) return t[e].identity;
              if (i) return t[e].identity;
            }
          }
        },
        searchVersion: function (t) {
          var e = t.indexOf(this.versionSearchString);
          if (-1 !== e)
            return parseFloat(
              t.substring(e + this.versionSearchString.length + 1)
            );
        },
        dataBrowser: [
          { string: e.userAgent, subString: "Chrome", identity: "Chrome" },
          {
            string: e.userAgent,
            subString: "OmniWeb",
            versionSearch: "OmniWeb/",
            identity: "OmniWeb",
          },
          {
            string: e.vendor,
            subString: "Apple",
            identity: "Safari",
            versionSearch: "Version",
          },
          { prop: window.opera, identity: "Opera" },
          { string: e.vendor, subString: "iCab", identity: "iCab" },
          { string: e.vendor, subString: "KDE", identity: "Konqueror" },
          { string: e.userAgent, subString: "Firefox", identity: "Firefox" },
          { string: e.vendor, subString: "Camino", identity: "Camino" },
          { string: e.userAgent, subString: "Netscape", identity: "Netscape" },
          {
            string: e.userAgent,
            subString: "MSIE",
            identity: "Explorer",
            versionSearch: "MSIE",
          },
          {
            string: e.userAgent,
            subString: "Gecko",
            identity: "Mozilla",
            versionSearch: "rv",
          },
          {
            string: e.userAgent,
            subString: "Mozilla",
            identity: "Netscape",
            versionSearch: "Mozilla",
          },
        ],
        dataOS: [
          { string: e.platform, subString: "Win", identity: "Windows" },
          { string: e.platform, subString: "Mac", identity: "Mac" },
          { string: e.userAgent, subString: "iPhone", identity: "iPhone/iPod" },
          { string: e.platform, subString: "Linux", identity: "Linux" },
        ],
      };
    i.init();
    this.version = (n.match(/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/) || [0, "0"])[1];
    this.os = i.OS;
    this.brand = i.browser;
    this.webkit = /webkit/.test(n);
    this.opera = /opera/.test(n);
    this.msie = /msie/.test(n) && !/opera/.test(n);
    this.mozilla = /mozilla/.test(n) && !/(compatible|webkit)/.test(n);
  };
  (hstc = hstc || {}).autotrack = hstc.autotrack || {};
  var CLICKABLE_NODES = ["A", "BUTTON", "SUMMARY"],
    CLICKABLE_ROLES = ["button", "link", "menuitem", "option", "tab"],
    QUERY_SELECTORS = [
      "input[type=submit],input[type=reset],input[type=button],input[type=image]",
      CLICKABLE_NODES.join(","),
      ["[role=", CLICKABLE_ROLES.join("],[role="), "]"].join(""),
    ].join(","),
    NAV_CONTAINERS = ["nav", "header", "footer", "aside"],
    NAV_ROLES = ["navigation", "menubar", "menu"],
    NAV_TERMS = ["navbar", "sidebar"].concat(NAV_CONTAINERS, NAV_ROLES),
    TRACKED_ELEMENTS = new Set(),
    VISIBILITY_STATE = new WeakMap(),
    VISIBILITY_OPTIONS = {
      opacityProperty: !0,
      visibilityProperty: !0,
      contentVisibilityAuto: !0,
    };
  hstc.autotrack.initClickListeners = function (t) {
    function e() {
      hstc.autotrack.addClickListeners_(document.body, t);
      hstc.autotrack.addMutationObserver_(document.body, t);
      document.body.querySelectorAll(QUERY_SELECTORS).forEach(function (t) {
        "function" == typeof t.checkVisibility &&
          VISIBILITY_STATE.set(t, t.checkVisibility(VISIBILITY_OPTIONS));
      });
    }
    "loading" !== document.readyState
      ? e()
      : document.addEventListener("DOMContentLoaded", e);
  };
  hstc.autotrack.addClickListeners_ = function (t, e) {
    var n = window.matchMedia("(pointer: coarse)").matches,
      i = n ? "touchstart" : "mousedown";
    function r(t) {
      var o = t.currentTarget || t.target,
        s = hstc.autotrack.getSelector_(o);
      if (s && !TRACKED_ELEMENTS.has(s)) {
        TRACKED_ELEMENTS.add(s);
        e({
          ...hstc.autotrack.getElementProperties_(o),
          ...hstc.autotrack.getWindowProperties_(),
          ...hstc.autotrack.getEventProperties_(t),
          hs_touch_screen: n,
          hs_selector: s,
          hs_is_navigation: hstc.autotrack.isNavElement_(o),
        });
        o.removeEventListener(i, r);
      }
    }
    const o = !0;
    t.querySelectorAll(QUERY_SELECTORS).forEach(function (t) {
      t.addEventListener(i, r, o);
    });
    t.matches && t.matches(QUERY_SELECTORS) && t.addEventListener(i, r, o);
  };
  hstc.autotrack.addMutationObserver_ = function (t, e) {
    new MutationObserver(function (t) {
      for (const n of t)
        "childList" === n.type &&
          n.addedNodes.length > 0 &&
          n.addedNodes.forEach(function (t) {
            t.nodeType === Node.ELEMENT_NODE &&
              hstc.autotrack.addClickListeners_(t, e);
          });
    }).observe(t, { childList: !0, subtree: !0 });
  };
  hstc.autotrack.getWindowProperties_ = function () {
    return {
      hs_viewport_width: window.innerWidth,
      hs_viewport_height: window.innerHeight,
      hs_document_width: document.body.clientWidth,
      hs_document_height: document.body.clientHeight,
      hs_screen_width: window.screen.width,
      hs_screen_height: window.screen.height,
      hs_scroll_x_coordinate: window.scrollX,
      hs_scroll_y_coordinate: window.scrollY,
    };
  };
  hstc.autotrack.getElementText_ = function (t) {
    var e = t.dataset,
      n = (
        (t.innerText && t.innerText.trim()) ||
        t.alt ||
        t.title ||
        t.placeholder ||
        t.ariaPlaceholder ||
        t.ariaLabel ||
        t.name ||
        t.type ||
        (e && (e.label || e.title || e.text)) ||
        ("title" === t.nodeName && t.textContent) ||
        t.classList.value ||
        ""
      ).trim();
    if (!n && t.firstElementChild)
      return hstc.autotrack.getElementText_(t.firstElementChild);
    n || "IMG" !== t.tagName || (n = t.src.split(/[?#]/)[0].split("/").pop());
    return n.slice(0, 100);
  };
  hstc.autotrack.getElementProperties_ = function (t) {
    return {
      hs_tag_name: t.tagName,
      hs_element_id: t.id,
      hs_element_class: t.classList.value,
      hs_element_text: hstc.autotrack.getElementText_(t),
      hs_element_visible: VISIBILITY_STATE.get(t),
      hs_link_href: t.href || t.src,
      hs_parent_module_id: hstc.utils.getParentNodeModuleId(t),
    };
  };
  hstc.autotrack.getEventProperties_ = function (t) {
    var e = t.touches && t.touches[0];
    return {
      hs_mouse_x_coordinate: e?.clientX || t.clientX,
      hs_mouse_y_coordinate: e?.clientY || t.clientY,
      hs_offset_x: t.offsetX || 0,
      hs_offset_y: t.offsetY || 0,
      hs_key_ctrl: t.ctrlKey,
      hs_key_shift: t.shiftKey,
      hs_key_alt: t.altKey,
      hs_key_meta: t.metaKey,
    };
  };
  hstc.autotrack.getSelector_ = function (t) {
    return "function" == typeof hstc.unsizzle && hstc.unsizzle(t);
  };
  hstc.autotrack.isNavElement_ = function (t) {
    if (t && t.closest) {
      if (t.closest(NAV_CONTAINERS.join(", "))) return !0;
      if (
        t.closest(
          NAV_ROLES.map(function (t) {
            return `[role="${t}"]`;
          }).join(", ")
        )
      )
        return !0;
      if (
        NAV_TERMS.some(function (e) {
          return t.closest(`[class*="${e}"],[id*="${e}"]`);
        })
      )
        return !0;
    }
    return !1;
  };
  (hstc = hstc || {}).tracking = hstc.tracking || {};
  var hstc,
    thisScriptUrl =
      document && document.currentScript && document.currentScript.src;
  hstc.tracking.Tracker = function (t, e) {
    this.context = t || new hstc.global.Context();
    this.cookie = e || new hstc.cookies.Cookie(this.context);
    this.now = hstc.utils.utcnow();
    this.session = null;
    this.utk = null;
    this.managedCookies = !1;
    this.trackingEnabled = !0;
    this.limitTrackingToCookieDomains = !1;
    this.crossDomainLinkingEnabled = !1;
    this.hasResetVisitor = !1;
    this.privacyConsent = null;
    this.privacySettings = null;
    this.clickSelectors = [];
    this.userTokenListeners = [];
    this.cookieListeners = [];
    this.pageIdListeners = [];
    this.contentMetadataListeners = [];
    this.contentTypeListeners = [];
    this.trackingDomain = null;
    this.trackingGate = [];
    this.currentScriptUrl = thisScriptUrl;
    this.eventBuilderMessageHandler = null;
  };
  hstc.tracking.Tracker.DO_NOT_TRACK = "__hs_do_not_track";
  hstc.tracking.Tracker.DO_NOT_TRACK_EXPIRATION = 180;
  hstc.tracking.Tracker.prototype._initialize = function () {
    this._handlePrivacyPolicy();
    this._handleMigrations();
    this._handleCtaReplacedInlineHtml();
    this._setRelCanonicalUrl();
    this._initPageDiagnostics();
    this._initAutoCapture();
  };
  hstc.tracking.Tracker.prototype._initAutoCapture = function () {
    var t = this.context.getWindow()._hsq,
      e = function (t) {
        return Array.isArray(t) && "trackPageView" === t[0];
      };
    if (t && t.some(e)) {
      var n = this;
      hstc.autotrack.initClickListeners(function (t) {
        n.trackClickEvent({ properties: t });
      });
    }
  };
  hstc.tracking.Tracker.prototype._getHspQueue = function () {
    return (this.context.getWindow()._hsp =
      this.context.getWindow()._hsp || []);
  };
  hstc.tracking.Tracker.prototype.setTrackingDomain = function (t) {
    this.trackingDomain = t;
  };
  hstc.tracking.Tracker.prototype.setTrackingGate = function (t) {
    this.trackingGate.push(t);
  };
  hstc.tracking.Tracker.prototype.hasTrackingGate = function (t) {
    return -1 !== hstc.utils.inArray(t, this.trackingGate);
  };
  hstc.tracking.Tracker.prototype.setPortalId = function (t) {
    this.portalId = t;
    this._manageCookies();
  };
  hstc.tracking.Tracker.prototype.setCanonicalUrl = function (t) {
    this.canonicalUrl = t;
  };
  hstc.tracking.Tracker.prototype.setPath = function (t) {
    "" == t && (t = "/");
    this.path && t !== this.path && (this.referrerPath = this.path);
    this.path = t;
    this.refreshPageHandlers();
    this.crossDomainLinkingEnabled && this.enableAutomaticLinker();
  };
  hstc.tracking.Tracker.prototype.refreshPageHandlers = function () {
    for (var t = 0; t < this.clickSelectors.length; t++)
      this._resetClickHandler(this.clickSelectors[t]);
  };
  hstc.tracking.Tracker.prototype.setContentType = function (t) {
    this.contentType = t;
    for (var e = 0; e < this.contentTypeListeners.length; e++)
      this.contentTypeListeners[e](this.contentType);
  };
  hstc.tracking.Tracker.prototype.setPageId = function (t) {
    this.pageId = t;
    for (var e = 0; e < this.pageIdListeners.length; e++)
      this.pageIdListeners[e](this.pageId);
  };
  hstc.tracking.Tracker.prototype.setContentMetadata = function (t) {
    this.contentMetadata = t;
    for (var e = 0; e < this.contentMetadataListeners.length; e++)
      this.contentMetadataListeners[e](this.contentMetadata);
  };
  hstc.tracking.Tracker.prototype.setTargetedContentMetadata = function (t) {
    this.targetedContentMetadata = t;
  };
  hstc.tracking.Tracker.prototype.setDebugMode = function (t) {
    hstc.debug = t;
  };
  hstc.tracking.Tracker.prototype.setCookiesToSubdomain = function (t) {
    this.cookie.setCookiesToSubdomain(t);
  };
  hstc.tracking.Tracker.prototype.setLimitTrackingToCookieDomains = function (
    t
  ) {
    this.limitTrackingToCookieDomains = t;
  };
  hstc.tracking.Tracker.prototype.setTrackingEnabled = function (t) {
    this.trackingEnabled = !!t;
  };
  hstc.tracking.Tracker.prototype.addUserTokenListener = function (t) {
    this.utk && this.utk.visitor && t(this.utk.visitor);
    this.userTokenListeners.push(t);
  };
  hstc.tracking.Tracker.prototype.addCookieListener = function (t) {
    var e = null,
      n = null;
    this.utk && this.utk.visitor && (e = this.utk.get());
    this.session && (n = this.session.get());
    (e || n) && t(e, n, this._getFingerprint());
    this.cookieListeners.push(t);
  };
  hstc.tracking.Tracker.prototype.addIdentityListener =
    hstc.tracking.Tracker.prototype.addCookieListener;
  hstc.tracking.Tracker.prototype.addPageIdListener = function (t) {
    this.pageId && t(this.pageId);
    this.pageIdListeners.push(t);
  };
  hstc.tracking.Tracker.prototype.addContentMetadataListener = function (t) {
    this.contentMetadata && t(this.contentMetadata);
    this.contentMetadataListeners.push(t);
  };
  hstc.tracking.Tracker.prototype.addContentTypeListener = function (t) {
    this.contentType && t(this.contentType);
    this.contentTypeListeners.push(t);
  };
  hstc.tracking.Tracker.prototype.addPrivacyConsentListener = function (t) {
    this._enqueuePrivacyCall("addPrivacyConsentListener", t);
  };
  hstc.tracking.Tracker.prototype.addHashedCookieDomain = function (t) {
    this.cookie.addHashedDomain(t);
  };
  hstc.tracking.Tracker.prototype.enableSecureCookie = function () {
    this.cookie.setSecureCookie();
  };
  hstc.tracking.Tracker.prototype.enableAutomaticLinker = function () {
    var t = this;
    t.crossDomainLinkingEnabled = !0;
    t._manageCookies();
    if (
      this.cookie.getHashedDomains() &&
      !(this.cookie.getHashedDomains().length <= 0)
    ) {
      var e = this.cookie.getHashedDomains(),
        n = this.cookie.currentDomain;
      t._enqueueConsentListener(function () {
        t._iterateLinks(function (i) {
          var r = hstc.utils.checkHashedDomain(i.hostname, e);
          n && r == n && (r = "");
          return (
            i.hostname && i.hostname !== t.context.getHostName() && r.length > 0
          );
        });
      });
    }
  };
  hstc.tracking.Tracker.prototype.handleSearchLink = function (t) {
    var e = this;
    e._enqueueConsentListener(function () {
      e.handleLink(t, null, !0);
    });
  };
  hstc.tracking.Tracker.prototype.handleSearchLinks = function () {
    var t = this;
    t._manageCookies();
    var e = new RegExp(
      "(/_hcms/analytics/search/conversion|/_hcms/analytics/search/request)"
    );
    t._enqueueConsentListener(function () {
      t._iterateLinks(function (t) {
        return t.href.match(e);
      });
    });
  };
  hstc.tracking.Tracker.prototype._iterateLinks = function (t) {
    var e = this;
    hstc.utils.each(hstc.find("a"), function (n, i) {
      if (e.utk && e.utk.visitor)
        try {
          if (t(i))
            try {
              i.href = e.handleLink(i.href, i.target, !0);
            } catch (t) {
              i &&
                i.href &&
                hstc.utils.logError(
                  "Unable to modify link to " + i.href,
                  e._determineTrackingDomain()
                );
            }
        } catch (t) {
          hstc.log("Can't modify link.");
        }
    });
  };
  hstc.tracking.Tracker.prototype.handleLink = function (t, e, n) {
    var i = t,
      r = this._getFingerprint();
    if (null !== r) {
      i = hstc.utils.updateQueryStringParameter(i, "__hstc", this.utk.get());
      i = hstc.utils.updateQueryStringParameter(
        i,
        "__hssc",
        this.session.get()
      );
      i = hstc.utils.updateQueryStringParameter(i, "__hsfp", r);
    }
    if (n) return i;
    this.context.getWindow().open(i, e || "_self");
  };
  hstc.tracking.Tracker.prototype.identify = function (t, e) {
    e || this._manageCookies();
    t instanceof Array || "object" != typeof t
      ? this.logError(
          "Function identify was not called with a supported object: <" +
            t +
            ">",
          this._determineTrackingDomain()
        )
      : this.identity
      ? this.identity.merge(t)
      : (this.identity = new hstc.identities.Identity(t));
  };
  hstc.tracking.Tracker.prototype.trackPageView = function () {
    this._manageCookies();
    var t = { k: 1 };
    this._loadImage(t);
  };
  hstc.tracking.Tracker.prototype.trackConversion = function (t, e) {
    this._manageCookies();
    if ("string" == typeof t || "number" == typeof t) {
      t = { id: hstc.utils.safeString(t) };
      hstc.utils.isDefined(e) && (t = hstc.utils.mergeObject(t, e));
    }
    hstc.utils.isFunction(t.value) && (t.value = t.value(hstc));
    var n = hstc.utils.mergeObject(t, {
      k: 3,
      n: hstc.utils.safeString(t.id),
      m: hstc.utils.safeString(t.value),
    });
    this._loadImage(n);
  };
  hstc.tracking.Tracker.prototype.trackEvent =
    hstc.tracking.Tracker.prototype.trackConversion;
  hstc.tracking.Tracker.prototype.trackClick = function (t, e, n) {
    var i = this,
      r = {
        selector: t,
        eventId: e,
        opts: (n = n || {}),
        handler: function (t) {
          try {
            if (hstc.utils.isDefined(i.portalId)) {
              var r = (t && t.target) || {},
                o = {
                  hs_element_text: (r.innerText || r.value || "").trim(),
                  hs_link_href: r.href,
                  hs_element_id: r.id,
                  hs_element_class: r.className,
                  hs_tracking_config_id: n.trackingConfigId,
                };
              r &&
                !hstc.utils.isEmpty(r) &&
                i.getParentNodeModuleId(r) &&
                (o.hs_parent_module_id = i.getParentNodeModuleId(r));
              if (hstc.utils.startsWith(e, "pe" + i.portalId + "_"))
                i.trackCustomBehavioralEvent({ name: e, properties: o });
              else if (hstc.utils.startsWith(e, "autocaptureClick")) {
                var s = hstc.utils.mergeObject(o, {
                  hs_mouse_x_coordinate: t.clientX,
                  hs_mouse_y_coordinate: t.clientY,
                  hs_scroll_x_coordinate: window.scrollX,
                  hs_scroll_y_coordinate: window.scrollY,
                  hs_viewport_width: document.documentElement.clientWidth,
                  hs_viewport_height: document.documentElement.clientHeight,
                });
                i.trackClickEvent({ properties: s });
              }
            }
            (hstc.utils.isDefined(i.portalId) &&
              (hstc.utils.startsWith(e, "pe" + i.portalId + "_") ||
                hstc.utils.startsWith(e, "autocaptureClick"))) ||
              i.trackEvent(e, n);
          } catch (t) {
            hstc.utils.logError(t, i._determineTrackingDomain());
          }
        },
      };
    this.clickSelectors.push(r);
    this._resetClickHandler(r);
  };
  hstc.tracking.Tracker.prototype._resetClickHandler = function (t) {
    var e = "data-hs-event-" + hstc.utils.hashString(t.eventId),
      n = !t.opts.url || this.urlMatches(t.opts.url);
    try {
      hstc.utils.each(hstc.find(t.selector), function (i, r) {
        var o = "1" == r.getAttribute(e);
        if (o && !n) {
          hstc.utils.removeEventListener(r, "mousedown", t.handler);
          r.removeAttribute(e);
        } else if (!o && n) {
          hstc.utils.addEventListener(r, "mousedown", t.handler);
          r.setAttribute(e, "1");
        }
      });
    } catch (e) {
      hstc.log(
        "Bad selector for " +
          this.portalId +
          ": " +
          t.selector +
          ", for event " +
          t.eventId
      );
    }
  };
  hstc.tracking.Tracker.prototype.trackFormView = function (t, e, n) {
    this._trackFormActivity(15, t, e, n);
  };
  hstc.tracking.Tracker.prototype.trackFormInstall = function (t, e, n) {
    this._trackFormActivity(16, t, e, n);
  };
  hstc.tracking.Tracker.prototype.trackFormVisible = function (t, e, n) {
    this._trackFormActivity(17, t, e, n);
  };
  hstc.tracking.Tracker.prototype.trackFormInteraction = function (t, e, n) {
    this._trackFormActivity(18, t, e, n);
  };
  hstc.tracking.Tracker.prototype.trackFormCompletion = function (t, e, n) {
    this._trackFormActivity(19, t, e, n);
  };
  hstc.tracking.Tracker.prototype._trackFormActivity = function (t, e, n, i) {
    if ("object" == typeof n) {
      i = n;
      n = "";
    }
    i = i || {};
    var r = { k: t, fi: hstc.utils.safeString(e) };
    hstc.utils.isEmpty(n) || (r.fci = n);
    (hstc.utils.isEmpty(i.formVariantId) && hstc.utils.isEmpty(i.fvi)) ||
      (r.fvi = i.formVariantId || i.fvi);
    (hstc.utils.isEmpty(i.leadFlowId) && hstc.utils.isEmpty(i.lfi)) ||
      (r.lfi = i.leadFlowId || i.lfi);
    (hstc.utils.isEmpty(i.formType) && 0 !== i.formType) || (r.ft = i.formType);
    this._loadImage(r);
  };
  hstc.tracking.Tracker.prototype.trackFeedbackView = function (t) {
    t = t || {};
    var e = {
      k: 26,
      st: hstc.utils.safeString(t.surveyType),
      si: hstc.utils.safeString(t.surveyId),
    };
    this._loadImage(e);
  };
  hstc.tracking.Tracker.prototype.trackCtaView = function (t, e) {
    var n = {
      k: 12,
      aij:
        '["' +
        hstc.utils.safeString(t) +
        '","' +
        hstc.utils.safeString(e) +
        '"]',
      rfc: 8,
    };
    this._loadImage(n);
  };
  hstc.tracking.Tracker.prototype.trackAudioPlay = function (t) {
    var e = { k: 33 };
    (t = t || {}).fileId && (e.afi = t.fileId);
    t.episodeId && (e.aei = t.episodeId);
    t.showId && (e.asi = t.showId);
    hstc.utils.isEmpty(t.moduleType) || (e.amt = t.moduleType);
    "number" == typeof t.duration && (e.ad = t.duration);
    hstc.utils.isEmpty(t.playSessionId) || (e.aps = t.playSessionId);
    hstc.utils.isEmpty(t.eventPhase) || (e.aep = t.eventPhase);
    this._loadImage(e);
  };
  hstc.tracking.Tracker.prototype.doNotTrack = function (t) {
    t && t.track
      ? this.cookie.remove(hstc.tracking.Tracker.DO_NOT_TRACK)
      : this.cookie.set(hstc.tracking.Tracker.DO_NOT_TRACK, "yes", {
          daysToExpire: hstc.tracking.Tracker.DO_NOT_TRACK_EXPIRATION,
        });
  };
  hstc.tracking.Tracker.prototype.autocaptureClicks = function () {
    this.trackClick('input[type="button"], button, a', "autocaptureClick");
  };
  hstc.tracking.Tracker.prototype.urlMatches = function (t, e) {
    e || (e = this.context.getCurrentHref(this.path));
    if (e == (t = t.toLowerCase())) return !0;
    if (-1 === t.indexOf("?")) {
      var n = e.indexOf("?");
      -1 !== n && (e = e.substring(0, n));
    }
    if (-1 == t.indexOf("*"))
      return (
        (t = t.replace(/\/$/, "")) == (e = e.replace(/\/$/, "")) ||
        (0 === t.indexOf("/") && hstc.utils.removeDomain(e) == t)
      );
    if (t == e) return !0;
    if (0 === t.length) return !1;
    var i = new RegExp("[.+?|()\\[\\]{}\\\\]", "g");
    regex = t.replace(i, "\\$&").replace(new RegExp("\\*", "g"), "(.*?)");
    regex = /\/$/.test(regex) ? "^" + regex + "$" : "^" + regex + "/?$";
    regex = new RegExp(regex, "i");
    if (regex.test(e)) return !0;
    if (0 === t.indexOf("/")) {
      e = "/" + e.split("//")[1].split("/").splice(1).join("/");
      return regex.test(e);
    }
    return !1;
  };
  hstc.tracking.Tracker.prototype.resetVisitorIdentity = function () {
    this.hasResetVisitor = !0;
    this.utk = hstc.tracking.Utk.regenerate(this.cookie);
    this.session = hstc.tracking.Session.regenerate(this.cookie);
    this.identity = null;
    this._manageCookies(this.utk, this.session, !0);
  };
  hstc.tracking.Tracker.prototype.resetVisitor = function () {
    this.resetVisitorIdentity();
    this.crossDomainLinkingEnabled && this.enableAutomaticLinker();
    this.handleSearchLinks();
  };
  hstc.tracking.Tracker.prototype._manageCookies = function (t, e, n) {
    var i = this;
    if (!this.managedCookies || n) {
      var r = hstc.tracking.Utk.parse(this.cookie),
        o = hstc.tracking.Session.parse(this.cookie);
      if (!this.hasResetVisitor) {
        this._extractIdentitiesFromQueryString(r, o);
        this._extractUtkOverride(r);
      }
      this.utk || (this.utk = t || r);
      this.session || (this.session = e || o);
      this.session.isNew() && !n
        ? this.utk.isNew() || this.utk.rotate(this.session.start)
        : n || this.session.increment();
      this.context.getWindow().__hsUserToken ||
        (this.context.getWindow().__hsUserToken = this.utk.visitor);
      this._enqueueConsentListener(function () {
        i.utk.save(i.privacySettings, i.privacyConsent);
        i.session.save();
      });
      for (var s = 0; s < this.userTokenListeners.length; s++)
        this.userTokenListeners[s](this.utk.visitor);
      for (var a = 0; a < this.cookieListeners.length; a++)
        this.cookieListeners[a](
          this.utk.get(),
          this.session.get(),
          this._getFingerprint()
        );
      this.managedCookies = !0;
    }
  };
  hstc.tracking.Tracker.prototype._extractIdentitiesFromQueryString = function (
    t,
    e
  ) {
    var n = this._getUrlParams();
    n.__hs_email &&
      this.identify({ email: hstc.utils.decodeParam(n.__hs_email) }, !0);
    if (0 !== this.cookie.getHashedDomains().length) {
      var i = this;
      if (n.__hsfp) {
        var r = hstc.utils.safeString(n.__hsfp),
          o = this._getFingerprint();
        if (null === o || o != r) return;
        if (n.__hstc) {
          var s = hstc.tracking.Utk.parse(
            this.cookie,
            hstc.utils.safeString(n.__hstc)
          );
          hstc.utils.each(this.cookie.getHashedDomains(), function (e, n) {
            if (n == s.domain) {
              if (i.utk && i.utk.visitor !== s.visitor)
                i.identify({ visitor: s.visitor }, !0);
              else if (t.recovered) {
                if (t.visitor !== s.visitor) {
                  i.utk = t;
                  i.identify({ visitor: s.visitor }, !0);
                }
              } else {
                i.utk = s;
                i.utk.resetDomain();
              }
              return !1;
            }
          });
        }
        if (n.__hssc) {
          var a = hstc.tracking.Session.parse(
            this.cookie,
            hstc.utils.safeString(n.__hssc)
          );
          hstc.utils.each(this.cookie.getHashedDomains(), function (t, n) {
            if (n == a.domain) {
              if (e.recovered) i.session = e.merge(a);
              else {
                i.session = a;
                i.session.resetDomain();
                i.session.recovered = !0;
              }
              return !1;
            }
          });
        }
      }
    }
  };
  hstc.tracking.Tracker.prototype._extractUtkOverride = function (t) {
    var e = this.context.getWindow().__hsUserToken;
    if (e) {
      var n = this.utk && this.utk.visitor == e,
        i = t.visitor == e,
        r = this.identity && !!this.identity.get().visitor;
      n ||
        i ||
        r ||
        (this.utk || t.recovered
          ? this.identify({ visitor: e }, !0)
          : (this.utk = hstc.tracking.Utk.parse(this.cookie, e, !0)));
    }
  };
  hstc.tracking.Tracker.prototype._loadImage = function (t, e) {
    if (!this.limitTrackingToCookieDomains || this.cookie.currentDomain) {
      if (!this._hasDoNotTrack() && this.trackingEnabled) {
        hstc.log("Sending Request");
        t && hstc.log(t);
        e = e || this._generateURL(t);
        hstc.log(e);
        hstc.utils.loadImage(e, 0);
      }
    } else
      try {
        hstc.log(
          "Invalid domain for portal " +
            this.portalId +
            ": " +
            this.context.getHostName()
        );
      } catch (t) {}
  };
  hstc.tracking.Tracker.prototype._generateURL = function (t) {
    var e = "https://" + this._determineTrackingDomain() + "/__ptq.gif",
      n = hstc.utils.extend(
        t,
        this._getClientInfo(),
        this._getPageInfo(),
        this._getUserInfo(),
        this._getPrivacyInfo()
      );
    return e + "?" + hstc.utils.param(n);
  };
  hstc.tracking.Tracker.prototype._determineTrackingDomain = function () {
    return this.trackingDomain ? this.trackingDomain : hstc.ANALYTICS_HOST;
  };
  hstc.tracking.Tracker.prototype._getUserInfo = function () {
    var t = {};
    t.cts = hstc.utils.utcnow();
    if (this.identity) {
      var e = {},
        n = this.identity.get();
      if ("object" == typeof n) {
        Object.keys(n).forEach((t) => {
          e[t] = n[t] || "";
        });
        t.i = hstc.utils.param(e);
      } else
        hstc.utils.logError(
          "Identity is not a supported object: <" + n + ">",
          this._determineTrackingDomain()
        );
    }
    this.hasResetVisitor && (t.rv = 1);
    if (this.utk) {
      t.vi = this.utk.visitor;
      t.nc = this.utk.isNew();
    }
    var i = this.cookie.get(hstc.tracking.Utk.COOKIE);
    hstc.utils.isEmpty(i) || (t.u = i);
    var r = this.cookie.get(hstc.tracking.Session.COOKIE);
    hstc.utils.isEmpty(r) || (t.b = r);
    (this.privacyConsent && this.privacyConsent.allowed) || (t.ce = !1);
    return t;
  };
  hstc.tracking.Tracker.prototype._getPageInfo = function () {
    var t = {};
    t.v = hstc.JS_VERSION;
    t.a = this.portalId;
    hstc.utils.isEmpty(this.pageId) || (t.pi = this.pageId);
    hstc.utils.isEmpty(this.contentType) || (t.ct = this.contentType);
    hstc.utils.isEmpty(this.canonicalUrl) || (t.ccu = this.canonicalUrl);
    if (!hstc.utils.isEmpty(this.path)) {
      t.po = this.path;
      if (
        (this.session || hstc.tracking.Session.parse(this.cookie)).viewCount <=
        1
      ) {
        var e = hstc.utils.resolveInitialUrl(this.path);
        t.po = e;
        t.qo = e !== this.path;
        t.opo = this.path;
      }
    }
    hstc.utils.isEmpty(this.referrerPath) || (t.rpo = this.referrerPath);
    hstc.utils.isEmpty(this.canonicalUrl) &&
      !hstc.utils.isEmpty(this.relCanonicalUrl) &&
      (t.rcu = this.relCanonicalUrl);
    if (!hstc.utils.isEmpty(this.contentMetadata)) {
      var n = this.contentMetadata;
      hstc.utils.isEmpty(n.contentPageId) || (t.cpi = n.contentPageId);
      hstc.utils.isEmpty(n.contentGroupId) || (t.cgi = n.contentGroupId);
      hstc.utils.isEmpty(n.contentFolderId) || (t.cfi = n.contentFolderId);
      hstc.utils.isEmpty(n.legacyPageId) || (t.lpi = n.legacyPageId);
      hstc.utils.isEmpty(n.abTestId) || (t.abi = n.abTestId);
      hstc.utils.isEmpty(n.languageVariantId) || (t.lvi = n.languageVariantId);
      hstc.utils.isEmpty(n.languageCode) || (t.lvc = n.languageCode);
      if (
        !hstc.utils.isEmpty(n.mabData) &&
        !hstc.utils.isEmpty(n.mabData.correlationId) &&
        !hstc.utils.isEmpty(n.mabData.experimentId)
      ) {
        t.mabci = n.mabData.correlationId;
        t.mabei = n.mabData.experimentId;
      }
      hstc.utils.isEmpty(n.scpContentType) || (t.scpct = n.scpContentType);
      hstc.utils.isEmpty(n.inChatView) || (t.icv = n.inChatView);
    }
    if (
      hstc.utils.isArray(this.targetedContentMetadata) &&
      this.targetedContentMetadata.length
    ) {
      for (
        var i = [], r = Math.min(this.targetedContentMetadata.length, 5), o = 0;
        o < r;
        o++
      ) {
        var s = this.targetedContentMetadata[o];
        3 === s.length && i.push(s[0] + "-" + s[1] + "-" + s[2]);
      }
      i.length && (t.tc = i);
    }
    var a = this.context.getReferrer();
    hstc.utils.isEmpty(a) || (t.r = a);
    var c = this.context.getLocation().href;
    hstc.utils.isEmpty(c) || (t.pu = c);
    var u = this.context.getDocument().title;
    hstc.utils.isEmpty(u) || (t.t = u);
    return t;
  };
  hstc.tracking.Tracker.prototype._getClientInfo = function () {
    var t = {},
      e = this.context.getScreen();
    if (e) {
      t.sd = e.width + "x" + e.height;
      t.cd = e.colorDepth + "-bit";
    }
    var n = this.context.getCharacterSet();
    hstc.utils.isEmpty(n) || (t.cs = n);
    var i = this.context.getNavigator(),
      r = i.language ? i.language : i.browserLanguage ? i.browserLanguage : "";
    hstc.utils.isEmpty(r) || (t.ln = hstc.utils.makeLowerCase(r));
    if (!this._hasDoNotTrack()) {
      var o = this._getFingerprint();
      null !== o && (t.bfp = o);
    }
    return t;
  };
  hstc.tracking.Tracker.prototype._getPrivacyInfo = function () {
    var t = {};
    this.privacySettings &&
      ("OPT_IN" == this.privacySettings.mode && this.privacySettings.hideDecline
        ? (t.pt = 0)
        : "OPT_IN" == this.privacySettings.mode
        ? (t.pt = 1)
        : "NO_COOKIES" == this.privacySettings.mode
        ? (t.pt = 2)
        : "COOKIES_BY_CATEGORY" == this.privacySettings.mode && (t.pt = 3));
    (this.privacyConsent && this.privacyConsent.allowed) || (t.ce = !1);
    t.cc = 0;
    this.privacyConsent &&
      this.privacyConsent.categories &&
      (t.cc =
        (this.privacyConsent.categories.necessary ? 1 : 0) +
        (this.privacyConsent.categories.analytics ? 2 : 0) +
        (this.privacyConsent.categories.advertisement ? 4 : 0) +
        (this.privacyConsent.categories.functionality ? 8 : 0));
    return t;
  };
  hstc.tracking.Tracker.prototype._hasDoNotTrack = function () {
    try {
      if (
        this.cookie.get(hstc.tracking.Tracker.DO_NOT_TRACK) &&
        "yes" == this.cookie.get(hstc.tracking.Tracker.DO_NOT_TRACK)
      )
        return !0;
    } catch (t) {}
    return !1;
  };
  hstc.tracking.Tracker.prototype.showTargetedElements = function () {
    hstc.utils.each(this.clickSelectors, function (t, e) {
      hstc.utils.each(hstc.find(e), function (t, e) {
        e._hs_oldStyle = e.style.border;
        e.style.border = "dotted 2px red";
      });
    });
  };
  hstc.tracking.Tracker.prototype.hideTargetedElements = function () {
    var t = function (t, e) {
      hstc.utils.each(hstc.find(e), function (t, e) {
        hstc.utils.isDefined(e._hs_oldStyle) &&
          (e.style.border = e._hs_oldStyle);
      });
    };
    hstc.utils.each(this.clickSelectors, t);
  };
  hstc.tracking.Tracker.prototype.removeCookies = function () {
    this.cookie.remove(hstc.tracking.Utk.COOKIE);
    this.cookie.remove(hstc.tracking.Utk.LEGACY_COOKIE);
    this.cookie.remove(hstc.tracking.Session.RESTART_COOKIE);
    this.cookie.remove(hstc.tracking.Session.COOKIE);
    this.utk && this.utk.removeCookies();
    this.session && this.session.removeCookies();
  };
  hstc.tracking.Tracker.prototype._handlePrivacyPolicy = function () {
    var t = this;
    this._enqueuePrivacyCall("addPrivacyConsentListener", function (e) {
      var n = e && (e.allowed || (e.categories && e.categories.analytics)),
        i = e && e.categories;
      t.privacyConsent = { allowed: n, categories: i };
      if (!1 === n) {
        t.removeCookies();
        t.resetVisitorIdentity();
      }
    });
    this._enqueuePrivacyCall("addPrivacySettingsListener", function (e) {
      t.privacySettings = e;
    });
  };
  hstc.tracking.Tracker.prototype._enqueueConsentListener = function (t) {
    this._enqueuePrivacyCall("addPrivacyConsentListener", function (e) {
      e && (e.allowed || (e.categories && e.categories.analytics)) && t();
    });
  };
  hstc.tracking.Tracker.prototype._enqueuePrivacyCall = function (t, e) {
    var n = this._getHspQueue();
    e ? n.push([t, e]) : n.push([t]);
  };
  hstc.tracking.Tracker.prototype._handleMigrations = function () {
    var t =
        this.cookie.get(hstc.tracking.Utk.LEGACY_COOKIE) || window.hubspotutk,
      e = this.cookie.get(hstc.tracking.Utk.COOKIE);
    if (
      !hstc.utils.isEmpty(t) &&
      /[0123456789abcdef]{32}/.test(t) &&
      hstc.utils.isEmpty(e)
    ) {
      var n = hstc.tracking.Utk.parse(this.cookie, t);
      this._manageCookies(n);
    }
    hstc.utils.isEmpty(this.cookie.get("hsfirstvisit")) ||
      this.cookie.remove("hsfirstvisit");
  };
  hstc.tracking.Tracker.prototype._setRelCanonicalUrl = function () {
    for (
      var t = document.getElementsByTagName("link"), e = 0;
      e < t.length;
      e++
    )
      if ("canonical" === t[e].rel) {
        this.relCanonicalUrl = t[e].href;
        return;
      }
  };
  hstc.tracking.Tracker.prototype._getFingerprint = function () {
    var t = this;
    try {
      return new hstc.Fingerprint().get();
    } catch (e) {
      hstc.utils.logError(e, t._determineTrackingDomain());
      return null;
    }
  };
  hstc.tracking.Tracker.prototype._getUrlParams = function () {
    var t,
      e,
      n = this.context.getLocation();
    try {
      t = n.search;
      e = n.hash;
    } catch (n) {
      t = window.location.search;
      e = window.location.hash;
    }
    return hstc.utils.deparam(t || e);
  };
  hstc.tracking.Tracker.prototype.embedHubSpotScript = function (t, e) {
    if (
      !(
        (this.hasTrackingGate("AnalyticsTracking:BlockEmbeddedScriptReload") &&
          this.context.getWindow()._hstc_loaded) ||
        document.getElementById(e)
      ) &&
      this.trackingEnabled
    ) {
      var n = document.createElement("script");
      n.src = t;
      n.type = "text/javascript";
      n.id = e;
      var i = document.getElementsByTagName("script")[0];
      i.parentNode.insertBefore(n, i);
    }
  };
  hstc.tracking.Tracker.prototype.revokeCookieConsent = function () {
    this._enqueuePrivacyCall("revokeCookieConsent");
  };
  hstc.tracking.Tracker.prototype.trackApproveCookieConsent = function () {
    this._loadImage({ k: 28 });
  };
  hstc.tracking.Tracker.prototype.trackDeclineCookieConsent = function () {
    this._loadImage({ k: 29 });
  };
  hstc.tracking.Tracker.prototype.trackRevokeCookieConsent = function () {
    this._loadImage({ k: 30 });
  };
  hstc.tracking.Tracker.prototype._safeCallListener = function (t, e) {
    var n = this;
    try {
      t(e);
    } catch (t) {
      hstc.utils.logError(t, n._determineTrackingDomain());
    }
  };
  hstc.tracking.Tracker.prototype._handleCtaReplacedInlineHtml = function () {
    window.HubSpotCallsToActions
      ? window.HubSpotCallsToActions.on(
          "onCallToActionReplacedInlineHTML",
          () => {
            this.refreshPageHandlers();
          }
        )
      : (window.hsCallsToActionsReady = window.hsCallsToActionsReady || [
          () => {
            window.HubSpotCallsToActions.on(
              "onCallToActionReplacedInlineHTML",
              () => {
                this.refreshPageHandlers();
              }
            );
          },
        ]);
  };
  hstc.tracking.Utk = function (t, e, n, i, r, o, s, a, c) {
    this.context = t ? t.context : new hstc.global.Context();
    this.cookie = t || new hstc.cookies.Cookie(this.context);
    this.rawDomain =
      this.cookie.currentDomain ||
      hstc.utils.extractDomain(this.context.getHostName());
    this.domain = e && !a ? e : hstc.utils.hashString(this.rawDomain);
    this.visitor = n ? n.toLowerCase() : hstc.Math.uuid();
    this.initial = i || hstc.utils.utcnow();
    this.previous = r || hstc.utils.utcnow();
    this.current = o || hstc.utils.utcnow();
    this.session = s || 1;
    this.recovered = a;
    this.returningVisitor = c;
  };
  hstc.tracking.Utk.COOKIE = "__hstc";
  hstc.tracking.Utk.LEGACY_COOKIE = "hubspotutk";
  hstc.tracking.Utk.EXPIRATION = 180;
  hstc.tracking.Utk.EXPIRATION_START = 15444e8;
  hstc.tracking.Utk.parse = function (t, e, n) {
    var i = t ? t.context : new hstc.global.Context();
    t = t || new hstc.cookies.Cookie(i);
    var r = !e;
    e = e || t.get(hstc.tracking.Utk.COOKIE);
    try {
      var o = e.split(".");
      if (6 == o.length && o[1].length > 0) {
        o[5] = parseInt(o[5], 10);
        return new hstc.tracking.Utk(
          t,
          o[0],
          o[1],
          o[2],
          o[3],
          o[4],
          o[5],
          r,
          !0
        );
      }
      if (1 == o.length && o[0].length > 0)
        return new hstc.tracking.Utk(
          t,
          null,
          o[0],
          null,
          null,
          null,
          null,
          !n,
          !1
        );
    } catch (t) {}
    return hstc.tracking.Utk.regenerate(t);
  };
  hstc.tracking.Utk.regenerate = function (t) {
    return new hstc.tracking.Utk(t);
  };
  hstc.tracking.Utk.prototype.isNew = function () {
    return !this.returningVisitor;
  };
  hstc.tracking.Utk.prototype.rotate = function (t) {
    this.previous = this.current || t;
    this.current = t;
    this.session += 1;
  };
  hstc.tracking.Utk.prototype.get = function () {
    return [
      this.domain,
      this.visitor,
      this.initial,
      this.previous,
      this.current,
      this.session,
    ].join(".");
  };
  hstc.tracking.Utk.prototype.save = function (t, e) {
    var n =
        t &&
        1 == t.active &&
        ("OPT_IN" == t.mode || "COOKIES_BY_CATEGORY" == t.mode) &&
        0 == t.hideDecline,
      i = e && 1 == e.allowed;
    if (!this.isNew() && n) {
      if (i) {
        var r =
          hstc.tracking.Utk.EXPIRATION -
          Math.floor((hstc.utils.utcnow() - this.initial) / 864e5);
        this.cookie.set(hstc.tracking.Utk.COOKIE, this.get(), {
          daysToExpire: r,
        });
        this.cookie.set(hstc.tracking.Utk.LEGACY_COOKIE, this.visitor, {
          daysToExpire: r,
        });
      }
    } else {
      this.cookie.set(hstc.tracking.Utk.COOKIE, this.get(), {
        daysToExpire: hstc.tracking.Utk.EXPIRATION,
      });
      this.cookie.set(hstc.tracking.Utk.LEGACY_COOKIE, this.visitor, {
        daysToExpire: hstc.tracking.Utk.EXPIRATION,
      });
    }
  };
  hstc.tracking.Utk.prototype.removeCookies = function (t) {
    this.cookie.remove(hstc.tracking.Utk.COOKIE);
    this.cookie.remove(hstc.tracking.Utk.LEGACY_COOKIE);
  };
  hstc.tracking.Utk.prototype.resetDomain = function () {
    this.domain = hstc.utils.hashString(this.rawDomain);
  };
  hstc.tracking.Session = function (t, e, n, i, r) {
    this.context = t ? t.context : new hstc.global.Context();
    this.cookie = t || new hstc.cookies.Cookie(this.context);
    this.rawDomain =
      this.cookie.currentDomain ||
      hstc.utils.extractDomain(this.context.getHostName());
    this.domain = e && !r ? e : hstc.utils.hashString(this.rawDomain);
    this.viewCount = n || 1;
    this.start = i || hstc.utils.utcnow();
    this.recovered = r;
  };
  hstc.tracking.Session.COOKIE = "__hssc";
  hstc.tracking.Session.RESTART_COOKIE = "__hssrc";
  hstc.tracking.Session.prototype.isNew = function () {
    return !0 !== this.recovered;
  };
  hstc.tracking.Session.parse = function (t, e) {
    var n = t ? t.context : new hstc.global.Context();
    t = t || new hstc.cookies.Cookie(n);
    var i = !e;
    if (e || "1" === t.get(hstc.tracking.Session.RESTART_COOKIE)) {
      e = e || t.get(hstc.tracking.Session.COOKIE);
      try {
        var r = e.split(".");
        if (3 == r.length)
          return new hstc.tracking.Session(t, r[0], r[1], r[2], i);
      } catch (t) {}
    }
    return hstc.tracking.Session.regenerate(t);
  };
  hstc.tracking.Session.regenerate = function (t) {
    return new hstc.tracking.Session(t);
  };
  hstc.tracking.Session.prototype.increment = function () {
    try {
      this.viewCount = parseInt(this.viewCount || 1, 10) + 1;
    } catch (t) {
      this.viewCount = 1;
    }
  };
  hstc.tracking.Session.prototype.get = function () {
    return [this.domain, this.viewCount, this.start].join(".");
  };
  hstc.tracking.Session.prototype.save = function () {
    this.cookie.set(hstc.tracking.Session.RESTART_COOKIE, "1");
    this.cookie.set(hstc.tracking.Session.COOKIE, this.get(), {
      minsToExpire: 30,
    });
  };
  hstc.tracking.Session.prototype.removeCookies = function () {
    this.cookie.remove(hstc.tracking.Session.RESTART_COOKIE);
    this.cookie.remove(hstc.tracking.Session.COOKIE);
  };
  hstc.tracking.Session.prototype.merge = function (t) {
    t.start && t.start < this.start && (this.start = t.start);
    t.viewCount && (this.viewCount += t.viewCount);
    return this;
  };
  hstc.tracking.Session.prototype.resetDomain = function () {
    this.domain = hstc.utils.hashString(this.rawDomain);
  };
  hstc.tracking.Tracker.prototype.trackCustomBehavioralEvent = function (t) {
    if (t) {
      this._manageCookies();
      var e = {};
      hstc.utils.isDefined(t.name) && (e.n = hstc.utils.safeString(t.name));
      if (hstc.utils.isDefined(t.properties))
        for (var n in t.properties)
          if (hstc.utils.isDefined(n)) {
            e["_" + n] = hstc.utils.safeString(t.properties[n]);
          }
      var i = this._determineTrackingDomain(),
        r = hstc.utils.extend(
          e,
          this._getClientInfo(),
          this._getPageInfo(),
          this._getUserInfo(),
          this._getPrivacyInfo()
        ),
        o = "https://" + i + "/__ptbe.gif?" + hstc.utils.param(r);
      this._loadImage(e, o);
    }
  };
  hstc.tracking.Tracker.prototype.trackClickEvent = function (t) {
    this._manageCookies();
    var e = {};
    if (hstc.utils.isDefined(t.properties))
      for (var n in t.properties)
        if (hstc.utils.isDefined(n)) {
          e["_" + n] = hstc.utils.safeString(t.properties[n]);
        }
    var i = this._determineTrackingDomain(),
      r = hstc.utils.extend(
        e,
        this._getClientInfo(),
        this._getPageInfo(),
        this._getUserInfo(),
        this._getPrivacyInfo()
      ),
      o = "https://" + i + "/__ptc.gif?" + hstc.utils.param(r);
    this._loadImage(e, o);
  };
  hstc.tracking.Tracker.prototype.getPageDiagnostics = function () {
    var t = { type: "hsAnalyticsDiag" };
    t.canonicalUrl = this.canonicalUrl;
    t.debugLogs = [];
    hstc.__logs &&
      hstc.utils.each(hstc.__logs, function (e, n) {
        t.debugLogs.push(JSON.stringify(n));
      });
    hstc.__logs = [];
    t.trackingScripts = [];
    hstc.utils.each(hstc.find("#hs-analytics"), function (e, n) {
      t.trackingScripts.push(n.src);
    });
    return t;
  };
  hstc.tracking.Tracker.prototype._initPageDiagnostics = function () {
    document.location.hash.indexOf("#hsdbg") > -1 &&
      hstc.utils.addEventListener(
        this.context.getWindow(),
        "message",
        function (t) {
          "hsAnalyticsDiag" === t.data &&
            t.source &&
            t.source.postMessage &&
            hstc.utils.isValidHubUrl(t.origin) &&
            t.source.postMessage(this.getPageDiagnostics(), t.origin);
        }.bind(this)
      );
  };
  hstc.tracking.Tracker.prototype.getParentNodeModuleId = function (t) {
    return hstc.utils.getParentNodeModuleId(t);
  };
  hstc.tracking.Tracker.prototype.initEventVisualizerScript = function () {
    const t = "eventVisualizerIsLocal",
      e = "hubspotEventVisualizeMode",
      n = "hubspotEventLabelerMode",
      i = "true",
      r = "hs-events-builder",
      o = this.context.getReferrer(),
      s = "hsExchangeCredentials";
    try {
      const a = localStorage.getItem(e) === i,
        c = localStorage.getItem(n) === i,
        u = localStorage.getItem(t) === i,
        l = () => {
          if (!document.getElementById(r)) {
            const t = document.createElement("script"),
              e = /^https:\/\/js(-?[a-z0-9]*)\.([a-z0-9-]+)\./i,
              n = this.currentScriptUrl.match(e);
            if (n) {
              const e = n[1] || "",
                i = u ? "local" : "app",
                o = "hs-analytics" === n[2] ? "hubspot" : "hubspotqa";
              t.id = r;
              t.src = `https://${i}${e}.${o}.com/events-visualizer.js`;
              t.async = !0;
              document.body.appendChild(t);
            }
          }
        };
      this.eventBuilderMessageHandler = (t) => {
        const { data: e, origin: n } = t;
        if (hstc.utils.isValidHubUrl(n) || u) {
          const t = e?.message;
          t === s && l();
        }
      };
      window.addEventListener("message", this.eventBuilderMessageHandler);
      (hstc.utils.isValidHubUrl(o) || a || c) && l();
    } catch (t) {
      hstc.utils.logError(t, this._determineTrackingDomain());
    }
  };
  hstc.tracking.Tracker.prototype.logError = function (t, e) {
    hstc.utils.logError(t, e);
  };
  (hstc = hstc || {}).tracking = hstc.tracking || {};
  hstc.tracking.Runner = function (t, e) {
    this.context = t || new hstc.global.Context();
    this.cookie = e || new hstc.cookies.Cookie(this.context);
    this.tracker = new hstc.tracking.Tracker(this.context, this.cookie);
  };
  hstc.tracking.Runner.hsqParam = "_hsq";
  hstc.tracking.Runner.ranParam = "_hstc_ran";
  hstc.tracking.Runner.priorityFunctions = [
    "setPortalId",
    "setCanonicalUrl",
    "setPath",
    "setContentType",
    "setContentMetadata",
    "setPageId",
    "setTargetedContentMetadata",
    "identify",
    "setDebugMode",
    "setLimitTrackingToCookieDomains",
    "setTrackingEnabled",
    "doNotTrack",
  ];
  hstc.tracking.Runner.prototype.run = function () {
    var t = this.context.getWindow();
    if (!t[hstc.tracking.Runner.ranParam]) {
      t[hstc.tracking.Runner.ranParam] = !0;
      var e = this.tracker;
      this.setUpHsq(n);
      this.processHsq(n);
    }
    function n(t) {
      try {
        if ("function" == typeof t) t(e, hstc);
        else if (t && hstc.utils.isArray(t) && e[t[0]])
          return e[t[0]].apply(e, t.slice(1));
      } catch (t) {
        hstc.utils.logError(t);
      }
    }
  };
  hstc.tracking.Runner.prototype.setUpHsq = function (t) {
    var e = this.context.getWindow(),
      n = (e[hstc.tracking.Runner.hsqParam] =
        e[hstc.tracking.Runner.hsqParam] || []);
    hstc.utils.isArray(n) || (n = e[hstc.tracking.Runner.hsqParam] = []);
    n.push = t;
  };
  hstc.tracking.Runner.prototype.processHsq = function (t) {
    var e = this.context.getWindow()[hstc.tracking.Runner.hsqParam];
    hstc.utils.search2dArray(
      e,
      1,
      ["setTrackingDomain", "setCookiesToSubdomain"],
      t
    );
    hstc.utils.search2dArray(
      e,
      1,
      ["addHashedCookieDomain", "enableSecureCookie", "setTrackingGate"],
      t
    );
    this.tracker._initialize();
    hstc.utils.search2dArray(e, 1, hstc.tracking.Runner.priorityFunctions, t);
    hstc.utils.search2dArray(e, 1, ["trackPageView"], t);
    for (; e.length; ) t(e.shift());
  };
  !(function (t) {
    var e,
      n,
      i,
      r,
      o,
      s,
      a,
      c,
      u,
      l,
      h,
      d,
      f,
      p,
      g,
      m,
      y,
      k = "sizzle" + -new Date(),
      v = t.document,
      b = 0,
      w = 0,
      _ = rt(),
      C = rt(),
      S = rt(),
      T = !1,
      E = function (t, e) {
        if (t === e) {
          T = !0;
          return 0;
        }
        return 0;
      },
      x = "undefined",
      L = 1 << 31,
      I = {}.hasOwnProperty,
      N = [],
      D = N.pop,
      A = N.push,
      R = N.push,
      O = N.slice,
      P =
        N.indexOf ||
        function (t) {
          for (var e = 0, n = this.length; e < n; e++)
            if (this[e] === t) return e;
          return -1;
        },
      M =
        "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
      V = "[\\x20\\t\\r\\n\\f]",
      W = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
      F = W.replace("w", "w#"),
      H =
        "\\[" +
        V +
        "*(" +
        W +
        ")" +
        V +
        "*(?:([*^$|!~]?=)" +
        V +
        "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" +
        F +
        ")|)|)" +
        V +
        "*\\]",
      j =
        ":(" +
        W +
        ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" +
        H.replace(3, 8) +
        ")*)|.*)\\)|)",
      U = new RegExp("^" + V + "+|((?:^|[^\\\\])(?:\\\\.)*)" + V + "+$", "g"),
      G = new RegExp("^" + V + "*," + V + "*"),
      Y = new RegExp("^" + V + "*([>+~]|" + V + ")" + V + "*"),
      Z = new RegExp(V + "*[+~]"),
      B = new RegExp("=" + V + "*([^\\]'\"]*)" + V + "*\\]", "g"),
      X = new RegExp(j),
      z = new RegExp("^" + F + "$"),
      $ = {
        ID: new RegExp("^#(" + W + ")"),
        CLASS: new RegExp("^\\.(" + W + ")"),
        TAG: new RegExp("^(" + W.replace("w", "w*") + ")"),
        ATTR: new RegExp("^" + H),
        PSEUDO: new RegExp("^" + j),
        CHILD: new RegExp(
          "^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" +
            V +
            "*(even|odd|(([+-]|)(\\d*)n|)" +
            V +
            "*(?:([+-]|)" +
            V +
            "*(\\d+)|))" +
            V +
            "*\\)|)",
          "i"
        ),
        bool: new RegExp("^(?:" + M + ")$", "i"),
        needsContext: new RegExp(
          "^" +
            V +
            "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" +
            V +
            "*((?:-\\d)?\\d*)" +
            V +
            "*\\)|)(?=[^-]|$)",
          "i"
        ),
      },
      J = /^[^{]+\{\s*\[native \w/,
      K = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
      q = /^(?:input|select|textarea|button)$/i,
      Q = /^h\d$/i,
      tt = /'|\\/g,
      et = new RegExp("\\\\([\\da-f]{1,6}" + V + "?|(" + V + ")|.)", "ig"),
      nt = function (t, e, n) {
        var i = "0x" + e - 65536;
        return i != i || n
          ? e
          : i < 0
          ? String.fromCharCode(i + 65536)
          : String.fromCharCode((i >> 10) | 55296, (1023 & i) | 56320);
      };
    try {
      R.apply((N = O.call(v.childNodes)), v.childNodes);
      N[v.childNodes.length].nodeType;
    } catch (t) {
      R = {
        apply: N.length
          ? function (t, e) {
              A.apply(t, O.call(e));
            }
          : function (t, e) {
              for (var n = t.length, i = 0; (t[n++] = e[i++]); );
              t.length = n - 1;
            },
      };
    }
    function it(t, e, i, r) {
      var o, s, a, c, u, d, g, m, b, w;
      (e ? e.ownerDocument || e : v) !== h && l(e);
      i = i || [];
      if (!t || "string" != typeof t) return i;
      if (1 !== (c = (e = e || h).nodeType) && 9 !== c) return [];
      if (f && !r) {
        if ((o = K.exec(t)))
          if ((a = o[1])) {
            if (9 === c) {
              if (!(s = e.getElementById(a)) || !s.parentNode) return i;
              if (s.id === a) {
                i.push(s);
                return i;
              }
            } else if (
              e.ownerDocument &&
              (s = e.ownerDocument.getElementById(a)) &&
              y(e, s) &&
              s.id === a
            ) {
              i.push(s);
              return i;
            }
          } else {
            if (o[2]) {
              R.apply(i, e.getElementsByTagName(t));
              return i;
            }
            if (
              (a = o[3]) &&
              n.getElementsByClassName &&
              e.getElementsByClassName
            ) {
              R.apply(i, e.getElementsByClassName(a));
              return i;
            }
          }
        if (n.qsa && (!p || !p.test(t))) {
          m = g = k;
          b = e;
          w = 9 === c && t;
          if (1 === c && "object" !== e.nodeName.toLowerCase()) {
            d = ft(t);
            (g = e.getAttribute("id"))
              ? (m = g.replace(tt, "\\$&"))
              : e.setAttribute("id", m);
            m = "[id='" + m + "'] ";
            u = d.length;
            for (; u--; ) d[u] = m + pt(d[u]);
            b = (Z.test(t) && e.parentNode) || e;
            w = d.join(",");
          }
          if (w)
            try {
              R.apply(i, b.querySelectorAll(w));
              return i;
            } catch (t) {
            } finally {
              g || e.removeAttribute("id");
            }
        }
      }
      return _t(t.replace(U, "$1"), e, i, r);
    }
    function rt() {
      var t = [];
      function e(n, i) {
        t.push((n += " ")) > r.cacheLength && delete e[t.shift()];
        return (e[n] = i);
      }
      return e;
    }
    function ot(t) {
      t[k] = !0;
      return t;
    }
    function st(t) {
      var e = h.createElement("div");
      try {
        return !!t(e);
      } catch (t) {
        return !1;
      } finally {
        e.parentNode && e.parentNode.removeChild(e);
        e = null;
      }
    }
    function at(t, e) {
      for (var n = t.split("|"), i = t.length; i--; ) r.attrHandle[n[i]] = e;
    }
    function ct(t, e) {
      var n = e && t,
        i =
          n &&
          1 === t.nodeType &&
          1 === e.nodeType &&
          (~e.sourceIndex || L) - (~t.sourceIndex || L);
      if (i) return i;
      if (n) for (; (n = n.nextSibling); ) if (n === e) return -1;
      return t ? 1 : -1;
    }
    function ut(t) {
      return function (e) {
        return "input" === e.nodeName.toLowerCase() && e.type === t;
      };
    }
    function lt(t) {
      return function (e) {
        var n = e.nodeName.toLowerCase();
        return ("input" === n || "button" === n) && e.type === t;
      };
    }
    function ht(t) {
      return ot(function (e) {
        e = +e;
        return ot(function (n, i) {
          for (var r, o = t([], n.length, e), s = o.length; s--; )
            n[(r = o[s])] && (n[r] = !(i[r] = n[r]));
        });
      });
    }
    s = it.isXML = function (t) {
      var e = t && (t.ownerDocument || t).documentElement;
      return !!e && "HTML" !== e.nodeName;
    };
    n = it.support = {};
    l = it.setDocument = function (t) {
      var e = t ? t.ownerDocument || t : v,
        i = e.defaultView;
      if (e === h || 9 !== e.nodeType || !e.documentElement) return h;
      h = e;
      d = e.documentElement;
      f = !s(e);
      i &&
        i.attachEvent &&
        i !== i.top &&
        i.attachEvent("onbeforeunload", function () {
          l();
        });
      n.attributes = st(function (t) {
        t.className = "i";
        return !t.getAttribute("className");
      });
      n.getElementsByTagName = st(function (t) {
        t.appendChild(e.createComment(""));
        return !t.getElementsByTagName("*").length;
      });
      n.getElementsByClassName = st(function (t) {
        t.innerHTML = "<div class='a'></div><div class='a i'></div>";
        t.firstChild.className = "i";
        return 2 === t.getElementsByClassName("i").length;
      });
      n.getById = st(function (t) {
        d.appendChild(t).id = k;
        return !e.getElementsByName || !e.getElementsByName(k).length;
      });
      if (n.getById) {
        r.find.ID = function (t, e) {
          if (typeof e.getElementById !== x && f) {
            var n = e.getElementById(t);
            return n && n.parentNode ? [n] : [];
          }
        };
        r.filter.ID = function (t) {
          var e = t.replace(et, nt);
          return function (t) {
            return t.getAttribute("id") === e;
          };
        };
      } else {
        delete r.find.ID;
        r.filter.ID = function (t) {
          var e = t.replace(et, nt);
          return function (t) {
            var n = typeof t.getAttributeNode !== x && t.getAttributeNode("id");
            return n && n.value === e;
          };
        };
      }
      r.find.TAG = n.getElementsByTagName
        ? function (t, e) {
            if (typeof e.getElementsByTagName !== x)
              return e.getElementsByTagName(t);
          }
        : function (t, e) {
            var n,
              i = [],
              r = 0,
              o = e.getElementsByTagName(t);
            if ("*" === t) {
              for (; (n = o[r++]); ) 1 === n.nodeType && i.push(n);
              return i;
            }
            return o;
          };
      r.find.CLASS =
        n.getElementsByClassName &&
        function (t, e) {
          if (typeof e.getElementsByClassName !== x && f)
            return e.getElementsByClassName(t);
        };
      g = [];
      p = [];
      if ((n.qsa = J.test(e.querySelectorAll))) {
        st(function (t) {
          t.innerHTML = "<select><option selected=''></option></select>";
          t.querySelectorAll("[selected]").length ||
            p.push("\\[" + V + "*(?:value|" + M + ")");
          t.querySelectorAll(":checked").length || p.push(":checked");
        });
        st(function (t) {
          var n = e.createElement("input");
          n.setAttribute("type", "hidden");
          t.appendChild(n).setAttribute("t", "");
          t.querySelectorAll("[t^='']").length &&
            p.push("[*^$]=" + V + "*(?:''|\"\")");
          t.querySelectorAll(":enabled").length ||
            p.push(":enabled", ":disabled");
          t.querySelectorAll("*,:x");
          p.push(",.*:");
        });
      }
      (n.matchesSelector = J.test(
        (m =
          d.webkitMatchesSelector ||
          d.mozMatchesSelector ||
          d.oMatchesSelector ||
          d.msMatchesSelector)
      )) &&
        st(function (t) {
          n.disconnectedMatch = m.call(t, "div");
          m.call(t, "[s!='']:x");
          g.push("!=", j);
        });
      p = p.length && new RegExp(p.join("|"));
      g = g.length && new RegExp(g.join("|"));
      y =
        J.test(d.contains) || d.compareDocumentPosition
          ? function (t, e) {
              var n = 9 === t.nodeType ? t.documentElement : t,
                i = e && e.parentNode;
              return (
                t === i ||
                !(
                  !i ||
                  1 !== i.nodeType ||
                  !(n.contains
                    ? n.contains(i)
                    : t.compareDocumentPosition &&
                      16 & t.compareDocumentPosition(i))
                )
              );
            }
          : function (t, e) {
              if (e) for (; (e = e.parentNode); ) if (e === t) return !0;
              return !1;
            };
      E = d.compareDocumentPosition
        ? function (t, i) {
            if (t === i) {
              T = !0;
              return 0;
            }
            var r =
              i.compareDocumentPosition &&
              t.compareDocumentPosition &&
              t.compareDocumentPosition(i);
            return r
              ? 1 & r || (!n.sortDetached && i.compareDocumentPosition(t) === r)
                ? t === e || y(v, t)
                  ? -1
                  : i === e || y(v, i)
                  ? 1
                  : u
                  ? P.call(u, t) - P.call(u, i)
                  : 0
                : 4 & r
                ? -1
                : 1
              : t.compareDocumentPosition
              ? -1
              : 1;
          }
        : function (t, n) {
            var i,
              r = 0,
              o = t.parentNode,
              s = n.parentNode,
              a = [t],
              c = [n];
            if (t === n) {
              T = !0;
              return 0;
            }
            if (!o || !s)
              return t === e
                ? -1
                : n === e
                ? 1
                : o
                ? -1
                : s
                ? 1
                : u
                ? P.call(u, t) - P.call(u, n)
                : 0;
            if (o === s) return ct(t, n);
            i = t;
            for (; (i = i.parentNode); ) a.unshift(i);
            i = n;
            for (; (i = i.parentNode); ) c.unshift(i);
            for (; a[r] === c[r]; ) r++;
            return r ? ct(a[r], c[r]) : a[r] === v ? -1 : c[r] === v ? 1 : 0;
          };
      return e;
    };
    it.matches = function (t, e) {
      return it(t, null, null, e);
    };
    it.matchesSelector = function (t, e) {
      (t.ownerDocument || t) !== h && l(t);
      e = e.replace(B, "='$1']");
      if (n.matchesSelector && f && (!g || !g.test(e)) && (!p || !p.test(e)))
        try {
          var i = m.call(t, e);
          if (
            i ||
            n.disconnectedMatch ||
            (t.document && 11 !== t.document.nodeType)
          )
            return i;
        } catch (t) {}
      return it(e, h, null, [t]).length > 0;
    };
    it.contains = function (t, e) {
      (t.ownerDocument || t) !== h && l(t);
      return y(t, e);
    };
    it.attr = function (t, e) {
      (t.ownerDocument || t) !== h && l(t);
      var i = r.attrHandle[e.toLowerCase()],
        o = i && I.call(r.attrHandle, e.toLowerCase()) ? i(t, e, !f) : void 0;
      return void 0 === o
        ? n.attributes || !f
          ? t.getAttribute(e)
          : (o = t.getAttributeNode(e)) && o.specified
          ? o.value
          : null
        : o;
    };
    it.error = function (t) {
      throw new Error("Syntax error, unrecognized expression: " + t);
    };
    it.uniqueSort = function (t) {
      var e,
        i = [],
        r = 0,
        o = 0;
      T = !n.detectDuplicates;
      u = !n.sortStable && t.slice(0);
      t.sort(E);
      if (T) {
        for (; (e = t[o++]); ) e === t[o] && (r = i.push(o));
        for (; r--; ) t.splice(i[r], 1);
      }
      return t;
    };
    o = it.getText = function (t) {
      var e,
        n = "",
        i = 0,
        r = t.nodeType;
      if (r) {
        if (1 === r || 9 === r || 11 === r) {
          if ("string" == typeof t.textContent) return t.textContent;
          for (t = t.firstChild; t; t = t.nextSibling) n += o(t);
        } else if (3 === r || 4 === r) return t.nodeValue;
      } else for (; (e = t[i]); i++) n += o(e);
      return n;
    };
    r = it.selectors = {
      cacheLength: 50,
      createPseudo: ot,
      match: $,
      attrHandle: {},
      find: {},
      relative: {
        ">": { dir: "parentNode", first: !0 },
        " ": { dir: "parentNode" },
        "+": { dir: "previousSibling", first: !0 },
        "~": { dir: "previousSibling" },
      },
      preFilter: {
        ATTR: function (t) {
          t[1] = t[1].replace(et, nt);
          t[3] = (t[4] || t[5] || "").replace(et, nt);
          "~=" === t[2] && (t[3] = " " + t[3] + " ");
          return t.slice(0, 4);
        },
        CHILD: function (t) {
          t[1] = t[1].toLowerCase();
          if ("nth" === t[1].slice(0, 3)) {
            t[3] || it.error(t[0]);
            t[4] = +(t[4]
              ? t[5] + (t[6] || 1)
              : 2 * ("even" === t[3] || "odd" === t[3]));
            t[5] = +(t[7] + t[8] || "odd" === t[3]);
          } else t[3] && it.error(t[0]);
          return t;
        },
        PSEUDO: function (t) {
          var e,
            n = !t[5] && t[2];
          if ($.CHILD.test(t[0])) return null;
          if (t[3] && void 0 !== t[4]) t[2] = t[4];
          else if (
            n &&
            X.test(n) &&
            (e = ft(n, !0)) &&
            (e = n.indexOf(")", n.length - e) - n.length)
          ) {
            t[0] = t[0].slice(0, e);
            t[2] = n.slice(0, e);
          }
          return t.slice(0, 3);
        },
      },
      filter: {
        TAG: function (t) {
          var e = t.replace(et, nt).toLowerCase();
          return "*" === t
            ? function () {
                return !0;
              }
            : function (t) {
                return t.nodeName && t.nodeName.toLowerCase() === e;
              };
        },
        CLASS: function (t) {
          var e = _[t + " "];
          return (
            e ||
            ((e = new RegExp("(^|" + V + ")" + t + "(" + V + "|$)")) &&
              _(t, function (t) {
                return e.test(
                  ("string" == typeof t.className && t.className) ||
                    (typeof t.getAttribute !== x && t.getAttribute("class")) ||
                    ""
                );
              }))
          );
        },
        ATTR: function (t, e, n) {
          return function (i) {
            var r = it.attr(i, t);
            if (null == r) return "!=" === e;
            if (!e) return !0;
            r += "";
            return "=" === e
              ? r === n
              : "!=" === e
              ? r !== n
              : "^=" === e
              ? n && 0 === r.indexOf(n)
              : "*=" === e
              ? n && r.indexOf(n) > -1
              : "$=" === e
              ? n && r.slice(-n.length) === n
              : "~=" === e
              ? (" " + r + " ").indexOf(n) > -1
              : "|=" === e && (r === n || r.slice(0, n.length + 1) === n + "-");
          };
        },
        CHILD: function (t, e, n, i, r) {
          var o = "nth" !== t.slice(0, 3),
            s = "last" !== t.slice(-4),
            a = "of-type" === e;
          return 1 === i && 0 === r
            ? function (t) {
                return !!t.parentNode;
              }
            : function (e, n, c) {
                var u,
                  l,
                  h,
                  d,
                  f,
                  p,
                  g = o !== s ? "nextSibling" : "previousSibling",
                  m = e.parentNode,
                  y = a && e.nodeName.toLowerCase(),
                  v = !c && !a;
                if (m) {
                  if (o) {
                    for (; g; ) {
                      h = e;
                      for (; (h = h[g]); )
                        if (
                          a ? h.nodeName.toLowerCase() === y : 1 === h.nodeType
                        )
                          return !1;
                      p = g = "only" === t && !p && "nextSibling";
                    }
                    return !0;
                  }
                  p = [s ? m.firstChild : m.lastChild];
                  if (s && v) {
                    f =
                      (u = (l = m[k] || (m[k] = {}))[t] || [])[0] === b && u[1];
                    d = u[0] === b && u[2];
                    h = f && m.childNodes[f];
                    for (; (h = (++f && h && h[g]) || (d = f = 0) || p.pop()); )
                      if (1 === h.nodeType && ++d && h === e) {
                        l[t] = [b, f, d];
                        break;
                      }
                  } else if (v && (u = (e[k] || (e[k] = {}))[t]) && u[0] === b)
                    d = u[1];
                  else
                    for (; (h = (++f && h && h[g]) || (d = f = 0) || p.pop()); )
                      if (
                        (a
                          ? h.nodeName.toLowerCase() === y
                          : 1 === h.nodeType) &&
                        ++d
                      ) {
                        v && ((h[k] || (h[k] = {}))[t] = [b, d]);
                        if (h === e) break;
                      }
                  return (d -= r) === i || (d % i == 0 && d / i >= 0);
                }
              };
        },
        PSEUDO: function (t, e) {
          var n,
            i =
              r.pseudos[t] ||
              r.setFilters[t.toLowerCase()] ||
              it.error("unsupported pseudo: " + t);
          if (i[k]) return i(e);
          if (i.length > 1) {
            n = [t, t, "", e];
            return r.setFilters.hasOwnProperty(t.toLowerCase())
              ? ot(function (t, n) {
                  for (var r, o = i(t, e), s = o.length; s--; )
                    t[(r = P.call(t, o[s]))] = !(n[r] = o[s]);
                })
              : function (t) {
                  return i(t, 0, n);
                };
          }
          return i;
        },
      },
      pseudos: {
        not: ot(function (t) {
          var e = [],
            n = [],
            i = a(t.replace(U, "$1"));
          return i[k]
            ? ot(function (t, e, n, r) {
                for (var o, s = i(t, null, r, []), a = t.length; a--; )
                  (o = s[a]) && (t[a] = !(e[a] = o));
              })
            : function (t, r, o) {
                e[0] = t;
                i(e, null, o, n);
                return !n.pop();
              };
        }),
        has: ot(function (t) {
          return function (e) {
            return it(t, e).length > 0;
          };
        }),
        contains: ot(function (t) {
          return function (e) {
            return (e.textContent || e.innerText || o(e)).indexOf(t) > -1;
          };
        }),
        lang: ot(function (t) {
          z.test(t || "") || it.error("unsupported lang: " + t);
          t = t.replace(et, nt).toLowerCase();
          return function (e) {
            var n;
            do {
              if (
                (n = f
                  ? e.lang
                  : e.getAttribute("xml:lang") || e.getAttribute("lang"))
              )
                return (n = n.toLowerCase()) === t || 0 === n.indexOf(t + "-");
            } while ((e = e.parentNode) && 1 === e.nodeType);
            return !1;
          };
        }),
        target: function (e) {
          var n = t.location && t.location.hash;
          return n && n.slice(1) === e.id;
        },
        root: function (t) {
          return t === d;
        },
        focus: function (t) {
          return (
            t === h.activeElement &&
            (!h.hasFocus || h.hasFocus()) &&
            !!(t.type || t.href || ~t.tabIndex)
          );
        },
        enabled: function (t) {
          return !1 === t.disabled;
        },
        disabled: function (t) {
          return !0 === t.disabled;
        },
        checked: function (t) {
          var e = t.nodeName.toLowerCase();
          return (
            ("input" === e && !!t.checked) || ("option" === e && !!t.selected)
          );
        },
        selected: function (t) {
          t.parentNode && t.parentNode.selectedIndex;
          return !0 === t.selected;
        },
        empty: function (t) {
          for (t = t.firstChild; t; t = t.nextSibling)
            if (t.nodeName > "@" || 3 === t.nodeType || 4 === t.nodeType)
              return !1;
          return !0;
        },
        parent: function (t) {
          return !r.pseudos.empty(t);
        },
        header: function (t) {
          return Q.test(t.nodeName);
        },
        input: function (t) {
          return q.test(t.nodeName);
        },
        button: function (t) {
          var e = t.nodeName.toLowerCase();
          return ("input" === e && "button" === t.type) || "button" === e;
        },
        text: function (t) {
          var e;
          return (
            "input" === t.nodeName.toLowerCase() &&
            "text" === t.type &&
            (null == (e = t.getAttribute("type")) || e.toLowerCase() === t.type)
          );
        },
        first: ht(function () {
          return [0];
        }),
        last: ht(function (t, e) {
          return [e - 1];
        }),
        eq: ht(function (t, e, n) {
          return [n < 0 ? n + e : n];
        }),
        even: ht(function (t, e) {
          for (var n = 0; n < e; n += 2) t.push(n);
          return t;
        }),
        odd: ht(function (t, e) {
          for (var n = 1; n < e; n += 2) t.push(n);
          return t;
        }),
        lt: ht(function (t, e, n) {
          for (var i = n < 0 ? n + e : n; --i >= 0; ) t.push(i);
          return t;
        }),
        gt: ht(function (t, e, n) {
          for (var i = n < 0 ? n + e : n; ++i < e; ) t.push(i);
          return t;
        }),
      },
    };
    r.pseudos.nth = r.pseudos.eq;
    for (e in { radio: !0, checkbox: !0, file: !0, password: !0, image: !0 })
      r.pseudos[e] = ut(e);
    for (e in { submit: !0, reset: !0 }) r.pseudos[e] = lt(e);
    function dt() {}
    dt.prototype = r.filters = r.pseudos;
    r.setFilters = new dt();
    function ft(t, e) {
      var n,
        i,
        o,
        s,
        a,
        c,
        u,
        l = C[t + " "];
      if (l) return e ? 0 : l.slice(0);
      a = t;
      c = [];
      u = r.preFilter;
      for (; a; ) {
        if (!n || (i = G.exec(a))) {
          i && (a = a.slice(i[0].length) || a);
          c.push((o = []));
        }
        n = !1;
        if ((i = Y.exec(a))) {
          n = i.shift();
          o.push({ value: n, type: i[0].replace(U, " ") });
          a = a.slice(n.length);
        }
        for (s in r.filter)
          if ((i = $[s].exec(a)) && (!u[s] || (i = u[s](i)))) {
            n = i.shift();
            o.push({ value: n, type: s, matches: i });
            a = a.slice(n.length);
          }
        if (!n) break;
      }
      return e ? a.length : a ? it.error(t) : C(t, c).slice(0);
    }
    function pt(t) {
      for (var e = 0, n = t.length, i = ""; e < n; e++) i += t[e].value;
      return i;
    }
    function gt(t, e, n) {
      var r = e.dir,
        o = n && "parentNode" === r,
        s = w++;
      return e.first
        ? function (e, n, i) {
            for (; (e = e[r]); ) if (1 === e.nodeType || o) return t(e, n, i);
          }
        : function (e, n, a) {
            var c,
              u,
              l,
              h = b + " " + s;
            if (a) {
              for (; (e = e[r]); )
                if ((1 === e.nodeType || o) && t(e, n, a)) return !0;
            } else
              for (; (e = e[r]); )
                if (1 === e.nodeType || o)
                  if ((u = (l = e[k] || (e[k] = {}))[r]) && u[0] === h) {
                    if (!0 === (c = u[1]) || c === i) return !0 === c;
                  } else {
                    (u = l[r] = [h])[1] = t(e, n, a) || i;
                    if (!0 === u[1]) return !0;
                  }
          };
    }
    function mt(t) {
      return t.length > 1
        ? function (e, n, i) {
            for (var r = t.length; r--; ) if (!t[r](e, n, i)) return !1;
            return !0;
          }
        : t[0];
    }
    function yt(t, e, n, i, r) {
      for (var o, s = [], a = 0, c = t.length, u = null != e; a < c; a++)
        if ((o = t[a]) && (!n || n(o, i, r))) {
          s.push(o);
          u && e.push(a);
        }
      return s;
    }
    function kt(t, e, n, i, r, o) {
      i && !i[k] && (i = kt(i));
      r && !r[k] && (r = kt(r, o));
      return ot(function (o, s, a, c) {
        var u,
          l,
          h,
          d = [],
          f = [],
          p = s.length,
          g = o || wt(e || "*", a.nodeType ? [a] : a, []),
          m = !t || (!o && e) ? g : yt(g, d, t, a, c),
          y = n ? (r || (o ? t : p || i) ? [] : s) : m;
        n && n(m, y, a, c);
        if (i) {
          u = yt(y, f);
          i(u, [], a, c);
          l = u.length;
          for (; l--; ) (h = u[l]) && (y[f[l]] = !(m[f[l]] = h));
        }
        if (o) {
          if (r || t) {
            if (r) {
              u = [];
              l = y.length;
              for (; l--; ) (h = y[l]) && u.push((m[l] = h));
              r(null, (y = []), u, c);
            }
            l = y.length;
            for (; l--; )
              (h = y[l]) &&
                (u = r ? P.call(o, h) : d[l]) > -1 &&
                (o[u] = !(s[u] = h));
          }
        } else {
          y = yt(y === s ? y.splice(p, y.length) : y);
          r ? r(null, s, y, c) : R.apply(s, y);
        }
      });
    }
    function vt(t) {
      for (
        var e,
          n,
          i,
          o = t.length,
          s = r.relative[t[0].type],
          a = s || r.relative[" "],
          u = s ? 1 : 0,
          l = gt(
            function (t) {
              return t === e;
            },
            a,
            !0
          ),
          h = gt(
            function (t) {
              return P.call(e, t) > -1;
            },
            a,
            !0
          ),
          d = [
            function (t, n, i) {
              return (
                (!s && (i || n !== c)) ||
                ((e = n).nodeType ? l(t, n, i) : h(t, n, i))
              );
            },
          ];
        u < o;
        u++
      )
        if ((n = r.relative[t[u].type])) d = [gt(mt(d), n)];
        else {
          if ((n = r.filter[t[u].type].apply(null, t[u].matches))[k]) {
            i = ++u;
            for (; i < o && !r.relative[t[i].type]; i++);
            return kt(
              u > 1 && mt(d),
              u > 1 &&
                pt(
                  t
                    .slice(0, u - 1)
                    .concat({ value: " " === t[u - 2].type ? "*" : "" })
                ).replace(U, "$1"),
              n,
              u < i && vt(t.slice(u, i)),
              i < o && vt((t = t.slice(i))),
              i < o && pt(t)
            );
          }
          d.push(n);
        }
      return mt(d);
    }
    function bt(t, e) {
      var n = 0,
        o = e.length > 0,
        s = t.length > 0,
        a = function (a, u, l, d, f) {
          var p,
            g,
            m,
            y = [],
            k = 0,
            v = "0",
            w = a && [],
            _ = null != f,
            C = c,
            S = a || (s && r.find.TAG("*", (f && u.parentNode) || u)),
            T = (b += null == C ? 1 : Math.random() || 0.1),
            E = S.length;
          if (_) {
            c = u !== h && u;
            i = n;
          }
          for (; v !== E && null != (p = S[v]); v++) {
            if (s && p) {
              g = 0;
              for (; (m = t[g++]); )
                if (m(p, u, l)) {
                  d.push(p);
                  break;
                }
              if (_) {
                b = T;
                i = ++n;
              }
            }
            if (o) {
              (p = !m && p) && k--;
              a && w.push(p);
            }
          }
          k += v;
          if (o && v !== k) {
            g = 0;
            for (; (m = e[g++]); ) m(w, y, u, l);
            if (a) {
              if (k > 0) for (; v--; ) w[v] || y[v] || (y[v] = D.call(d));
              y = yt(y);
            }
            R.apply(d, y);
            _ && !a && y.length > 0 && k + e.length > 1 && it.uniqueSort(d);
          }
          if (_) {
            b = T;
            c = C;
          }
          return w;
        };
      return o ? ot(a) : a;
    }
    a = it.compile = function (t, e) {
      var n,
        i = [],
        r = [],
        o = S[t + " "];
      if (!o) {
        e || (e = ft(t));
        n = e.length;
        for (; n--; ) (o = vt(e[n]))[k] ? i.push(o) : r.push(o);
        o = S(t, bt(r, i));
      }
      return o;
    };
    function wt(t, e, n) {
      for (var i = 0, r = e.length; i < r; i++) it(t, e[i], n);
      return n;
    }
    function _t(t, e, i, o) {
      var s,
        c,
        u,
        l,
        h,
        d = ft(t);
      if (!o && 1 === d.length) {
        if (
          (c = d[0] = d[0].slice(0)).length > 2 &&
          "ID" === (u = c[0]).type &&
          n.getById &&
          9 === e.nodeType &&
          f &&
          r.relative[c[1].type]
        ) {
          if (!(e = (r.find.ID(u.matches[0].replace(et, nt), e) || [])[0]))
            return i;
          t = t.slice(c.shift().value.length);
        }
        s = $.needsContext.test(t) ? 0 : c.length;
        for (; s--; ) {
          u = c[s];
          if (r.relative[(l = u.type)]) break;
          if (
            (h = r.find[l]) &&
            (o = h(
              u.matches[0].replace(et, nt),
              (Z.test(c[0].type) && e.parentNode) || e
            ))
          ) {
            c.splice(s, 1);
            if (!(t = o.length && pt(c))) {
              R.apply(i, o);
              return i;
            }
            break;
          }
        }
      }
      a(t, d)(o, e, !f, i, Z.test(t));
      return i;
    }
    n.sortStable = k.split("").sort(E).join("") === k;
    n.detectDuplicates = T;
    l();
    n.sortDetached = st(function (t) {
      return 1 & t.compareDocumentPosition(h.createElement("div"));
    });
    st(function (t) {
      t.innerHTML = "<a href='#'></a>";
      return "#" === t.firstChild.getAttribute("href");
    }) ||
      at("type|href|height|width", function (t, e, n) {
        if (!n) return t.getAttribute(e, "type" === e.toLowerCase() ? 1 : 2);
      });
    (n.attributes &&
      st(function (t) {
        t.innerHTML = "<input/>";
        t.firstChild.setAttribute("value", "");
        return "" === t.firstChild.getAttribute("value");
      })) ||
      at("value", function (t, e, n) {
        if (!n && "input" === t.nodeName.toLowerCase()) return t.defaultValue;
      });
    st(function (t) {
      return null == t.getAttribute("disabled");
    }) ||
      at(M, function (t, e, n) {
        var i;
        if (!n)
          return !0 === t[e]
            ? e.toLowerCase()
            : (i = t.getAttributeNode(e)) && i.specified
            ? i.value
            : null;
      });
    function Ct(t) {
      if (!t) return null;
      var e = /\[\w+(\*|\$|\||~|!|\^)?=(.+)]/,
        n = e.test(t);
      if (n && (n = e.exec(t)) && 3 == n.length) {
        var i = /".+"/;
        if (!/'.+'/.test(n[2]) && !i.test(n[2]))
          return t.replace("=" + n[2], "='" + n[2] + "'");
      }
    }
    hstc.find = function () {
      try {
        return it.apply(null, arguments);
      } catch (e) {
        var t = Ct(arguments[0]);
        if (t) {
          arguments[0] = t;
          return it.apply(null, arguments);
        }
        throw e;
      }
    };
    hstc.expr = it.selectors;
    hstc.expr[":"] = hstc.expr.filters;
    hstc.unique = it.uniqueSort;
    hstc.text = it.getText;
    hstc.isXMLDoc = it.isXML;
    hstc.contains = it.contains;
  })(window);
  (hstc = hstc || {}).unsizzle = (function () {
    const t = /^(\D+)(-|_)(?:.+)(_)/g;
    function e(e) {
      const n = e.match(t);
      return (n && n[0]) || null;
    }
    function n(t) {
      return e(t) || t;
    }
    const i = {
      userInteractionClasses: new RegExp(
        "^" +
          [
            "((is|has)-?)?(enable|disable|collapse|require|close)d?",
            "((is|has)-?)?(expand|select|visit|check|focus|press)(ed)?",
            "((is|has)-?)?(active|hidden|open|(in)?(visible|valid)|optional|read-only)",
            "(hover|target|outline|show|hide|autofill|sfhover)",
            "((is|has)-?)?(fade|slide|zoom|bounce|flip)-(in|out|up|down|left|right)",
            "(aria|sr)-(expanded|selected|checked|pressed|current|hidden|live)",
            "(hover|focus|focus-within|focus-visible|active|target):[\\w-]+",
            "(visited|disabled|enabled|empty|open|closed):[\\w-]+",
            "(btn|form|nav|dropdown|modal|tooltip|popover)-(active|disabled|focus|hover)",
            "(mui|uk)-(active|checked|disabled|error|expanded|focused|required|selected)",
          ].join("|") +
          "$",
        "gi"
      ),
      event: function (t) {
        return i.node(t.target);
      },
      node: function (t) {
        const e = [];
        let n = !0,
          r = t;
        for (; n; ) {
          if (
            r.id.length ||
            null == r.parentElement ||
            r.parentNode === document ||
            "HTML" === r.parentElement.tagName
          ) {
            e.unshift(i.selector(r));
            n = !1;
          } else {
            e.unshift("> " + i.selector(r));
            r = r.parentElement;
          }
        }
        return e.join(" ");
      },
      selector: function (t) {
        const e = i.join(t.tagName, t.id, t.classList),
          n = i.join(t.tagName, t.id);
        if (t.parentNode !== document && i.hasSiblings(t) && !t.id) {
          let e = 0,
            r = !1,
            o = 0;
          const s = (t.parentNode && Array.from(t.parentNode.children)) || [];
          for (let n = 0; n < s.length; n++) {
            const a = s[n];
            a !== t && i.hasDuplicateClassLists(t, a) && !r && (r = !0);
            a.tagName === t.tagName && (e += 1);
            t && a === t && (o = e);
          }
          if (r && e > 1) return n + ":nth-of-type(" + o + ")";
        }
        return e;
      },
      join: function (t, e, r) {
        let o = "",
          s = "";
        const a =
          r && r.length > 0
            ? i.filterUserInteractionClasses(Array.from(r || []))
            : [];
        if (e.length)
          if (-1 !== e.indexOf("hsForm")) {
            o = '[id*="' + n(e) + '"]';
          } else if (-1 !== a.indexOf("hs-input")) {
            o = '[id*="' + n(e) + '"]';
          } else o = "#" + e;
        if (a.length > 0) {
          -1 !== a.indexOf("hs-form")
            ? (s += '[class*="hs-form"]')
            : (s += "." + a.join("."));
          s = s.replace(i.userInteractionClasses, "");
        }
        return t.toLowerCase() + o + s;
      },
      hasDuplicateClassLists: function (t, e) {
        const n = i.filterUserInteractionClasses(Array.from(t.classList)),
          r = i.filterUserInteractionClasses(Array.from(e.classList));
        return t.tagName === e.tagName && n.toString() === r.toString();
      },
      filterUserInteractionClasses: function (t) {
        return t.filter(function (t) {
          return !t.match(i.userInteractionClasses);
        });
      },
      hasSiblings: function (t) {
        return t.parentNode && t.parentNode.children.length > 1;
      },
      isEvent: function (t) {
        return t && null != t.currentTarget;
      },
      isNode: function (t) {
        return "object" == typeof Node
          ? t instanceof Node
          : t &&
              "object" == typeof t &&
              "number" == typeof t.nodeType &&
              "string" == typeof t.nodeName;
      },
      unsizzle: function (t) {
        return i.isEvent(t) ? i.event(t) : i.isNode(t) ? i.node(t) : null;
      },
      getHsFormElementMatches: e,
      getFuzzyMatchUsingRegex: n,
    };
    return i.unsizzle;
  })();
  !(function (t, e, n) {
    hstc["Fingerprint"] = n();
  })(0, 0, function () {
    "use strict";
    var t = (function (t) {
      var e = "5.0.1";
      function n(t, e) {
        return new Promise((n) => setTimeout(n, t, e));
      }
      function i() {
        return new Promise((t) => {
          const e = new MessageChannel();
          e.port1.onmessage = () => t();
          e.port2.postMessage(null);
        });
      }
      function r(t, e = 1 / 0) {
        const { requestIdleCallback: i } = window;
        return i
          ? new Promise((t) => i.call(window, () => t(), { timeout: e }))
          : n(Math.min(t, e));
      }
      function o(t) {
        return !!t && "function" == typeof t.then;
      }
      function s(t, e) {
        try {
          const n = t();
          o(n)
            ? n.then(
                (t) => e(!0, t),
                (t) => e(!1, t)
              )
            : e(!0, n);
        } catch (t) {
          e(!1, t);
        }
      }
      async function a(t, e, n = 16) {
        const r = Array(t.length);
        let o = Date.now();
        for (let s = 0; s < t.length; ++s) {
          r[s] = e(t[s], s);
          const a = Date.now();
          if (a >= o + n) {
            o = a;
            await i();
          }
        }
        return r;
      }
      function c(t) {
        t.then(void 0, () => {});
        return t;
      }
      function u(t, e) {
        for (let n = 0, i = t.length; n < i; ++n) if (t[n] === e) return !0;
        return !1;
      }
      function l(t, e) {
        return !u(t, e);
      }
      function h(t) {
        return parseInt(t, 10);
      }
      function d(t) {
        return parseFloat(t);
      }
      function f(t, e) {
        return "number" == typeof t && isNaN(t) ? e : t;
      }
      function p(t) {
        return t.reduce((t, e) => t + (e ? 1 : 0), 0);
      }
      function g(t, e = 1) {
        if (Math.abs(e) >= 1) return Math.round(t / e) * e;
        {
          const n = 1 / e;
          return Math.round(t * n) / n;
        }
      }
      function m(t) {
        var e, n;
        const i = `Unexpected syntax '${t}'`,
          r = /^\s*([a-z-]*)(.*)$/i.exec(t),
          o = r[1] || void 0,
          s = {},
          a = /([.:#][\w-]+|\[.+?\])/gi,
          c = (t, e) => {
            s[t] = s[t] || [];
            s[t].push(e);
          };
        for (;;) {
          const t = a.exec(r[2]);
          if (!t) break;
          const o = t[0];
          switch (o[0]) {
            case ".":
              c("class", o.slice(1));
              break;
            case "#":
              c("id", o.slice(1));
              break;
            case "[": {
              const t =
                /^\[([\w-]+)([~|^$*]?=("(.*?)"|([\w-]+)))?(\s+[is])?\]$/.exec(
                  o
                );
              if (!t) throw new Error(i);
              c(
                t[1],
                null !== (n = null !== (e = t[4]) && void 0 !== e ? e : t[5]) &&
                  void 0 !== n
                  ? n
                  : ""
              );
              break;
            }
            default:
              throw new Error(i);
          }
        }
        return [o, s];
      }
      function y(t) {
        const e = new Uint8Array(t.length);
        for (let n = 0; n < t.length; n++) {
          const i = t.charCodeAt(n);
          if (i > 127) return new TextEncoder().encode(t);
          e[n] = i;
        }
        return e;
      }
      function k(t, e) {
        const n = t[0] >>> 16,
          i = 65535 & t[0],
          r = t[1] >>> 16,
          o = 65535 & t[1],
          s = e[0] >>> 16,
          a = 65535 & e[0],
          c = e[1] >>> 16;
        let u = 0,
          l = 0,
          h = 0,
          d = 0;
        d += o + (65535 & e[1]);
        h += d >>> 16;
        d &= 65535;
        h += r + c;
        l += h >>> 16;
        h &= 65535;
        l += i + a;
        u += l >>> 16;
        l &= 65535;
        u += n + s;
        u &= 65535;
        t[0] = (u << 16) | l;
        t[1] = (h << 16) | d;
      }
      function v(t, e) {
        const n = t[0] >>> 16,
          i = 65535 & t[0],
          r = t[1] >>> 16,
          o = 65535 & t[1],
          s = e[0] >>> 16,
          a = 65535 & e[0],
          c = e[1] >>> 16,
          u = 65535 & e[1];
        let l = 0,
          h = 0,
          d = 0,
          f = 0;
        f += o * u;
        d += f >>> 16;
        f &= 65535;
        d += r * u;
        h += d >>> 16;
        d &= 65535;
        d += o * c;
        h += d >>> 16;
        d &= 65535;
        h += i * u;
        l += h >>> 16;
        h &= 65535;
        h += r * c;
        l += h >>> 16;
        h &= 65535;
        h += o * a;
        l += h >>> 16;
        h &= 65535;
        l += n * u + i * c + r * a + o * s;
        l &= 65535;
        t[0] = (l << 16) | h;
        t[1] = (d << 16) | f;
      }
      function b(t, e) {
        const n = t[0];
        if (32 === (e %= 64)) {
          t[0] = t[1];
          t[1] = n;
        } else if (e < 32) {
          t[0] = (n << e) | (t[1] >>> (32 - e));
          t[1] = (t[1] << e) | (n >>> (32 - e));
        } else {
          e -= 32;
          t[0] = (t[1] << e) | (n >>> (32 - e));
          t[1] = (n << e) | (t[1] >>> (32 - e));
        }
      }
      function w(t, e) {
        if (0 !== (e %= 64))
          if (e < 32) {
            t[0] = t[1] >>> (32 - e);
            t[1] = t[1] << e;
          } else {
            t[0] = t[1] << (e - 32);
            t[1] = 0;
          }
      }
      function _(t, e) {
        t[0] ^= e[0];
        t[1] ^= e[1];
      }
      const C = [4283543511, 3981806797],
        S = [3301882366, 444984403];
      function T(t) {
        const e = [0, t[0] >>> 1];
        _(t, e);
        v(t, C);
        e[1] = t[0] >>> 1;
        _(t, e);
        v(t, S);
        e[1] = t[0] >>> 1;
        _(t, e);
      }
      const E = [2277735313, 289559509],
        x = [1291169091, 658871167],
        L = [0, 5],
        I = [0, 1390208809],
        N = [0, 944331445];
      function D(t, e) {
        const n = y(t);
        e = e || 0;
        const i = [0, n.length],
          r = i[1] % 16,
          o = i[1] - r,
          s = [0, e],
          a = [0, e],
          c = [0, 0],
          u = [0, 0];
        let l;
        for (l = 0; l < o; l += 16) {
          c[0] =
            n[l + 4] | (n[l + 5] << 8) | (n[l + 6] << 16) | (n[l + 7] << 24);
          c[1] = n[l] | (n[l + 1] << 8) | (n[l + 2] << 16) | (n[l + 3] << 24);
          u[0] =
            n[l + 12] |
            (n[l + 13] << 8) |
            (n[l + 14] << 16) |
            (n[l + 15] << 24);
          u[1] =
            n[l + 8] | (n[l + 9] << 8) | (n[l + 10] << 16) | (n[l + 11] << 24);
          v(c, E);
          b(c, 31);
          v(c, x);
          _(s, c);
          b(s, 27);
          k(s, a);
          v(s, L);
          k(s, I);
          v(u, x);
          b(u, 33);
          v(u, E);
          _(a, u);
          b(a, 31);
          k(a, s);
          v(a, L);
          k(a, N);
        }
        c[0] = 0;
        c[1] = 0;
        u[0] = 0;
        u[1] = 0;
        const h = [0, 0];
        switch (r) {
          case 15:
            h[1] = n[l + 14];
            w(h, 48);
            _(u, h);
          case 14:
            h[1] = n[l + 13];
            w(h, 40);
            _(u, h);
          case 13:
            h[1] = n[l + 12];
            w(h, 32);
            _(u, h);
          case 12:
            h[1] = n[l + 11];
            w(h, 24);
            _(u, h);
          case 11:
            h[1] = n[l + 10];
            w(h, 16);
            _(u, h);
          case 10:
            h[1] = n[l + 9];
            w(h, 8);
            _(u, h);
          case 9:
            h[1] = n[l + 8];
            _(u, h);
            v(u, x);
            b(u, 33);
            v(u, E);
            _(a, u);
          case 8:
            h[1] = n[l + 7];
            w(h, 56);
            _(c, h);
          case 7:
            h[1] = n[l + 6];
            w(h, 48);
            _(c, h);
          case 6:
            h[1] = n[l + 5];
            w(h, 40);
            _(c, h);
          case 5:
            h[1] = n[l + 4];
            w(h, 32);
            _(c, h);
          case 4:
            h[1] = n[l + 3];
            w(h, 24);
            _(c, h);
          case 3:
            h[1] = n[l + 2];
            w(h, 16);
            _(c, h);
          case 2:
            h[1] = n[l + 1];
            w(h, 8);
            _(c, h);
          case 1:
            h[1] = n[l];
            _(c, h);
            v(c, E);
            b(c, 31);
            v(c, x);
            _(s, c);
        }
        _(s, i);
        _(a, i);
        k(s, a);
        k(a, s);
        T(s);
        T(a);
        k(s, a);
        k(a, s);
        return (
          ("00000000" + (s[0] >>> 0).toString(16)).slice(-8) +
          ("00000000" + (s[1] >>> 0).toString(16)).slice(-8) +
          ("00000000" + (a[0] >>> 0).toString(16)).slice(-8) +
          ("00000000" + (a[1] >>> 0).toString(16)).slice(-8)
        );
      }
      function A(t) {
        var e;
        return {
          name: t.name,
          message: t.message,
          stack:
            null === (e = t.stack) || void 0 === e ? void 0 : e.split("\n"),
          ...t,
        };
      }
      function R(t) {
        return /^function\s.*?\{\s*\[native code]\s*}$/.test(String(t));
      }
      function O(t) {
        return "function" != typeof t;
      }
      function P(t, e) {
        const n = c(
          new Promise((n) => {
            const i = Date.now();
            s(t.bind(null, e), (...t) => {
              const e = Date.now() - i;
              if (!t[0]) return n(() => ({ error: t[1], duration: e }));
              const r = t[1];
              if (O(r)) return n(() => ({ value: r, duration: e }));
              n(
                () =>
                  new Promise((t) => {
                    const n = Date.now();
                    s(r, (...i) => {
                      const r = e + Date.now() - n;
                      if (!i[0]) return t({ error: i[1], duration: r });
                      t({ value: i[1], duration: r });
                    });
                  })
              );
            });
          })
        );
        return function () {
          return n.then((t) => t());
        };
      }
      function M(t, e, n, i) {
        const r = Object.keys(t).filter((t) => l(n, t)),
          o = c(a(r, (n) => P(t[n], e), i));
        return async function () {
          const t = await o,
            e = await a(t, (t) => c(t()), i),
            n = await Promise.all(e),
            s = {};
          for (let t = 0; t < r.length; ++t) s[r[t]] = n[t];
          return s;
        };
      }
      function V(t, e) {
        const n = (t) =>
          O(t)
            ? e(t)
            : () => {
                const n = t();
                return o(n) ? n.then(e) : e(n);
              };
        return (e) => {
          const i = t(e);
          return o(i) ? i.then(n) : n(i);
        };
      }
      function W() {
        const t = window,
          e = navigator;
        return (
          p([
            "MSCSSMatrix" in t,
            "msSetImmediate" in t,
            "msIndexedDB" in t,
            "msMaxTouchPoints" in e,
            "msPointerEnabled" in e,
          ]) >= 4
        );
      }
      function F() {
        const t = window,
          e = navigator;
        return (
          p([
            "msWriteProfilerMark" in t,
            "MSStream" in t,
            "msLaunchUri" in e,
            "msSaveBlob" in e,
          ]) >= 3 && !W()
        );
      }
      function H() {
        const t = window,
          e = navigator;
        return (
          p([
            "webkitPersistentStorage" in e,
            "webkitTemporaryStorage" in e,
            0 === (e.vendor || "").indexOf("Google"),
            "webkitResolveLocalFileSystemURL" in t,
            "BatteryManager" in t,
            "webkitMediaStream" in t,
            "webkitSpeechGrammar" in t,
          ]) >= 5
        );
      }
      function j() {
        const t = window;
        return (
          p([
            "ApplePayError" in t,
            "CSSPrimitiveValue" in t,
            "Counter" in t,
            0 === navigator.vendor.indexOf("Apple"),
            "RGBColor" in t,
            "WebKitMediaKeys" in t,
          ]) >= 4
        );
      }
      function U() {
        const t = window,
          { HTMLElement: e, Document: n } = t;
        return (
          p([
            "safari" in t,
            !("ongestureend" in t),
            !("TouchEvent" in t),
            !("orientation" in t),
            e && !("autocapitalize" in e.prototype),
            n && "pointerLockElement" in n.prototype,
          ]) >= 4
        );
      }
      function G() {
        const t = window;
        return R(t.print) && "[object WebPageNamespace]" === String(t.browser);
      }
      function Y() {
        var t, e;
        const n = window;
        return (
          p([
            "buildID" in navigator,
            "MozAppearance" in
              (null !==
                (e =
                  null === (t = document.documentElement) || void 0 === t
                    ? void 0
                    : t.style) && void 0 !== e
                ? e
                : {}),
            "onmozfullscreenchange" in n,
            "mozInnerScreenX" in n,
            "CSSMozDocumentRule" in n,
            "CanvasCaptureMediaStream" in n,
          ]) >= 4
        );
      }
      function Z() {
        const t = window;
        return (
          p([
            !("MediaSettingsRange" in t),
            "RTCEncodedAudioFrame" in t,
            "" + t.Intl == "[object Intl]",
            "" + t.Reflect == "[object Reflect]",
          ]) >= 3
        );
      }
      function B() {
        const t = window,
          { URLPattern: e } = t;
        return (
          p([
            "union" in Set.prototype,
            "Iterator" in t,
            e && "hasRegExpGroups" in e.prototype,
            "RGB8" in WebGLRenderingContext.prototype,
          ]) >= 3
        );
      }
      function X() {
        const t = window;
        return (
          p([
            "DOMRectList" in t,
            "RTCPeerConnectionIceEvent" in t,
            "SVGGeometryElement" in t,
            "ontransitioncancel" in t,
          ]) >= 3
        );
      }
      function z() {
        const t = window,
          e = navigator,
          { CSS: n, HTMLButtonElement: i } = t;
        return (
          p([
            !("getStorageUpdates" in e),
            i && "popover" in i.prototype,
            "CSSCounterStyleRule" in t,
            n.supports("font-size-adjust: ex-height 0.5"),
            n.supports("text-transform: full-width"),
          ]) >= 4
        );
      }
      function $() {
        if ("iPad" === navigator.platform) return !0;
        const t = screen,
          e = t.width / t.height;
        return (
          p([
            "MediaSource" in window,
            !!Element.prototype.webkitRequestFullscreen,
            e > 0.65 && e < 1.53,
          ]) >= 2
        );
      }
      function J() {
        const t = document;
        return (
          t.fullscreenElement ||
          t.msFullscreenElement ||
          t.mozFullScreenElement ||
          t.webkitFullscreenElement ||
          null
        );
      }
      function K() {
        const t = document;
        return (
          t.exitFullscreen ||
          t.msExitFullscreen ||
          t.mozCancelFullScreen ||
          t.webkitExitFullscreen
        ).call(t);
      }
      function q() {
        const t = H(),
          e = Y(),
          n = window,
          i = navigator,
          r = "connection";
        return t
          ? p([
              !("SharedWorker" in n),
              i[r] && "ontypechange" in i[r],
              !("sinkId" in new Audio()),
            ]) >= 2
          : !!e &&
              p([
                "onorientationchange" in n,
                "orientation" in n,
                /android/i.test(i.appVersion),
              ]) >= 2;
      }
      function Q() {
        const t = navigator,
          e = window,
          n = Audio.prototype,
          { visualViewport: i } = e;
        return (
          p([
            "srLatency" in n,
            "srChannelCount" in n,
            "devicePosture" in t,
            i && "segments" in i,
            "getTextInformation" in Image.prototype,
          ]) >= 3
        );
      }
      function tt() {
        return it() ? -4 : et();
      }
      function et() {
        const t = window,
          e = t.OfflineAudioContext || t.webkitOfflineAudioContext;
        if (!e) return -2;
        if (nt()) return -1;
        const n = 4500,
          i = new e(1, 5e3, 44100),
          r = i.createOscillator();
        r.type = "triangle";
        r.frequency.value = 1e4;
        const o = i.createDynamicsCompressor();
        o.threshold.value = -50;
        o.knee.value = 40;
        o.ratio.value = 12;
        o.attack.value = 0;
        o.release.value = 0.25;
        r.connect(o);
        o.connect(i.destination);
        r.start(0);
        const [s, a] = rt(i),
          u = c(
            s.then(
              (t) => ot(t.getChannelData(0).subarray(n)),
              (t) => {
                if ("timeout" === t.name || "suspended" === t.name) return -3;
                throw t;
              }
            )
          );
        return () => {
          a();
          return u;
        };
      }
      function nt() {
        return j() && !U() && !X();
      }
      function it() {
        return (j() && z() && G()) || (H() && Q() && B());
      }
      function rt(t) {
        const e = 3,
          n = 500,
          i = 500,
          r = 5e3;
        let s = () => {};
        return [
          new Promise((a, u) => {
            let l = !1,
              h = 0,
              d = 0;
            t.oncomplete = (t) => a(t.renderedBuffer);
            const f = () => {
                setTimeout(
                  () => u(st("timeout")),
                  Math.min(i, d + r - Date.now())
                );
              },
              p = () => {
                try {
                  const i = t.startRendering();
                  o(i) && c(i);
                  switch (t.state) {
                    case "running":
                      d = Date.now();
                      l && f();
                      break;
                    case "suspended":
                      document.hidden || h++;
                      l && h >= e ? u(st("suspended")) : setTimeout(p, n);
                  }
                } catch (t) {
                  u(t);
                }
              };
            p();
            s = () => {
              if (!l) {
                l = !0;
                d > 0 && f();
              }
            };
          }),
          s,
        ];
      }
      function ot(t) {
        let e = 0;
        for (let n = 0; n < t.length; ++n) e += Math.abs(t[n]);
        return e;
      }
      function st(t) {
        const e = new Error(t);
        e.name = t;
        return e;
      }
      async function at(t, e, i = 50) {
        var r, o, s;
        const a = document;
        for (; !a.body; ) await n(i);
        const c = a.createElement("iframe");
        try {
          await new Promise((t, n) => {
            let i = !1;
            const r = () => {
                i = !0;
                t();
              },
              o = (t) => {
                i = !0;
                n(t);
              };
            c.onload = r;
            c.onerror = o;
            const { style: s } = c;
            s.setProperty("display", "block", "important");
            s.position = "absolute";
            s.top = "0";
            s.left = "0";
            s.visibility = "hidden";
            e && "srcdoc" in c ? (c.srcdoc = e) : (c.src = "about:blank");
            a.body.appendChild(c);
            const u = () => {
              var t, e;
              i ||
                ("complete" ===
                (null ===
                  (e =
                    null === (t = c.contentWindow) || void 0 === t
                      ? void 0
                      : t.document) || void 0 === e
                  ? void 0
                  : e.readyState)
                  ? r()
                  : setTimeout(u, 10));
            };
            u();
          });
          for (
            ;
            !(null ===
              (o =
                null === (r = c.contentWindow) || void 0 === r
                  ? void 0
                  : r.document) || void 0 === o
              ? void 0
              : o.body);

          )
            await n(i);
          return await t(c, c.contentWindow);
        } finally {
          null === (s = c.parentNode) || void 0 === s || s.removeChild(c);
        }
      }
      function ct(t) {
        const [e, n] = m(t),
          i = document.createElement(null != e ? e : "div");
        for (const t of Object.keys(n)) {
          const e = n[t].join(" ");
          "style" === t ? ut(i.style, e) : i.setAttribute(t, e);
        }
        return i;
      }
      function ut(t, e) {
        for (const n of e.split(";")) {
          const e = /^\s*([\w-]+)\s*:\s*(.+?)(\s*!([\w-]+))?\s*$/.exec(n);
          if (e) {
            const [, n, i, , r] = e;
            t.setProperty(n, i, r || "");
          }
        }
      }
      function lt() {
        let t = window;
        for (;;) {
          const e = t.parent;
          if (!e || e === t) return !1;
          try {
            if (e.location.origin !== t.location.origin) return !0;
          } catch (t) {
            if (t instanceof Error && "SecurityError" === t.name) return !0;
            throw t;
          }
          t = e;
        }
      }
      const ht = "mmMwWLliI0O&1",
        dt = "48px",
        ft = ["monospace", "sans-serif", "serif"],
        pt = [
          "sans-serif-thin",
          "ARNO PRO",
          "Agency FB",
          "Arabic Typesetting",
          "Arial Unicode MS",
          "AvantGarde Bk BT",
          "BankGothic Md BT",
          "Batang",
          "Bitstream Vera Sans Mono",
          "Calibri",
          "Century",
          "Century Gothic",
          "Clarendon",
          "EUROSTILE",
          "Franklin Gothic",
          "Futura Bk BT",
          "Futura Md BT",
          "GOTHAM",
          "Gill Sans",
          "HELV",
          "Haettenschweiler",
          "Helvetica Neue",
          "Humanst521 BT",
          "Leelawadee",
          "Letter Gothic",
          "Levenim MT",
          "Lucida Bright",
          "Lucida Sans",
          "Menlo",
          "MS Mincho",
          "MS Outlook",
          "MS Reference Specialty",
          "MS UI Gothic",
          "MT Extra",
          "MYRIAD PRO",
          "Marlett",
          "Meiryo UI",
          "Microsoft Uighur",
          "Minion Pro",
          "Monotype Corsiva",
          "PMingLiU",
          "Pristina",
          "SCRIPTINA",
          "Segoe UI Light",
          "Serifa",
          "SimHei",
          "Small Fonts",
          "Staccato222 BT",
          "TRAJAN PRO",
          "Univers CE 55 Medium",
          "Vrinda",
          "ZWAdobeF",
        ];
      function gt() {
        return at(async (t, { document: e }) => {
          const n = e.body;
          n.style.fontSize = dt;
          const i = e.createElement("div");
          i.style.setProperty("visibility", "hidden", "important");
          const r = {},
            o = {},
            s = (t) => {
              const n = e.createElement("span"),
                { style: r } = n;
              r.position = "absolute";
              r.top = "0";
              r.left = "0";
              r.fontFamily = t;
              n.textContent = ht;
              i.appendChild(n);
              return n;
            },
            a = (t, e) => s(`'${t}',${e}`),
            c = () => {
              const t = {};
              for (const e of pt) t[e] = ft.map((t) => a(e, t));
              return t;
            },
            u = (t) =>
              ft.some(
                (e, n) =>
                  t[n].offsetWidth !== r[e] || t[n].offsetHeight !== o[e]
              ),
            l = (() => ft.map(s))(),
            h = c();
          n.appendChild(i);
          for (let t = 0; t < ft.length; t++) {
            r[ft[t]] = l[t].offsetWidth;
            o[ft[t]] = l[t].offsetHeight;
          }
          return pt.filter((t) => u(h[t]));
        });
      }
      function mt() {
        const t = navigator.plugins;
        if (!t) return;
        const e = [];
        for (let n = 0; n < t.length; ++n) {
          const i = t[n];
          if (!i) continue;
          const r = [];
          for (let t = 0; t < i.length; ++t) {
            const e = i[t];
            r.push({ type: e.type, suffixes: e.suffixes });
          }
          e.push({ name: i.name, description: i.description, mimeTypes: r });
        }
        return e;
      }
      function yt() {
        return kt(Et());
      }
      function kt(t) {
        let e,
          n,
          i = !1;
        const [r, o] = vt();
        if (bt(r, o)) {
          i = wt(o);
          t ? (e = n = "skipped") : ([e, n] = _t(r, o));
        } else e = n = "unsupported";
        return { winding: i, geometry: e, text: n };
      }
      function vt() {
        const t = document.createElement("canvas");
        t.width = 1;
        t.height = 1;
        return [t, t.getContext("2d")];
      }
      function bt(t, e) {
        return !(!e || !t.toDataURL);
      }
      function wt(t) {
        t.rect(0, 0, 10, 10);
        t.rect(2, 2, 6, 6);
        return !t.isPointInPath(5, 5, "evenodd");
      }
      function _t(t, e) {
        Ct(t, e);
        const n = Tt(t);
        if (n !== Tt(t)) return ["unstable", "unstable"];
        St(t, e);
        return [Tt(t), n];
      }
      function Ct(t, e) {
        t.width = 240;
        t.height = 60;
        e.textBaseline = "alphabetic";
        e.fillStyle = "#f60";
        e.fillRect(100, 1, 62, 20);
        e.fillStyle = "#069";
        e.font = '11pt "Times New Roman"';
        const n = `Cwm fjordbank gly ${String.fromCharCode(55357, 56835)}`;
        e.fillText(n, 2, 15);
        e.fillStyle = "rgba(102, 204, 0, 0.2)";
        e.font = "18pt Arial";
        e.fillText(n, 4, 45);
      }
      function St(t, e) {
        t.width = 122;
        t.height = 110;
        e.globalCompositeOperation = "multiply";
        for (const [t, n, i] of [
          ["#f2f", 40, 40],
          ["#2ff", 80, 40],
          ["#ff2", 60, 80],
        ]) {
          e.fillStyle = t;
          e.beginPath();
          e.arc(n, i, 40, 0, 2 * Math.PI, !0);
          e.closePath();
          e.fill();
        }
        e.fillStyle = "#f9c";
        e.arc(60, 60, 60, 0, 2 * Math.PI, !0);
        e.arc(60, 60, 20, 0, 2 * Math.PI, !0);
        e.fill("evenodd");
      }
      function Tt(t) {
        return t.toDataURL();
      }
      function Et() {
        return j() && z() && G();
      }
      function xt() {
        const t = navigator;
        let e,
          n = 0;
        void 0 !== t.maxTouchPoints
          ? (n = h(t.maxTouchPoints))
          : void 0 !== t.msMaxTouchPoints && (n = t.msMaxTouchPoints);
        try {
          document.createEvent("TouchEvent");
          e = !0;
        } catch (t) {
          e = !1;
        }
        return {
          maxTouchPoints: n,
          touchEvent: e,
          touchStart: "ontouchstart" in window,
        };
      }
      function Lt() {
        return navigator.oscpu;
      }
      function It() {
        const t = navigator,
          e = [],
          n =
            t.language ||
            t.userLanguage ||
            t.browserLanguage ||
            t.systemLanguage;
        void 0 !== n && e.push([n]);
        if (Array.isArray(t.languages)) (H() && Z()) || e.push(t.languages);
        else if ("string" == typeof t.languages) {
          const n = t.languages;
          n && e.push(n.split(","));
        }
        return e;
      }
      function Nt() {
        return window.screen.colorDepth;
      }
      function Dt() {
        return f(d(navigator.deviceMemory), void 0);
      }
      function At() {
        if (!(j() && z() && G())) return Rt();
      }
      function Rt() {
        const t = screen,
          e = (t) => f(h(t), null),
          n = [e(t.width), e(t.height)];
        n.sort().reverse();
        return n;
      }
      const Ot = 2500,
        Pt = 10;
      let Mt, Vt;
      function Wt() {
        if (void 0 !== Vt) return;
        const t = () => {
          const e = jt();
          if (Ut(e)) Vt = setTimeout(t, Ot);
          else {
            Mt = e;
            Vt = void 0;
          }
        };
        t();
      }
      function Ft() {
        Wt();
        return async () => {
          let t = jt();
          if (Ut(t)) {
            if (Mt) return [...Mt];
            if (J()) {
              await K();
              t = jt();
            }
          }
          Ut(t) || (Mt = t);
          return t;
        };
      }
      function Ht() {
        if (j() && z() && G()) return () => Promise.resolve(void 0);
        const t = Ft();
        return async () => {
          const e = await t(),
            n = (t) => (null === t ? null : g(t, Pt));
          return [n(e[0]), n(e[1]), n(e[2]), n(e[3])];
        };
      }
      function jt() {
        const t = screen;
        return [
          f(d(t.availTop), null),
          f(d(t.width) - d(t.availWidth) - f(d(t.availLeft), 0), null),
          f(d(t.height) - d(t.availHeight) - f(d(t.availTop), 0), null),
          f(d(t.availLeft), null),
        ];
      }
      function Ut(t) {
        for (let e = 0; e < 4; ++e) if (t[e]) return !1;
        return !0;
      }
      function Gt() {
        return f(h(navigator.hardwareConcurrency), void 0);
      }
      function Yt() {
        var t;
        const e =
          null === (t = window.Intl) || void 0 === t
            ? void 0
            : t.DateTimeFormat;
        if (e) {
          const t = new e().resolvedOptions().timeZone;
          if (t) return t;
        }
        const n = -Zt();
        return `UTC${n >= 0 ? "+" : ""}${n}`;
      }
      function Zt() {
        const t = new Date().getFullYear();
        return Math.max(
          d(new Date(t, 0, 1).getTimezoneOffset()),
          d(new Date(t, 6, 1).getTimezoneOffset())
        );
      }
      function Bt() {
        try {
          return !!window.sessionStorage;
        } catch (t) {
          return !0;
        }
      }
      function Xt() {
        try {
          return !!window.localStorage;
        } catch (t) {
          return !0;
        }
      }
      function zt() {
        if (!W() && !F())
          try {
            return !!window.indexedDB;
          } catch (t) {
            return !0;
          }
      }
      function $t() {
        return !!window.openDatabase;
      }
      function Jt() {
        return navigator.cpuClass;
      }
      function Kt() {
        const { platform: t } = navigator;
        return "MacIntel" === t && j() && !U() ? ($() ? "iPad" : "iPhone") : t;
      }
      function qt() {
        return navigator.vendor || "";
      }
      function Qt() {
        const t = [];
        for (const e of [
          "chrome",
          "safari",
          "__crWeb",
          "__gCrWeb",
          "yandex",
          "__yb",
          "__ybro",
          "__firefox__",
          "__edgeTrackingPreventionStatistics",
          "webkit",
          "oprt",
          "samsungAr",
          "ucweb",
          "UCShellJava",
          "puffinDevice",
        ]) {
          const n = window[e];
          n && "object" == typeof n && t.push(e);
        }
        return t.sort();
      }
      function te() {
        const t = document;
        try {
          t.cookie = "cookietest=1; SameSite=Strict;";
          const e = -1 !== t.cookie.indexOf("cookietest=");
          t.cookie =
            "cookietest=1; SameSite=Strict; expires=Thu, 01-Jan-1970 00:00:01 GMT";
          return e;
        } catch (t) {
          return !1;
        }
      }
      function ee() {
        const t = atob;
        return {
          abpIndo: [
            "#Iklan-Melayang",
            "#Kolom-Iklan-728",
            "#SidebarIklan-wrapper",
            '[title="ALIENBOLA" i]',
            t("I0JveC1CYW5uZXItYWRz"),
          ],
          abpvn: [
            ".quangcao",
            "#mobileCatfish",
            t("LmNsb3NlLWFkcw=="),
            '[id^="bn_bottom_fixed_"]',
            "#pmadv",
          ],
          adBlockFinland: [
            ".mainostila",
            t("LnNwb25zb3JpdA=="),
            ".ylamainos",
            t("YVtocmVmKj0iL2NsaWNrdGhyZ2guYXNwPyJd"),
            t("YVtocmVmXj0iaHR0cHM6Ly9hcHAucmVhZHBlYWsuY29tL2FkcyJd"),
          ],
          adBlockPersian: [
            "#navbar_notice_50",
            ".kadr",
            'TABLE[width="140px"]',
            "#divAgahi",
            t("YVtocmVmXj0iaHR0cDovL2cxLnYuZndtcm0ubmV0L2FkLyJd"),
          ],
          adBlockWarningRemoval: [
            "#adblock-honeypot",
            ".adblocker-root",
            ".wp_adblock_detect",
            t("LmhlYWRlci1ibG9ja2VkLWFk"),
            t("I2FkX2Jsb2NrZXI="),
          ],
          adGuardAnnoyances: [
            ".hs-sosyal",
            "#cookieconsentdiv",
            'div[class^="app_gdpr"]',
            ".as-oil",
            '[data-cypress="soft-push-notification-modal"]',
          ],
          adGuardBase: [
            ".BetterJsPopOverlay",
            t("I2FkXzMwMFgyNTA="),
            t("I2Jhbm5lcmZsb2F0MjI="),
            t("I2NhbXBhaWduLWJhbm5lcg=="),
            t("I0FkLUNvbnRlbnQ="),
          ],
          adGuardChinese: [
            t("LlppX2FkX2FfSA=="),
            t("YVtocmVmKj0iLmh0aGJldDM0LmNvbSJd"),
            "#widget-quan",
            t("YVtocmVmKj0iLzg0OTkyMDIwLnh5eiJd"),
            t("YVtocmVmKj0iLjE5NTZobC5jb20vIl0="),
          ],
          adGuardFrench: [
            "#pavePub",
            t("LmFkLWRlc2t0b3AtcmVjdGFuZ2xl"),
            ".mobile_adhesion",
            ".widgetadv",
            t("LmFkc19iYW4="),
          ],
          adGuardGerman: ['aside[data-portal-id="leaderboard"]'],
          adGuardJapanese: [
            "#kauli_yad_1",
            t("YVtocmVmXj0iaHR0cDovL2FkMi50cmFmZmljZ2F0ZS5uZXQvIl0="),
            t("Ll9wb3BJbl9pbmZpbml0ZV9hZA=="),
            t("LmFkZ29vZ2xl"),
            t("Ll9faXNib29zdFJldHVybkFk"),
          ],
          adGuardMobile: [
            t("YW1wLWF1dG8tYWRz"),
            t("LmFtcF9hZA=="),
            'amp-embed[type="24smi"]',
            "#mgid_iframe1",
            t("I2FkX2ludmlld19hcmVh"),
          ],
          adGuardRussian: [
            t("YVtocmVmXj0iaHR0cHM6Ly9hZC5sZXRtZWFkcy5jb20vIl0="),
            t("LnJlY2xhbWE="),
            'div[id^="smi2adblock"]',
            t("ZGl2W2lkXj0iQWRGb3hfYmFubmVyXyJd"),
            "#psyduckpockeball",
          ],
          adGuardSocial: [
            t("YVtocmVmXj0iLy93d3cuc3R1bWJsZXVwb24uY29tL3N1Ym1pdD91cmw9Il0="),
            t("YVtocmVmXj0iLy90ZWxlZ3JhbS5tZS9zaGFyZS91cmw/Il0="),
            ".etsy-tweet",
            "#inlineShare",
            ".popup-social",
          ],
          adGuardSpanishPortuguese: [
            "#barraPublicidade",
            "#Publicidade",
            "#publiEspecial",
            "#queTooltip",
            ".cnt-publi",
          ],
          adGuardTrackingProtection: [
            "#qoo-counter",
            t("YVtocmVmXj0iaHR0cDovL2NsaWNrLmhvdGxvZy5ydS8iXQ=="),
            t("YVtocmVmXj0iaHR0cDovL2hpdGNvdW50ZXIucnUvdG9wL3N0YXQucGhwIl0="),
            t("YVtocmVmXj0iaHR0cDovL3RvcC5tYWlsLnJ1L2p1bXAiXQ=="),
            "#top100counter",
          ],
          adGuardTurkish: [
            "#backkapat",
            t("I3Jla2xhbWk="),
            t("YVtocmVmXj0iaHR0cDovL2Fkc2Vydi5vbnRlay5jb20udHIvIl0="),
            t("YVtocmVmXj0iaHR0cDovL2l6bGVuemkuY29tL2NhbXBhaWduLyJd"),
            t("YVtocmVmXj0iaHR0cDovL3d3dy5pbnN0YWxsYWRzLm5ldC8iXQ=="),
          ],
          bulgarian: [
            t("dGQjZnJlZW5ldF90YWJsZV9hZHM="),
            "#ea_intext_div",
            ".lapni-pop-over",
            "#xenium_hot_offers",
          ],
          easyList: [
            ".yb-floorad",
            t("LndpZGdldF9wb19hZHNfd2lkZ2V0"),
            t("LnRyYWZmaWNqdW5reS1hZA=="),
            ".textad_headline",
            t("LnNwb25zb3JlZC10ZXh0LWxpbmtz"),
          ],
          easyListChina: [
            t("LmFwcGd1aWRlLXdyYXBbb25jbGljayo9ImJjZWJvcy5jb20iXQ=="),
            t("LmZyb250cGFnZUFkdk0="),
            "#taotaole",
            "#aafoot.top_box",
            ".cfa_popup",
          ],
          easyListCookie: [
            ".ezmob-footer",
            ".cc-CookieWarning",
            "[data-cookie-number]",
            t("LmF3LWNvb2tpZS1iYW5uZXI="),
            ".sygnal24-gdpr-modal-wrap",
          ],
          easyListCzechSlovak: [
            "#onlajny-stickers",
            t("I3Jla2xhbW5pLWJveA=="),
            t("LnJla2xhbWEtbWVnYWJvYXJk"),
            ".sklik",
            t("W2lkXj0ic2tsaWtSZWtsYW1hIl0="),
          ],
          easyListDutch: [
            t("I2FkdmVydGVudGll"),
            t("I3ZpcEFkbWFya3RCYW5uZXJCbG9jaw=="),
            ".adstekst",
            t("YVtocmVmXj0iaHR0cHM6Ly94bHR1YmUubmwvY2xpY2svIl0="),
            "#semilo-lrectangle",
          ],
          easyListGermany: [
            "#SSpotIMPopSlider",
            t("LnNwb25zb3JsaW5rZ3J1ZW4="),
            t("I3dlcmJ1bmdza3k="),
            t("I3Jla2xhbWUtcmVjaHRzLW1pdHRl"),
            t("YVtocmVmXj0iaHR0cHM6Ly9iZDc0Mi5jb20vIl0="),
          ],
          easyListItaly: [
            t("LmJveF9hZHZfYW5udW5jaQ=="),
            ".sb-box-pubbliredazionale",
            t("YVtocmVmXj0iaHR0cDovL2FmZmlsaWF6aW9uaWFkcy5zbmFpLml0LyJd"),
            t("YVtocmVmXj0iaHR0cHM6Ly9hZHNlcnZlci5odG1sLml0LyJd"),
            t("YVtocmVmXj0iaHR0cHM6Ly9hZmZpbGlhemlvbmlhZHMuc25haS5pdC8iXQ=="),
          ],
          easyListLithuania: [
            t("LnJla2xhbW9zX3RhcnBhcw=="),
            t("LnJla2xhbW9zX251b3JvZG9z"),
            t("aW1nW2FsdD0iUmVrbGFtaW5pcyBza3lkZWxpcyJd"),
            t("aW1nW2FsdD0iRGVkaWt1b3RpLmx0IHNlcnZlcmlhaSJd"),
            t("aW1nW2FsdD0iSG9zdGluZ2FzIFNlcnZlcmlhaS5sdCJd"),
          ],
          estonian: [t("QVtocmVmKj0iaHR0cDovL3BheTRyZXN1bHRzMjQuZXUiXQ==")],
          fanboyAnnoyances: [
            "#ac-lre-player",
            ".navigate-to-top",
            "#subscribe_popup",
            ".newsletter_holder",
            "#back-top",
          ],
          fanboyAntiFacebook: [".util-bar-module-firefly-visible"],
          fanboyEnhancedTrackers: [
            ".open.pushModal",
            "#issuem-leaky-paywall-articles-zero-remaining-nag",
            "#sovrn_container",
            'div[class$="-hide"][zoompage-fontsize][style="display: block;"]',
            ".BlockNag__Card",
          ],
          fanboySocial: [
            "#FollowUs",
            "#meteored_share",
            "#social_follow",
            ".article-sharer",
            ".community__social-desc",
          ],
          frellwitSwedish: [
            t("YVtocmVmKj0iY2FzaW5vcHJvLnNlIl1bdGFyZ2V0PSJfYmxhbmsiXQ=="),
            t("YVtocmVmKj0iZG9rdG9yLXNlLm9uZWxpbmsubWUiXQ=="),
            "article.category-samarbete",
            t("ZGl2LmhvbGlkQWRz"),
            "ul.adsmodern",
          ],
          greekAdBlock: [
            t("QVtocmVmKj0iYWRtYW4ub3RlbmV0LmdyL2NsaWNrPyJd"),
            t("QVtocmVmKj0iaHR0cDovL2F4aWFiYW5uZXJzLmV4b2R1cy5nci8iXQ=="),
            t(
              "QVtocmVmKj0iaHR0cDovL2ludGVyYWN0aXZlLmZvcnRobmV0LmdyL2NsaWNrPyJd"
            ),
            "DIV.agores300",
            "TABLE.advright",
          ],
          hungarian: [
            "#cemp_doboz",
            ".optimonk-iframe-container",
            t("LmFkX19tYWlu"),
            t("W2NsYXNzKj0iR29vZ2xlQWRzIl0="),
            "#hirdetesek_box",
          ],
          iDontCareAboutCookies: [
            '.alert-info[data-block-track*="CookieNotice"]',
            ".ModuleTemplateCookieIndicator",
            ".o--cookies--container",
            "#cookies-policy-sticky",
            "#stickyCookieBar",
          ],
          icelandicAbp: [
            t(
              "QVtocmVmXj0iL2ZyYW1ld29yay9yZXNvdXJjZXMvZm9ybXMvYWRzLmFzcHgiXQ=="
            ),
          ],
          latvian: [
            t(
              "YVtocmVmPSJodHRwOi8vd3d3LnNhbGlkemluaS5sdi8iXVtzdHlsZT0iZGlzcGxheTogYmxvY2s7IHdpZHRoOiAxMjBweDsgaGVpZ2h0OiA0MHB4OyBvdmVyZmxvdzogaGlkZGVuOyBwb3NpdGlvbjogcmVsYXRpdmU7Il0="
            ),
            t(
              "YVtocmVmPSJodHRwOi8vd3d3LnNhbGlkemluaS5sdi8iXVtzdHlsZT0iZGlzcGxheTogYmxvY2s7IHdpZHRoOiA4OHB4OyBoZWlnaHQ6IDMxcHg7IG92ZXJmbG93OiBoaWRkZW47IHBvc2l0aW9uOiByZWxhdGl2ZTsiXQ=="
            ),
          ],
          listKr: [
            t("YVtocmVmKj0iLy9hZC5wbGFuYnBsdXMuY28ua3IvIl0="),
            t("I2xpdmVyZUFkV3JhcHBlcg=="),
            t("YVtocmVmKj0iLy9hZHYuaW1hZHJlcC5jby5rci8iXQ=="),
            t("aW5zLmZhc3R2aWV3LWFk"),
            ".revenue_unit_item.dable",
          ],
          listeAr: [
            t("LmdlbWluaUxCMUFk"),
            ".right-and-left-sponsers",
            t("YVtocmVmKj0iLmFmbGFtLmluZm8iXQ=="),
            t("YVtocmVmKj0iYm9vcmFxLm9yZyJd"),
            t("YVtocmVmKj0iZHViaXp6bGUuY29tL2FyLz91dG1fc291cmNlPSJd"),
          ],
          listeFr: [
            t("YVtocmVmXj0iaHR0cDovL3Byb21vLnZhZG9yLmNvbS8iXQ=="),
            t("I2FkY29udGFpbmVyX3JlY2hlcmNoZQ=="),
            t("YVtocmVmKj0id2Vib3JhbWEuZnIvZmNnaS1iaW4vIl0="),
            ".site-pub-interstitiel",
            'div[id^="crt-"][data-criteo-id]',
          ],
          officialPolish: [
            "#ceneo-placeholder-ceneo-12",
            t("W2hyZWZePSJodHRwczovL2FmZi5zZW5kaHViLnBsLyJd"),
            t(
              "YVtocmVmXj0iaHR0cDovL2Fkdm1hbmFnZXIudGVjaGZ1bi5wbC9yZWRpcmVjdC8iXQ=="
            ),
            t("YVtocmVmXj0iaHR0cDovL3d3dy50cml6ZXIucGwvP3V0bV9zb3VyY2UiXQ=="),
            t("ZGl2I3NrYXBpZWNfYWQ="),
          ],
          ro: [
            t("YVtocmVmXj0iLy9hZmZ0cmsuYWx0ZXgucm8vQ291bnRlci9DbGljayJd"),
            t(
              "YVtocmVmXj0iaHR0cHM6Ly9ibGFja2ZyaWRheXNhbGVzLnJvL3Ryay9zaG9wLyJd"
            ),
            t(
              "YVtocmVmXj0iaHR0cHM6Ly9ldmVudC4ycGVyZm9ybWFudC5jb20vZXZlbnRzL2NsaWNrIl0="
            ),
            t("YVtocmVmXj0iaHR0cHM6Ly9sLnByb2ZpdHNoYXJlLnJvLyJd"),
            'a[href^="/url/"]',
          ],
          ruAd: [
            t("YVtocmVmKj0iLy9mZWJyYXJlLnJ1LyJd"),
            t("YVtocmVmKj0iLy91dGltZy5ydS8iXQ=="),
            t("YVtocmVmKj0iOi8vY2hpa2lkaWtpLnJ1Il0="),
            "#pgeldiz",
            ".yandex-rtb-block",
          ],
          thaiAds: [
            "a[href*=macau-uta-popup]",
            t("I2Fkcy1nb29nbGUtbWlkZGxlX3JlY3RhbmdsZS1ncm91cA=="),
            t("LmFkczMwMHM="),
            ".bumq",
            ".img-kosana",
          ],
          webAnnoyancesUltralist: [
            "#mod-social-share-2",
            "#social-tools",
            t("LmN0cGwtZnVsbGJhbm5lcg=="),
            ".zergnet-recommend",
            ".yt.btn-link.btn-md.btn",
          ],
        };
      }
      async function ne({ debug: t } = {}) {
        if (!ie()) return;
        const e = ee(),
          n = Object.keys(e),
          i = [].concat(...n.map((t) => e[t])),
          r = await re(i);
        t && se(e, r);
        const o = n.filter((t) => {
          const n = e[t];
          return p(n.map((t) => r[t])) > 0.6 * n.length;
        });
        o.sort();
        return o;
      }
      function ie() {
        return j() || q();
      }
      async function re(t) {
        var e;
        const i = document,
          r = i.createElement("div"),
          o = new Array(t.length),
          s = {};
        oe(r);
        for (let e = 0; e < t.length; ++e) {
          const n = ct(t[e]);
          "DIALOG" === n.tagName && n.show();
          const s = i.createElement("div");
          oe(s);
          s.appendChild(n);
          r.appendChild(s);
          o[e] = n;
        }
        for (; !i.body; ) await n(50);
        i.body.appendChild(r);
        try {
          for (let e = 0; e < t.length; ++e)
            o[e].offsetParent || (s[t[e]] = !0);
        } finally {
          null === (e = r.parentNode) || void 0 === e || e.removeChild(r);
        }
        return s;
      }
      function oe(t) {
        t.style.setProperty("visibility", "hidden", "important");
        t.style.setProperty("display", "block", "important");
      }
      function se(t, e) {
        let n = "DOM blockers debug:\n```";
        for (const i of Object.keys(t)) {
          n += `\n${i}:`;
          for (const r of t[i]) n += `\n  ${e[r] ? "🚫" : "➡️"} ${r}`;
        }
        console.log(`${n}\n\`\`\``);
      }
      function ae() {
        for (const t of ["rec2020", "p3", "srgb"])
          if (matchMedia(`(color-gamut: ${t})`).matches) return t;
      }
      function ce() {
        return !!ue("inverted") || (!ue("none") && void 0);
      }
      function ue(t) {
        return matchMedia(`(inverted-colors: ${t})`).matches;
      }
      function le() {
        return !!he("active") || (!he("none") && void 0);
      }
      function he(t) {
        return matchMedia(`(forced-colors: ${t})`).matches;
      }
      const de = 100;
      function fe() {
        if (matchMedia("(min-monochrome: 0)").matches) {
          for (let t = 0; t <= de; ++t)
            if (matchMedia(`(max-monochrome: ${t})`).matches) return t;
          throw new Error("Too high value");
        }
      }
      function pe() {
        return ge("no-preference")
          ? 0
          : ge("high") || ge("more")
          ? 1
          : ge("low") || ge("less")
          ? -1
          : ge("forced")
          ? 10
          : void 0;
      }
      function ge(t) {
        return matchMedia(`(prefers-contrast: ${t})`).matches;
      }
      function me() {
        return !!ye("reduce") || (!ye("no-preference") && void 0);
      }
      function ye(t) {
        return matchMedia(`(prefers-reduced-motion: ${t})`).matches;
      }
      function ke() {
        return !!ve("reduce") || (!ve("no-preference") && void 0);
      }
      function ve(t) {
        return matchMedia(`(prefers-reduced-transparency: ${t})`).matches;
      }
      function be() {
        return !!we("high") || (!we("standard") && void 0);
      }
      function we(t) {
        return matchMedia(`(dynamic-range: ${t})`).matches;
      }
      const _e = Math,
        Ce = () => 0;
      function Se() {
        const t = _e.acos || Ce,
          e = _e.acosh || Ce,
          n = _e.asin || Ce,
          i = _e.asinh || Ce,
          r = _e.atanh || Ce,
          o = _e.atan || Ce,
          s = _e.sin || Ce,
          a = _e.sinh || Ce,
          c = _e.cos || Ce,
          u = _e.cosh || Ce,
          l = _e.tan || Ce,
          h = _e.tanh || Ce,
          d = _e.exp || Ce,
          f = _e.expm1 || Ce,
          p = _e.log1p || Ce,
          g = (t) => _e.pow(_e.PI, t),
          m = (t) => _e.log(t + _e.sqrt(t * t - 1)),
          y = (t) => _e.log(t + _e.sqrt(t * t + 1)),
          k = (t) => _e.log((1 + t) / (1 - t)) / 2,
          v = (t) => _e.exp(t) - 1 / _e.exp(t) / 2,
          b = (t) => (_e.exp(t) + 1 / _e.exp(t)) / 2,
          w = (t) => _e.exp(t) - 1,
          _ = (t) => (_e.exp(2 * t) - 1) / (_e.exp(2 * t) + 1),
          C = (t) => _e.log(1 + t);
        return {
          acos: t(0.12312423423423424),
          acosh: e(1e308),
          acoshPf: m(1e154),
          asin: n(0.12312423423423424),
          asinh: i(1),
          asinhPf: y(1),
          atanh: r(0.5),
          atanhPf: k(0.5),
          atan: o(0.5),
          sin: s(-1e300),
          sinh: a(1),
          sinhPf: v(1),
          cos: c(10.000000000123),
          cosh: u(1),
          coshPf: b(1),
          tan: l(-1e300),
          tanh: h(1),
          tanhPf: _(1),
          exp: d(1),
          expm1: f(1),
          expm1Pf: w(1),
          log1p: p(10),
          log1pPf: C(10),
          powPI: g(-100),
        };
      }
      const Te = "mmMwWLliI0fiflO&1",
        Ee = {
          default: [],
          apple: [{ font: "-apple-system-body" }],
          serif: [{ fontFamily: "serif" }],
          sans: [{ fontFamily: "sans-serif" }],
          mono: [{ fontFamily: "monospace" }],
          min: [{ fontSize: "1px" }],
          system: [{ fontFamily: "system-ui" }],
        };
      function xe() {
        return Le((t, e) => {
          const n = {},
            i = {};
          for (const i of Object.keys(Ee)) {
            const [r = {}, o = Te] = Ee[i],
              s = t.createElement("span");
            s.textContent = o;
            s.style.whiteSpace = "nowrap";
            for (const t of Object.keys(r)) {
              const e = r[t];
              void 0 !== e && (s.style[t] = e);
            }
            n[i] = s;
            e.append(t.createElement("br"), s);
          }
          for (const t of Object.keys(Ee))
            i[t] = n[t].getBoundingClientRect().width;
          return i;
        });
      }
      function Le(t, e = 4e3) {
        return at((n, i) => {
          const r = i.document,
            o = r.body,
            s = o.style;
          s.width = `${e}px`;
          s.webkitTextSizeAdjust = s.textSizeAdjust = "none";
          H()
            ? (o.style.zoom = "" + 1 / i.devicePixelRatio)
            : j() && (o.style.zoom = "reset");
          const a = r.createElement("div");
          a.textContent = [...Array((e / 20) << 0)].map(() => "word").join(" ");
          o.appendChild(a);
          return t(r, o);
        }, '<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">');
      }
      function Ie() {
        return navigator.pdfViewerEnabled;
      }
      function Ne() {
        const t = new Float32Array(1),
          e = new Uint8Array(t.buffer);
        t[0] = 1 / 0;
        t[0] = t[0] - t[0];
        return e[3];
      }
      function De() {
        const { ApplePaySession: t } = window;
        if ("function" != typeof (null == t ? void 0 : t.canMakePayments))
          return -1;
        if (Ae()) return -3;
        try {
          return t.canMakePayments() ? 1 : 0;
        } catch (t) {
          return Re(t);
        }
      }
      const Ae = lt;
      function Re(t) {
        if (
          t instanceof Error &&
          "InvalidAccessError" === t.name &&
          /\bfrom\b.*\binsecure\b/i.test(t.message)
        )
          return -2;
        throw t;
      }
      function Oe() {
        var t;
        const e = document.createElement("a"),
          n =
            null !== (t = e.attributionSourceId) && void 0 !== t
              ? t
              : e.attributionsourceid;
        return void 0 === n ? void 0 : String(n);
      }
      const Pe = -1,
        Me = -2,
        Ve = new Set([
          10752, 2849, 2884, 2885, 2886, 2928, 2929, 2930, 2931, 2932, 2960,
          2961, 2962, 2963, 2964, 2965, 2966, 2967, 2968, 2978, 3024, 3042,
          3088, 3089, 3106, 3107, 32773, 32777, 32777, 32823, 32824, 32936,
          32937, 32938, 32939, 32968, 32969, 32970, 32971, 3317, 33170, 3333,
          3379, 3386, 33901, 33902, 34016, 34024, 34076, 3408, 3410, 3411, 3412,
          3413, 3414, 3415, 34467, 34816, 34817, 34818, 34819, 34877, 34921,
          34930, 35660, 35661, 35724, 35738, 35739, 36003, 36004, 36005, 36347,
          36348, 36349, 37440, 37441, 37443, 7936, 7937, 7938,
        ]),
        We = new Set([
          34047, 35723, 36063, 34852, 34853, 34854, 34229, 36392, 36795, 38449,
        ]),
        Fe = ["FRAGMENT_SHADER", "VERTEX_SHADER"],
        He = [
          "LOW_FLOAT",
          "MEDIUM_FLOAT",
          "HIGH_FLOAT",
          "LOW_INT",
          "MEDIUM_INT",
          "HIGH_INT",
        ],
        je = "WEBGL_debug_renderer_info",
        Ue = "WEBGL_polygon_mode";
      function Ge({ cache: t }) {
        var e, n, i, r, o, s;
        const a = Ze(t);
        if (!a) return Pe;
        if (!Ke(a)) return Me;
        const c = $e() ? null : a.getExtension(je);
        return {
          version:
            (null === (e = a.getParameter(a.VERSION)) || void 0 === e
              ? void 0
              : e.toString()) || "",
          vendor:
            (null === (n = a.getParameter(a.VENDOR)) || void 0 === n
              ? void 0
              : n.toString()) || "",
          vendorUnmasked: c
            ? null === (i = a.getParameter(c.UNMASKED_VENDOR_WEBGL)) ||
              void 0 === i
              ? void 0
              : i.toString()
            : "",
          renderer:
            (null === (r = a.getParameter(a.RENDERER)) || void 0 === r
              ? void 0
              : r.toString()) || "",
          rendererUnmasked: c
            ? null === (o = a.getParameter(c.UNMASKED_RENDERER_WEBGL)) ||
              void 0 === o
              ? void 0
              : o.toString()
            : "",
          shadingLanguageVersion:
            (null === (s = a.getParameter(a.SHADING_LANGUAGE_VERSION)) ||
            void 0 === s
              ? void 0
              : s.toString()) || "",
        };
      }
      function Ye({ cache: t }) {
        const e = Ze(t);
        if (!e) return Pe;
        if (!Ke(e)) return Me;
        const n = e.getSupportedExtensions(),
          i = e.getContextAttributes(),
          r = [],
          o = [],
          s = [],
          a = [],
          c = [];
        if (i) for (const t of Object.keys(i)) o.push(`${t}=${i[t]}`);
        const u = Xe(e);
        for (const t of u) {
          const n = e[t];
          s.push(`${t}=${n}${Ve.has(n) ? `=${e.getParameter(n)}` : ""}`);
        }
        if (n)
          for (const t of n) {
            if ((t === je && $e()) || (t === Ue && Je())) continue;
            const n = e.getExtension(t);
            if (n)
              for (const t of Xe(n)) {
                const i = n[t];
                a.push(`${t}=${i}${We.has(i) ? `=${e.getParameter(i)}` : ""}`);
              }
            else r.push(t);
          }
        for (const t of Fe)
          for (const n of He) {
            const i = Be(e, t, n);
            c.push(`${t}.${n}=${i.join(",")}`);
          }
        a.sort();
        s.sort();
        return {
          contextAttributes: o,
          parameters: s,
          shaderPrecisions: c,
          extensions: n,
          extensionParameters: a,
          unsupportedExtensions: r,
        };
      }
      function Ze(t) {
        if (t.webgl) return t.webgl.context;
        const e = document.createElement("canvas");
        let n;
        e.addEventListener("webglCreateContextError", () => (n = void 0));
        for (const t of ["webgl", "experimental-webgl"]) {
          try {
            n = e.getContext(t);
          } catch (t) {}
          if (n) break;
        }
        t.webgl = { context: n };
        return n;
      }
      function Be(t, e, n) {
        const i = t.getShaderPrecisionFormat(t[e], t[n]);
        return i ? [i.rangeMin, i.rangeMax, i.precision] : [];
      }
      function Xe(t) {
        return Object.keys(t.__proto__).filter(ze);
      }
      function ze(t) {
        return "string" == typeof t && !t.match(/[^A-Z0-9_x]/);
      }
      function $e() {
        return Y();
      }
      function Je() {
        return H() || j();
      }
      function Ke(t) {
        return "function" == typeof t.getParameter;
      }
      function qe() {
        if (!(q() || j())) return -2;
        if (!window.AudioContext) return -1;
        const t = new AudioContext().baseLatency;
        return null == t ? -1 : isFinite(t) ? t : -3;
      }
      function Qe() {
        if (!window.Intl) return -1;
        const t = window.Intl.DateTimeFormat;
        if (!t) return -2;
        const e = t().resolvedOptions().locale;
        return e || "" === e ? e : -3;
      }
      const tn = {
        fonts: gt,
        domBlockers: ne,
        fontPreferences: xe,
        audio: tt,
        screenFrame: Ht,
        canvas: yt,
        osCpu: Lt,
        languages: It,
        colorDepth: Nt,
        deviceMemory: Dt,
        screenResolution: At,
        hardwareConcurrency: Gt,
        timezone: Yt,
        sessionStorage: Bt,
        localStorage: Xt,
        indexedDB: zt,
        openDatabase: $t,
        cpuClass: Jt,
        platform: Kt,
        plugins: mt,
        touchSupport: xt,
        vendor: qt,
        vendorFlavors: Qt,
        cookiesEnabled: te,
        colorGamut: ae,
        invertedColors: ce,
        forcedColors: le,
        monochrome: fe,
        contrast: pe,
        reducedMotion: me,
        reducedTransparency: ke,
        hdr: be,
        math: Se,
        pdfViewerEnabled: Ie,
        architecture: Ne,
        applePay: De,
        privateClickMeasurement: Oe,
        audioBaseLatency: qe,
        dateTimeLocale: Qe,
        webGlBasics: Ge,
        webGlExtensions: Ye,
      };
      function en(t) {
        return M(tn, t, []);
      }
      const nn = "$ if upgrade to Pro: https://fpjs.dev/pro";
      function rn(t) {
        const e = on(t),
          n = sn(e);
        return { score: e, comment: nn.replace(/\$/g, `${n}`) };
      }
      function on(t) {
        if (q()) return 0.4;
        if (j()) return !U() || (z() && G()) ? 0.3 : 0.5;
        const e = "value" in t.platform ? t.platform.value : "";
        return /^Win/.test(e) ? 0.6 : /^Mac/.test(e) ? 0.5 : 0.7;
      }
      function sn(t) {
        return g(0.99 + 0.01 * t, 1e-4);
      }
      function an(t) {
        let e = "";
        for (const n of Object.keys(t).sort()) {
          const i = t[n],
            r = "error" in i ? "error" : JSON.stringify(i.value);
          e += `${e ? "|" : ""}${n.replace(/([:|\\])/g, "\\$1")}:${r}`;
        }
        return e;
      }
      function cn(t) {
        return JSON.stringify(t, (t, e) => (e instanceof Error ? A(e) : e), 2);
      }
      function un(t) {
        return D(an(t));
      }
      function ln(t) {
        let n;
        return {
          get visitorId() {
            void 0 === n && (n = un(this.components));
            return n;
          },
          set visitorId(t) {
            n = t;
          },
          confidence: rn(t),
          components: t,
          version: e,
        };
      }
      function hn(t = 50) {
        return r(t, 2 * t);
      }
      function dn(t, e) {
        const n = Date.now();
        return {
          async get(i) {
            const r = Date.now(),
              o = await t(),
              s = ln(o);
            (e || (null == i ? void 0 : i.debug)) &&
              console.log(
                `Copy the text below to get the debug data:\n\n\`\`\`\nversion: ${
                  s.version
                }\nuserAgent: ${navigator.userAgent}\ntimeBetweenLoadAndGet: ${
                  r - n
                }\nvisitorId: ${s.visitorId}\ncomponents: ${cn(o)}\n\`\`\``
              );
            return s;
          },
        };
      }
      async function fn(t = {}) {
        t.monitoring;
        const { delayFallback: e, debug: n } = t;
        await hn(e);
        return dn(en({ cache: {}, debug: n }), n);
      }
      var pn = { load: fn, hashComponents: un, componentsToDebugString: cn };
      const gn = D;
      t.componentsToDebugString = cn;
      t.default = pn;
      t.getFullscreenElement = J;
      t.getUnstableAudioFingerprint = et;
      t.getUnstableCanvasFingerprint = kt;
      t.getUnstableScreenFrame = Ft;
      t.getUnstableScreenResolution = Rt;
      t.getWebGLContext = Ze;
      t.hashComponents = un;
      t.isAndroid = q;
      t.isChromium = H;
      t.isDesktopWebKit = U;
      t.isEdgeHTML = F;
      t.isGecko = Y;
      t.isSamsungInternet = Q;
      t.isTrident = W;
      t.isWebKit = j;
      t.load = fn;
      t.loadSources = M;
      t.murmurX64Hash128 = gn;
      t.prepareForSources = hn;
      t.sources = tn;
      t.transformSource = V;
      t.withIframe = at;
      Object.defineProperty(t, "__esModule", { value: !0 });
      return t;
    })({});
    hstc.__bfp = null;
    t.load()
      .then((t) => t.get())
      .then((t) => (hstc.__bfp = t.visitorId))
      .catch((t) => hstc.utils && hstc.utils.logError(t));
    return function () {
      this.get = function () {
        return hstc.__bfp;
      };
    };
  });
  function loadHstc(t, e) {
    function n() {
      new hstc.tracking.Runner(t).run();
    }
    var i = t.getDocument();
    !i.readyState ||
    "complete" == i.readyState ||
    (i.addEventListener && "loaded" == i.readyState)
      ? n()
      : hstc.utils.addEventListener(e, "load", n, !0);
  }
  !(function (t, e) {
    try {
      var n = t.getWindow();
      if (!n[e]) {
        loadHstc(t, n);
        n[e] = !0;
      }
    } catch (t) {
      hstc.utils.logError(t);
    }
  })(new hstc.global.Context(), "_hstc_loaded");
})(); /** _anon_wrapper_ **/
