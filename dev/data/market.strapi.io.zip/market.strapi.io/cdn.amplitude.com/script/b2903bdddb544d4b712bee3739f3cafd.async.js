try {
  ("use strict");
  (function (c, l, n) {
    function p(b) {
      b.add(c.sessionReplay.plugin({ sampleRate: 0 }));
    }
    function q(b) {
      b.init("b2903bdddb544d4b712bee3739f3cafd", {
        serverZone: "US",
        autocapture: { elementInteractions: !0 },
      });
    }
    function r(b) {
      "" !== n &&
        b.add({
          name: "dynamic-script-library-plugin",
          execute: async (e) => {
            e.library = n + "/" + m.VERSION;
            return e;
          },
        });
    }
    function v() {
      if (!c.amplitude) return !1;
      const b = function (g, h) {
        let k = !1;
        var f = !1;
        for (const a of g._q) {
          "init" === a.name && (k = !0);
          for (let d = 0; a.args && d < a.args.length; d++)
            a.args[d] &&
              "object" === typeof a.args[d] &&
              "sr" === a.args[d]._STUBBED_PLUGIN_NAME &&
              (a.args[d]._conf
                ? ((f = a.args[d]._conf),
                  f.privacyConfig?.defaultMaskLevel ||
                    (f.privacyConfig = {
                      ...(f.privacyConfig || {}),
                      defaultMaskLevel: "conservative",
                    }),
                  (a.args[d] = c.sessionReplay.plugin(f)),
                  (f = !0))
                : ((a.args[d] = c.sessionReplay.plugin({ sampleRate: 0 })),
                  (f = !0)));
        }
        f || p(g);
        h && !k && q(g);
        r(g);
      };
      let e = !1;
      if (c.amplitude._iq)
        for (const g in c.amplitude._iq) {
          e = !0;
          const h = c.amplitude._iq[g];
          h._q && b(h, !1);
        }
      c.amplitude._q && b(c.amplitude, !e);
      return !0;
    }
    function t(b, e) {
      let g = 0;
      for (const h of b) {
        const { src: k, integrity: f } = h,
          a = l.createElement("script");
        a.src = k;
        a.integrity = f;
        a.crossOrigin = "anonymous";
        const d = l.querySelector("[nonce]");
        d && a.setAttribute("nonce", d.nonce || d.getAttribute("nonce"));
        a.readyState
          ? (a.onreadystatechange = function () {
              if ("loaded" === a.readyState || "complete" === a.readyState)
                (a.onreadystatechange = null), ++g === b.length && e();
            })
          : (a.onload = a.onerror =
              function () {
                ++g === b.length && e();
              });
        l.getElementsByTagName("head")[0].appendChild(a);
      }
    }
    function u() {
      const b = c.amplitude.createInstance;
      c.amplitude.createInstance = function () {
        const e = b();
        r(e);
        return e;
      };
    }
    const m = {
      VERSION: "2.36.7",
      INTEGRITY:
        "sha384-4nQ36il0EFzTt7wbIJJwU6SCu4DHjaAS98h4O3URvvX+f9R/I03UyGBSYfN0ftsl",
    };
    t(
      [
        {
          src: "https://cdn.amplitude.com/libs/plugin-session-replay-browser-1.27.7-min.js.gz",
          integrity:
            "sha384-8WMFffpEU/WccQVp3n0n2efKRilTag6ua/EFXj6MlXwJotTOVyvDRopoPi+RWqiE",
        },
      ],
      function () {
        let b = v();
        u();
        t(
          [
            {
              src:
                "https://cdn.amplitude.com/libs/analytics-browser-" +
                m.VERSION +
                "-min.js.gz",
              integrity: m.INTEGRITY,
            },
          ],
          function () {
            c.amplitude.runQueuedFunctions
              ? (u(), b || (p(c.amplitude), q(c.amplitude)))
              : console.log("[Amplitude] Error: could not load SDK");
          }
        );
      }
    );
  })(window, document, "amplitude-ts-script");
} catch (e) {
  console.log(e);
}
