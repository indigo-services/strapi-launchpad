try {
  /* @amplitude/experiment-tag v0.21.0 - For license info see https://unpkg.com/@amplitude/experiment-tag@0.21.0/files/LICENSE */
  !(function (e) {
    "use strict";
    var t = function () {
      return (
        (t =
          Object.assign ||
          function (e) {
            for (var t, r = 1, n = arguments.length; r < n; r++)
              for (var i in (t = arguments[r]))
                Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e;
          }),
        t.apply(this, arguments)
      );
    };
    function r(e, t, r, n) {
      return new (r || (r = Promise))(function (i, o) {
        function a(e) {
          try {
            l(n.next(e));
          } catch (e) {
            o(e);
          }
        }
        function s(e) {
          try {
            l(n.throw(e));
          } catch (e) {
            o(e);
          }
        }
        function l(e) {
          var t;
          e.done
            ? i(e.value)
            : ((t = e.value),
              t instanceof r
                ? t
                : new r(function (e) {
                    e(t);
                  })).then(a, s);
        }
        l((n = n.apply(e, t || [])).next());
      });
    }
    function n(e, t) {
      var r,
        n,
        i,
        o = {
          label: 0,
          sent: function () {
            if (1 & i[0]) throw i[1];
            return i[1];
          },
          trys: [],
          ops: [],
        },
        a = Object.create(
          ("function" == typeof Iterator ? Iterator : Object).prototype
        );
      return (
        (a.next = s(0)),
        (a.throw = s(1)),
        (a.return = s(2)),
        "function" == typeof Symbol &&
          (a[Symbol.iterator] = function () {
            return this;
          }),
        a
      );
      function s(s) {
        return function (l) {
          return (function (s) {
            if (r) throw new TypeError("Generator is already executing.");
            for (; a && ((a = 0), s[0] && (o = 0)), o; )
              try {
                if (
                  ((r = 1),
                  n &&
                    (i =
                      2 & s[0]
                        ? n.return
                        : s[0]
                        ? n.throw || ((i = n.return) && i.call(n), 0)
                        : n.next) &&
                    !(i = i.call(n, s[1])).done)
                )
                  return i;
                switch (((n = 0), i && (s = [2 & s[0], i.value]), s[0])) {
                  case 0:
                  case 1:
                    i = s;
                    break;
                  case 4:
                    return o.label++, { value: s[1], done: !1 };
                  case 5:
                    o.label++, (n = s[1]), (s = [0]);
                    continue;
                  case 7:
                    (s = o.ops.pop()), o.trys.pop();
                    continue;
                  default:
                    if (
                      !((i = o.trys),
                      (i = i.length > 0 && i[i.length - 1]) ||
                        (6 !== s[0] && 2 !== s[0]))
                    ) {
                      o = 0;
                      continue;
                    }
                    if (3 === s[0] && (!i || (s[1] > i[0] && s[1] < i[3]))) {
                      o.label = s[1];
                      break;
                    }
                    if (6 === s[0] && o.label < i[1]) {
                      (o.label = i[1]), (i = s);
                      break;
                    }
                    if (i && o.label < i[2]) {
                      (o.label = i[2]), o.ops.push(s);
                      break;
                    }
                    i[2] && o.ops.pop(), o.trys.pop();
                    continue;
                }
                s = t.call(e, o);
              } catch (e) {
                (s = [6, e]), (n = 0);
              } finally {
                r = i = 0;
              }
            if (5 & s[0]) throw s[1];
            return { value: s[0] ? s[1] : void 0, done: !0 };
          })([s, l]);
        };
      }
    }
    function i(e) {
      var t = "function" == typeof Symbol && Symbol.iterator,
        r = t && e[t],
        n = 0;
      if (r) return r.call(e);
      if (e && "number" == typeof e.length)
        return {
          next: function () {
            return (
              e && n >= e.length && (e = void 0),
              { value: e && e[n++], done: !e }
            );
          },
        };
      throw new TypeError(
        t ? "Object is not iterable." : "Symbol.iterator is not defined."
      );
    }
    function o(e, t) {
      var r = "function" == typeof Symbol && e[Symbol.iterator];
      if (!r) return e;
      var n,
        i,
        o = r.call(e),
        a = [];
      try {
        for (; (void 0 === t || t-- > 0) && !(n = o.next()).done; )
          a.push(n.value);
      } catch (e) {
        i = { error: e };
      } finally {
        try {
          n && !n.done && (r = o.return) && r.call(o);
        } finally {
          if (i) throw i.error;
        }
      }
      return a;
    }
    function a(e, t, r) {
      if (r || 2 === arguments.length)
        for (var n, i = 0, o = t.length; i < o; i++)
          (!n && i in t) ||
            (n || (n = Array.prototype.slice.call(t, 0, i)), (n[i] = t[i]));
      return e.concat(n || Array.prototype.slice.call(t));
    }
    "function" == typeof SuppressedError && SuppressedError;
    var s = function (e, t) {
      return (
        (s =
          Object.setPrototypeOf ||
          ({ __proto__: [] } instanceof Array &&
            function (e, t) {
              e.__proto__ = t;
            }) ||
          function (e, t) {
            for (var r in t)
              Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
          }),
        s(e, t)
      );
    };
    function l(e, t) {
      if ("function" != typeof t && null !== t)
        throw new TypeError(
          "Class extends value " + String(t) + " is not a constructor or null"
        );
      function r() {
        this.constructor = e;
      }
      s(e, t),
        (e.prototype =
          null === t
            ? Object.create(t)
            : ((r.prototype = t.prototype), new r()));
    }
    var u = function () {
      return (
        (u =
          Object.assign ||
          function (e) {
            for (var t, r = 1, n = arguments.length; r < n; r++)
              for (var i in (t = arguments[r]))
                Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
            return e;
          }),
        u.apply(this, arguments)
      );
    };
    function c(e, t, r, n) {
      return new (r || (r = Promise))(function (i, o) {
        function a(e) {
          try {
            l(n.next(e));
          } catch (e) {
            o(e);
          }
        }
        function s(e) {
          try {
            l(n.throw(e));
          } catch (e) {
            o(e);
          }
        }
        function l(e) {
          var t;
          e.done
            ? i(e.value)
            : ((t = e.value),
              t instanceof r
                ? t
                : new r(function (e) {
                    e(t);
                  })).then(a, s);
        }
        l((n = n.apply(e, t || [])).next());
      });
    }
    function d(e, t) {
      var r,
        n,
        i,
        o = {
          label: 0,
          sent: function () {
            if (1 & i[0]) throw i[1];
            return i[1];
          },
          trys: [],
          ops: [],
        },
        a = Object.create(
          ("function" == typeof Iterator ? Iterator : Object).prototype
        );
      return (
        (a.next = s(0)),
        (a.throw = s(1)),
        (a.return = s(2)),
        "function" == typeof Symbol &&
          (a[Symbol.iterator] = function () {
            return this;
          }),
        a
      );
      function s(s) {
        return function (l) {
          return (function (s) {
            if (r) throw new TypeError("Generator is already executing.");
            for (; a && ((a = 0), s[0] && (o = 0)), o; )
              try {
                if (
                  ((r = 1),
                  n &&
                    (i =
                      2 & s[0]
                        ? n.return
                        : s[0]
                        ? n.throw || ((i = n.return) && i.call(n), 0)
                        : n.next) &&
                    !(i = i.call(n, s[1])).done)
                )
                  return i;
                switch (((n = 0), i && (s = [2 & s[0], i.value]), s[0])) {
                  case 0:
                  case 1:
                    i = s;
                    break;
                  case 4:
                    return o.label++, { value: s[1], done: !1 };
                  case 5:
                    o.label++, (n = s[1]), (s = [0]);
                    continue;
                  case 7:
                    (s = o.ops.pop()), o.trys.pop();
                    continue;
                  default:
                    if (
                      !((i = o.trys),
                      (i = i.length > 0 && i[i.length - 1]) ||
                        (6 !== s[0] && 2 !== s[0]))
                    ) {
                      o = 0;
                      continue;
                    }
                    if (3 === s[0] && (!i || (s[1] > i[0] && s[1] < i[3]))) {
                      o.label = s[1];
                      break;
                    }
                    if (6 === s[0] && o.label < i[1]) {
                      (o.label = i[1]), (i = s);
                      break;
                    }
                    if (i && o.label < i[2]) {
                      (o.label = i[2]), o.ops.push(s);
                      break;
                    }
                    i[2] && o.ops.pop(), o.trys.pop();
                    continue;
                }
                s = t.call(e, o);
              } catch (e) {
                (s = [6, e]), (n = 0);
              } finally {
                r = i = 0;
              }
            if (5 & s[0]) throw s[1];
            return { value: s[0] ? s[1] : void 0, done: !0 };
          })([s, l]);
        };
      }
    }
    function f(e) {
      var t = "function" == typeof Symbol && Symbol.iterator,
        r = t && e[t],
        n = 0;
      if (r) return r.call(e);
      if (e && "number" == typeof e.length)
        return {
          next: function () {
            return (
              e && n >= e.length && (e = void 0),
              { value: e && e[n++], done: !e }
            );
          },
        };
      throw new TypeError(
        t ? "Object is not iterable." : "Symbol.iterator is not defined."
      );
    }
    function p(e, t) {
      var r = "function" == typeof Symbol && e[Symbol.iterator];
      if (!r) return e;
      var n,
        i,
        o = r.call(e),
        a = [];
      try {
        for (; (void 0 === t || t-- > 0) && !(n = o.next()).done; )
          a.push(n.value);
      } catch (e) {
        i = { error: e };
      } finally {
        try {
          n && !n.done && (r = o.return) && r.call(o);
        } finally {
          if (i) throw i.error;
        }
      }
      return a;
    }
    function v(e, t, r) {
      if (r || 2 === arguments.length)
        for (var n, i = 0, o = t.length; i < o; i++)
          (!n && i in t) ||
            (n || (n = Array.prototype.slice.call(t, 0, i)), (n[i] = t[i]));
      return e.concat(n || Array.prototype.slice.call(t));
    }
    "function" == typeof SuppressedError && SuppressedError;
    var h = "is",
      g = "is not",
      m = "contains",
      y = "does not contain",
      b = "less",
      w = "less or equal",
      x = "greater",
      S = "greater or equal",
      k = "version less",
      E = "version less or equal",
      _ = "version greater",
      O = "version greater or equal",
      A = "set is",
      P = "set is not",
      C = "set contains",
      M = "set does not contain",
      T = "set contains any",
      I = "set does not contain any",
      j = "regex match",
      N = "regex does not match",
      V = -862048943,
      L = 461845907,
      D = function (e, t) {
        void 0 === t && (t = 0);
        for (
          var r = (function (e) {
              for (var t = [], r = 0, n = 0; n < e.length; n++) {
                var i = e.charCodeAt(n);
                i < 128
                  ? (t[r++] = i)
                  : i < 2048
                  ? ((t[r++] = (i >> 6) | 192), (t[r++] = (63 & i) | 128))
                  : 55296 == (64512 & i) &&
                    n + 1 < e.length &&
                    56320 == (64512 & e.charCodeAt(n + 1))
                  ? ((i =
                      65536 + ((1023 & i) << 10) + (1023 & e.charCodeAt(++n))),
                    (t[r++] = (i >> 18) | 240),
                    (t[r++] = ((i >> 12) & 63) | 128),
                    (t[r++] = ((i >> 6) & 63) | 128),
                    (t[r++] = (63 & i) | 128))
                  : ((t[r++] = (i >> 12) | 224),
                    (t[r++] = ((i >> 6) & 63) | 128),
                    (t[r++] = (63 & i) | 128));
              }
              return Uint8Array.from(t);
            })(e),
            n = r.length,
            i = n >> 2,
            o = t,
            a = 0;
          a < i;
          a++
        ) {
          var s = B(r, a << 2);
          o = U(s, o);
        }
        var l = i << 2,
          u = 0;
        switch (n - l) {
          case 3:
            (u ^= r[l + 2] << 16),
              (u ^= r[l + 1] << 8),
              (u ^= r[l]),
              (u = Math.imul(u, V)),
              (u = R(u, 15)),
              (o ^= u = Math.imul(u, L));
            break;
          case 2:
            (u ^= r[l + 1] << 8),
              (u ^= r[l]),
              (u = Math.imul(u, V)),
              (u = R(u, 15)),
              (o ^= u = Math.imul(u, L));
            break;
          case 1:
            (u ^= r[l]),
              (u = Math.imul(u, V)),
              (u = R(u, 15)),
              (o ^= u = Math.imul(u, L));
        }
        return F((o ^= n)) >>> 0;
      },
      U = function (e, t) {
        var r = e,
          n = t;
        return (
          (r = Math.imul(r, V)),
          (r = R(r, 15)),
          (r = Math.imul(r, L)),
          (n = R((n ^= r), 13)),
          ((n = Math.imul(n, 5)) + -430675100) | 0
        );
      },
      F = function (e) {
        var t = e;
        return (
          (t ^= t >>> 16),
          (t = Math.imul(t, -2048144789)),
          (t ^= t >>> 13),
          (t = Math.imul(t, -1028477387)),
          (t ^= t >>> 16)
        );
      },
      R = function (e, t, r) {
        return (
          void 0 === r && (r = 32),
          t > r && (t %= r),
          ((e << t) |
            ((((e & ((4294967295 << (r - t)) >>> 0)) >>> 0) >>> (r - t)) >>>
              0)) >>>
            0
        );
      },
      B = function (e, t) {
        void 0 === t && (t = 0);
        var r = (e[t] << 24) | (e[t + 1] << 16) | (e[t + 2] << 8) | e[t + 3];
        return K(r);
      },
      K = function (e) {
        return (
          ((-16777216 & e) >>> 24) |
          ((16711680 & e) >>> 8) |
          ((65280 & e) << 8) |
          ((255 & e) << 24)
        );
      },
      q = function (e, t) {
        var r, n;
        if (t && 0 !== t.length) {
          try {
            for (var i = f(t), o = i.next(); !o.done; o = i.next()) {
              var a = o.value;
              if (!a || !e || "object" != typeof e) return;
              e = e[a];
            }
          } catch (e) {
            r = { error: e };
          } finally {
            try {
              o && !o.done && (n = i.return) && n.call(i);
            } finally {
              if (r) throw r.error;
            }
          }
          return null == e ? void 0 : e;
        }
      },
      z = "^"
        .concat("(\\d+)\\.(\\d+)", "(\\.")
        .concat("(\\d+)")
        .concat("(-(([-\\w]+\\.?)*))?", ")?$"),
      W = (function () {
        function e(e, t, r, n) {
          void 0 === n && (n = void 0),
            (this.major = e),
            (this.minor = t),
            (this.patch = r),
            (this.preRelease = n);
        }
        return (
          (e.parse = function (t) {
            if (t) {
              var r = new RegExp(z).exec(t);
              if (r) {
                var n = Number(r[1]),
                  i = Number(r[2]);
                if (!isNaN(n) && !isNaN(i))
                  return new e(n, i, Number(r[4]) || 0, r[5] || void 0);
              }
            }
          }),
          (e.prototype.compareTo = function (e) {
            return this.major > e.major
              ? 1
              : this.major < e.major
              ? -1
              : this.minor > e.minor
              ? 1
              : this.minor < e.minor
              ? -1
              : this.patch > e.patch
              ? 1
              : this.patch < e.patch || (this.preRelease && !e.preRelease)
              ? -1
              : !this.preRelease && e.preRelease
              ? 1
              : this.preRelease && e.preRelease
              ? this.preRelease > e.preRelease
                ? 1
                : this.preRelease < e.preRelease
                ? -1
                : 0
              : 0;
          }),
          e
        );
      })(),
      H = (function () {
        function e() {}
        return (
          (e.prototype.evaluate = function (e, t) {
            var r,
              n,
              i = {},
              o = { context: e, result: i };
            try {
              for (var a = f(t), s = a.next(); !s.done; s = a.next()) {
                var l = s.value,
                  u = this.evaluateFlag(o, l);
                u && (i[l.key] = u);
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                s && !s.done && (n = a.return) && n.call(a);
              } finally {
                if (r) throw r.error;
              }
            }
            return i;
          }),
          (e.prototype.evaluateWithTraces = function (e, t) {
            var r,
              n,
              i = {},
              o = {},
              a = { context: e, result: i };
            try {
              for (var s = f(t), l = s.next(); !l.done; l = s.next()) {
                var u = l.value,
                  c = this.evaluateFlagWithTrace(a, u),
                  d = c.variant,
                  p = c.trace;
                d && (i[u.key] = d), (o[u.key] = p);
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                l && !l.done && (n = s.return) && n.call(s);
              } finally {
                if (r) throw r.error;
              }
            }
            return { results: i, traces: o };
          }),
          (e.prototype.evaluateFlag = function (e, t) {
            var r, n, i;
            try {
              for (var o = f(t.segments), a = o.next(); !a.done; a = o.next()) {
                var s = a.value;
                if ((i = this.evaluateSegment(e, t, s))) {
                  var l = u(u(u({}, t.metadata), s.metadata), i.metadata);
                  i = u(u({}, i), { metadata: l });
                  break;
                }
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                a && !a.done && (n = o.return) && n.call(o);
              } finally {
                if (r) throw r.error;
              }
            }
            return i;
          }),
          (e.prototype.evaluateFlagWithTrace = function (e, t) {
            var r,
              n,
              i,
              o,
              a,
              s,
              l,
              c,
              d,
              p,
              v,
              h = [];
            try {
              for (var g = f(t.segments), m = g.next(); !m.done; m = g.next()) {
                var y = m.value;
                if (y.conditions) {
                  var b = [],
                    w = !1;
                  try {
                    for (
                      var x = ((i = void 0), f(y.conditions)), S = x.next();
                      !S.done;
                      S = x.next()
                    ) {
                      var k = S.value,
                        E = !0,
                        _ = [];
                      try {
                        for (
                          var O = ((a = void 0), f(k)), A = O.next();
                          !A.done;
                          A = O.next()
                        ) {
                          var P = A.value,
                            C = q(e, P.selector),
                            M = this.matchCondition(e, P);
                          if (
                            (_.push({ propValue: C, condition: P, matched: M }),
                            !M)
                          ) {
                            E = !1;
                            break;
                          }
                        }
                      } catch (e) {
                        a = { error: e };
                      } finally {
                        try {
                          A && !A.done && (s = O.return) && s.call(O);
                        } finally {
                          if (a) throw a.error;
                        }
                      }
                      if ((b.push(_), E)) {
                        w = !0;
                        break;
                      }
                    }
                  } catch (e) {
                    i = { error: e };
                  } finally {
                    try {
                      S && !S.done && (o = x.return) && o.call(x);
                    } finally {
                      if (i) throw i.error;
                    }
                  }
                  var T = !1,
                    I = void 0;
                  w && (T = void 0 !== (I = this.bucket(e, y))),
                    h.push({
                      segmentMetadata: y.metadata,
                      conditionsPassed: w,
                      bucketed: T,
                      bucketVariant: I,
                      conditionResult: b,
                      matched: w && T,
                    }),
                    w &&
                      void 0 !== I &&
                      !d &&
                      ((d = t.variants[I]),
                      (p = y),
                      (v =
                        null === (c = y.metadata) || void 0 === c
                          ? void 0
                          : c.segmentName));
                } else {
                  var j = this.bucket(e, y),
                    N = void 0 !== j;
                  h.push({
                    segmentMetadata: y.metadata,
                    conditionsPassed: !0,
                    bucketed: N,
                    bucketVariant: j,
                    conditionResult: void 0,
                    matched: N,
                  }),
                    d ||
                      void 0 === j ||
                      ((d = t.variants[j]),
                      (p = y),
                      (v =
                        null === (l = y.metadata) || void 0 === l
                          ? void 0
                          : l.segmentName));
                }
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                m && !m.done && (n = g.return) && n.call(g);
              } finally {
                if (r) throw r.error;
              }
            }
            if (d && p) {
              var V = u(u(u({}, t.metadata), p.metadata), d.metadata);
              d = u(u({}, d), { metadata: V });
            }
            return {
              variant: d,
              trace: {
                flagKey: t.key,
                matched: void 0 !== d,
                matchedSegment: v,
                steps: h,
              },
            };
          }),
          (e.prototype.evaluateSegment = function (e, t, r) {
            var n;
            return r.conditions
              ? this.evaluateConditions(e, r.conditions) &&
                void 0 !== (n = this.bucket(e, r))
                ? t.variants[n]
                : void 0
              : void 0 !== (n = this.bucket(e, r))
              ? t.variants[n]
              : void 0;
          }),
          (e.prototype.evaluateConditions = function (e, t) {
            var r, n, i, o;
            try {
              for (var a = f(t), s = a.next(); !s.done; s = a.next()) {
                var l = s.value,
                  u = !0;
                try {
                  for (
                    var c = ((i = void 0), f(l)), d = c.next();
                    !d.done;
                    d = c.next()
                  ) {
                    var p = d.value;
                    if (!(u = this.matchCondition(e, p))) break;
                  }
                } catch (e) {
                  i = { error: e };
                } finally {
                  try {
                    d && !d.done && (o = c.return) && o.call(c);
                  } finally {
                    if (i) throw i.error;
                  }
                }
                if (u) return !0;
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                s && !s.done && (n = a.return) && n.call(a);
              } finally {
                if (r) throw r.error;
              }
            }
            return !1;
          }),
          (e.prototype.matchCondition = function (e, t) {
            var r = q(e, t.selector);
            if (null == r) return this.matchNull(t.op, t.values);
            if (this.isSetOperator(t.op)) {
              var n = this.coerceStringArray(r);
              return !!n && this.matchSet(n, t.op, t.values);
            }
            var i = this.coerceString(r);
            return void 0 !== i && this.matchString(i, t.op, t.values);
          }),
          (e.prototype.getHash = function (e) {
            return D(e);
          }),
          (e.prototype.bucket = function (e, t) {
            var r, n, i, o;
            if (!t.bucket) return t.variant;
            var a = this.coerceString(q(e, t.bucket.selector));
            if (!a || 0 === a.length) return t.variant;
            var s = "".concat(t.bucket.salt, "/").concat(a),
              l = this.getHash(s),
              u = l % 100,
              c = Math.floor(l / 100);
            try {
              for (
                var d = f(t.bucket.allocations), p = d.next();
                !p.done;
                p = d.next()
              ) {
                var v = p.value,
                  h = v.range[0],
                  g = v.range[1];
                if (u >= h && u < g)
                  try {
                    for (
                      var m = ((i = void 0), f(v.distributions)), y = m.next();
                      !y.done;
                      y = m.next()
                    ) {
                      var b = y.value,
                        w = b.range[0],
                        x = b.range[1];
                      if (c >= w && c < x) return b.variant;
                    }
                  } catch (e) {
                    i = { error: e };
                  } finally {
                    try {
                      y && !y.done && (o = m.return) && o.call(m);
                    } finally {
                      if (i) throw i.error;
                    }
                  }
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                p && !p.done && (n = d.return) && n.call(d);
              } finally {
                if (r) throw r.error;
              }
            }
            return t.variant;
          }),
          (e.prototype.matchNull = function (e, t) {
            var r = this.containsNone(t);
            switch (e) {
              case h:
              case m:
              case b:
              case w:
              case x:
              case S:
              case k:
              case E:
              case _:
              case O:
              case A:
              case C:
              case T:
                return r;
              case g:
              case y:
              case M:
              case I:
                return !r;
              default:
                return !1;
            }
          }),
          (e.prototype.matchSet = function (e, t, r) {
            switch (t) {
              case A:
                return this.setEquals(e, r);
              case P:
                return !this.setEquals(e, r);
              case C:
                return this.matchesSetContainsAll(e, r);
              case M:
                return !this.matchesSetContainsAll(e, r);
              case T:
                return this.matchesSetContainsAny(e, r);
              case I:
                return !this.matchesSetContainsAny(e, r);
              default:
                return !1;
            }
          }),
          (e.prototype.matchString = function (e, t, r) {
            var n = this;
            switch (t) {
              case h:
                return this.matchesIs(e, r);
              case g:
                return !this.matchesIs(e, r);
              case m:
                return this.matchesContains(e, r);
              case y:
                return !this.matchesContains(e, r);
              case b:
              case w:
              case x:
              case S:
                return this.matchesComparable(
                  e,
                  t,
                  r,
                  function (e) {
                    return n.parseNumber(e);
                  },
                  this.comparator
                );
              case k:
              case E:
              case _:
              case O:
                return this.matchesComparable(
                  e,
                  t,
                  r,
                  function (e) {
                    return W.parse(e);
                  },
                  this.versionComparator
                );
              case j:
                return this.matchesRegex(e, r);
              case N:
                return !this.matchesRegex(e, r);
              default:
                return !1;
            }
          }),
          (e.prototype.matchesIs = function (e, t) {
            if (this.containsBooleans(t)) {
              var r = e.toLowerCase();
              if ("true" === r || "false" === r)
                return t.some(function (e) {
                  return e.toLowerCase() === r;
                });
            }
            return t.some(function (t) {
              return e === t;
            });
          }),
          (e.prototype.matchesContains = function (e, t) {
            var r, n;
            try {
              for (var i = f(t), o = i.next(); !o.done; o = i.next()) {
                var a = o.value;
                if (e.toLowerCase().includes(a.toLowerCase())) return !0;
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                o && !o.done && (n = i.return) && n.call(i);
              } finally {
                if (r) throw r.error;
              }
            }
            return !1;
          }),
          (e.prototype.matchesComparable = function (e, t, r, n, i) {
            var o = this,
              a = n(e),
              s = r
                .map(function (e) {
                  return n(e);
                })
                .filter(function (e) {
                  return void 0 !== e;
                });
            return void 0 === a || 0 === s.length
              ? r.some(function (r) {
                  return o.comparator(e, t, r);
                })
              : s.some(function (e) {
                  return i(a, t, e);
                });
          }),
          (e.prototype.comparator = function (e, t, r) {
            switch (t) {
              case b:
              case k:
                return e < r;
              case w:
              case E:
                return e <= r;
              case x:
              case _:
                return e > r;
              case S:
              case O:
                return e >= r;
              default:
                return !1;
            }
          }),
          (e.prototype.versionComparator = function (e, t, r) {
            var n = e.compareTo(r);
            switch (t) {
              case b:
              case k:
                return n < 0;
              case w:
              case E:
                return n <= 0;
              case x:
              case _:
                return n > 0;
              case S:
              case O:
                return n >= 0;
              default:
                return !1;
            }
          }),
          (e.prototype.matchesRegex = function (e, t) {
            return t.some(function (t) {
              return Boolean(new RegExp(t).exec(e));
            });
          }),
          (e.prototype.containsNone = function (e) {
            return e.some(function (e) {
              return "(none)" === e;
            });
          }),
          (e.prototype.containsBooleans = function (e) {
            return e.some(function (e) {
              switch (e.toLowerCase()) {
                case "true":
                case "false":
                  return !0;
                default:
                  return !1;
              }
            });
          }),
          (e.prototype.parseNumber = function (e) {
            var t;
            return null !== (t = Number(e)) && void 0 !== t ? t : void 0;
          }),
          (e.prototype.coerceString = function (e) {
            if (null != e)
              return "object" == typeof e ? JSON.stringify(e) : String(e);
          }),
          (e.prototype.coerceStringArray = function (e) {
            var t = this;
            if (Array.isArray(e))
              return e
                .map(function (e) {
                  return t.coerceString(e);
                })
                .filter(Boolean);
            var r = String(e);
            try {
              var n = JSON.parse(r);
              return Array.isArray(n)
                ? e
                    .map(function (e) {
                      return t.coerceString(e);
                    })
                    .filter(Boolean)
                : (i = this.coerceString(r))
                ? [i]
                : void 0;
            } catch (e) {
              var i;
              return (i = this.coerceString(r)) ? [i] : void 0;
            }
          }),
          (e.prototype.isSetOperator = function (e) {
            switch (e) {
              case A:
              case P:
              case C:
              case M:
              case T:
              case I:
                return !0;
              default:
                return !1;
            }
          }),
          (e.prototype.setEquals = function (e, t) {
            var r = new Set(e),
              n = new Set(t);
            return (
              r.size === n.size &&
              v([], p(n), !1).every(function (e) {
                return r.has(e);
              })
            );
          }),
          (e.prototype.matchesSetContainsAll = function (e, t) {
            var r, n;
            if (e.length < t.length) return !1;
            try {
              for (var i = f(t), o = i.next(); !o.done; o = i.next()) {
                var a = o.value;
                if (!this.matchesIs(a, e)) return !1;
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                o && !o.done && (n = i.return) && n.call(i);
              } finally {
                if (r) throw r.error;
              }
            }
            return !0;
          }),
          (e.prototype.matchesSetContainsAny = function (e, t) {
            var r, n;
            try {
              for (var i = f(t), o = i.next(); !o.done; o = i.next()) {
                var a = o.value;
                if (this.matchesIs(a, e)) return !0;
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                o && !o.done && (n = i.return) && n.call(i);
              } finally {
                if (r) throw r.error;
              }
            }
            return !1;
          }),
          e
        );
      })(),
      J = function (e, t) {
        var r,
          n,
          i = u({}, e),
          o = [],
          a = t || Object.keys(i);
        try {
          for (var s = f(a), l = s.next(); !l.done; l = s.next()) {
            var c = l.value,
              d = G(c, i);
            d && o.push.apply(o, v([], p(d), !1));
          }
        } catch (e) {
          r = { error: e };
        } finally {
          try {
            l && !l.done && (n = s.return) && n.call(s);
          } finally {
            if (r) throw r.error;
          }
        }
        return o;
      },
      G = function (e, t, r) {
        var n, i;
        void 0 === r && (r = []);
        var o = t[e];
        if (o) {
          if (!o.dependencies || 0 === o.dependencies.length)
            return delete t[o.key], [o];
          r.push(o.key);
          var a = [],
            s = function (e) {
              if (
                r.some(function (t) {
                  return t === e;
                })
              )
                throw Error("Detected a cycle between flags ".concat(r));
              var n = G(e, t, r);
              n && a.push.apply(a, v([], p(n), !1));
            };
          try {
            for (
              var l = f(o.dependencies), u = l.next();
              !u.done;
              u = l.next()
            ) {
              s(u.value);
            }
          } catch (e) {
            n = { error: e };
          } finally {
            try {
              u && !u.done && (i = l.return) && i.call(l);
            } finally {
              if (n) throw n.error;
            }
          }
          return a.push(o), r.pop(), delete t[o.key], a;
        }
      };
    const X = "function" == typeof Buffer,
      Q =
        ("function" == typeof TextDecoder && new TextDecoder(),
        "function" == typeof TextEncoder ? new TextEncoder() : void 0),
      $ = Array.prototype.slice.call(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
      ),
      Z = ((e) => {
        let t = {};
        return e.forEach((e, r) => (t[e] = r)), t;
      })($),
      Y =
        /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/,
      ee = String.fromCharCode.bind(String),
      te =
        ("function" == typeof Uint8Array.from &&
          Uint8Array.from.bind(Uint8Array),
        (e) =>
          e.replace(/=/g, "").replace(/[+\/]/g, (e) => ("+" == e ? "-" : "_"))),
      re = (e) => e.replace(/[^A-Za-z0-9\+\/]/g, ""),
      ne = (e) => {
        let t,
          r,
          n,
          i,
          o = "";
        const a = e.length % 3;
        for (let a = 0; a < e.length; ) {
          if (
            (r = e.charCodeAt(a++)) > 255 ||
            (n = e.charCodeAt(a++)) > 255 ||
            (i = e.charCodeAt(a++)) > 255
          )
            throw new TypeError("invalid character found");
          (t = (r << 16) | (n << 8) | i),
            (o +=
              $[(t >> 18) & 63] +
              $[(t >> 12) & 63] +
              $[(t >> 6) & 63] +
              $[63 & t]);
        }
        return a ? o.slice(0, a - 3) + "===".substring(a) : o;
      },
      ie =
        "function" == typeof btoa
          ? (e) => btoa(e)
          : X
          ? (e) => Buffer.from(e, "binary").toString("base64")
          : ne,
      oe = X
        ? (e) => Buffer.from(e).toString("base64")
        : (e) => {
            let t = [];
            for (let r = 0, n = e.length; r < n; r += 4096)
              t.push(ee.apply(null, e.subarray(r, r + 4096)));
            return ie(t.join(""));
          },
      ae = (e) => {
        if (e.length < 2)
          return (t = e.charCodeAt(0)) < 128
            ? e
            : t < 2048
            ? ee(192 | (t >>> 6)) + ee(128 | (63 & t))
            : ee(224 | ((t >>> 12) & 15)) +
              ee(128 | ((t >>> 6) & 63)) +
              ee(128 | (63 & t));
        var t =
          65536 + 1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320);
        return (
          ee(240 | ((t >>> 18) & 7)) +
          ee(128 | ((t >>> 12) & 63)) +
          ee(128 | ((t >>> 6) & 63)) +
          ee(128 | (63 & t))
        );
      },
      se = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g,
      le = (e) => e.replace(se, ae),
      ue = X
        ? (e) => Buffer.from(e, "utf8").toString("base64")
        : Q
        ? (e) => oe(Q.encode(e))
        : (e) => ie(le(e)),
      ce = (e, t = !1) => (t ? te(ue(e)) : ue(e)),
      de = (e) => ce(e, !0),
      fe = (e) => {
        if (((e = e.replace(/\s+/g, "")), !Y.test(e)))
          throw new TypeError("malformed base64.");
        let t, r, n;
        e += "==".slice(2 - (3 & e.length));
        let i = [];
        for (let o = 0; o < e.length; )
          (t =
            (Z[e.charAt(o++)] << 18) |
            (Z[e.charAt(o++)] << 12) |
            ((r = Z[e.charAt(o++)]) << 6) |
            (n = Z[e.charAt(o++)])),
            64 === r
              ? i.push(ee((t >> 16) & 255))
              : 64 === n
              ? i.push(ee((t >> 16) & 255, (t >> 8) & 255))
              : i.push(ee((t >> 16) & 255, (t >> 8) & 255, 255 & t));
        return i.join("");
      },
      pe = de;
    var ve = (function (e) {
        function t(r, n) {
          var i = e.call(this, n) || this;
          return (i.statusCode = r), Object.setPrototypeOf(i, t.prototype), i;
        }
        return l(t, e), t;
      })(Error),
      he = (function (e) {
        function t(r) {
          var n = e.call(this, r) || this;
          return Object.setPrototypeOf(n, t.prototype), n;
        }
        return l(t, e), t;
      })(Error),
      ge = (function () {
        function e(e, t, r) {
          (this.deploymentKey = e), (this.serverUrl = t), (this.httpClient = r);
        }
        return (
          (e.prototype.getVariants = function (e, t) {
            return c(this, void 0, void 0, function () {
              var r, n, i, o;
              return d(this, function (a) {
                switch (a.label) {
                  case 0:
                    return (
                      (r = pe(JSON.stringify(e))),
                      (n = {
                        Authorization: "Api-Key ".concat(this.deploymentKey),
                        "X-Amp-Exp-User": r,
                      }),
                      (null == t ? void 0 : t.flagKeys) &&
                        (n["X-Amp-Exp-Flag-Keys"] = pe(
                          JSON.stringify(t.flagKeys)
                        )),
                      (null == t ? void 0 : t.trackingOption) &&
                        (n["X-Amp-Exp-Track"] = t.trackingOption),
                      (null == t ? void 0 : t.exposureTrackingOption) &&
                        (n["X-Amp-Exp-Exposure-Track"] =
                          t.exposureTrackingOption),
                      (i = new URL(
                        "".concat(this.serverUrl, "/sdk/v2/vardata?v=0")
                      )),
                      (null == t ? void 0 : t.evaluationMode) &&
                        i.searchParams.append(
                          "eval_mode",
                          null == t ? void 0 : t.evaluationMode
                        ),
                      (null == t ? void 0 : t.deliveryMethod) &&
                        i.searchParams.append(
                          "delivery_method",
                          null == t ? void 0 : t.deliveryMethod
                        ),
                      [
                        4,
                        this.httpClient.request({
                          requestUrl: i.toString(),
                          method: "GET",
                          headers: n,
                          timeoutMillis: null == t ? void 0 : t.timeoutMillis,
                        }),
                      ]
                    );
                  case 1:
                    if (200 != (o = a.sent()).status)
                      throw new ve(
                        o.status,
                        "Fetch error response: status=".concat(o.status)
                      );
                    return [2, JSON.parse(o.body)];
                }
              });
            });
          }),
          e
        );
      })(),
      me = (function () {
        function e(e, t, r) {
          (this.deploymentKey = e), (this.serverUrl = t), (this.httpClient = r);
        }
        return (
          (e.prototype.getFlags = function (e) {
            return c(this, void 0, void 0, function () {
              var t, r;
              return d(this, function (n) {
                switch (n.label) {
                  case 0:
                    return (
                      (t = {
                        Authorization: "Api-Key ".concat(this.deploymentKey),
                      }),
                      (null == e ? void 0 : e.libraryName) &&
                        (null == e ? void 0 : e.libraryVersion) &&
                        (t["X-Amp-Exp-Library"] = ""
                          .concat(e.libraryName, "/")
                          .concat(e.libraryVersion)),
                      (null == e ? void 0 : e.user) &&
                        (t["X-Amp-Exp-User"] = pe(JSON.stringify(e.user))),
                      [
                        4,
                        this.httpClient.request({
                          requestUrl:
                            "".concat(this.serverUrl, "/sdk/v2/flags") +
                            ((null == e ? void 0 : e.deliveryMethod)
                              ? "?delivery_method=".concat(e.deliveryMethod)
                              : ""),
                          method: "GET",
                          headers: t,
                          timeoutMillis: null == e ? void 0 : e.timeoutMillis,
                        }),
                      ]
                    );
                  case 1:
                    if (200 != (r = n.sent()).status)
                      throw Error(
                        "Flags error response: status=".concat(r.status)
                      );
                    return [
                      2,
                      JSON.parse(r.body).reduce(function (e, t) {
                        return (e[t.key] = t), e;
                      }, {}),
                    ];
                }
              });
            });
          }),
          e
        );
      })(),
      ye = "undefined" != typeof globalThis ? globalThis : global || self,
      be = function () {
        return "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof window
          ? window
          : "undefined" != typeof self
          ? self
          : "undefined" != typeof global
          ? global
          : void 0;
      },
      we = function () {
        var e = be();
        if (e)
          try {
            var t = "EXP_test";
            return (
              e.localStorage.setItem(t, t), e.localStorage.removeItem(t), !0
            );
          } catch (e) {
            return !1;
          }
        return !1;
      },
      xe = (function () {
        function e(e, t) {
          (this.poller = void 0), (this.action = e), (this.ms = t);
        }
        return (
          (e.prototype.start = function () {
            this.poller ||
              ((this.poller = ye.setInterval(this.action, this.ms)),
              this.action());
          }),
          (e.prototype.stop = function () {
            this.poller &&
              (ye.clearInterval(this.poller), (this.poller = void 0));
          }),
          e
        );
      })(),
      Se = (function () {
        function e() {}
        return (
          (e.prototype.getApplicationContext = function () {
            return {
              versionName: this.versionName,
              language: ke(),
              platform: "Web",
              os: void 0,
              deviceModel: void 0,
            };
          }),
          e
        );
      })(),
      ke = function () {
        return (
          ("undefined" != typeof navigator &&
            ((navigator.languages && navigator.languages[0]) ||
              navigator.language)) ||
          ""
        );
      },
      Ee = (function () {
        function e() {
          this.queue = [];
        }
        return (
          (e.prototype.logEvent = function (e) {
            this.receiver
              ? this.receiver(e)
              : this.queue.length < 512 && this.queue.push(e);
          }),
          (e.prototype.setEventReceiver = function (e) {
            (this.receiver = e),
              this.queue.length > 0 &&
                (this.queue.forEach(function (t) {
                  e(t);
                }),
                (this.queue = []));
          }),
          e
        );
      })(),
      _e = function () {
        return (
          (_e =
            Object.assign ||
            function (e) {
              for (var t, r = 1, n = arguments.length; r < n; r++)
                for (var i in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
              return e;
            }),
          _e.apply(this, arguments)
        );
      };
    function Oe(e) {
      var t = "function" == typeof Symbol && Symbol.iterator,
        r = t && e[t],
        n = 0;
      if (r) return r.call(e);
      if (e && "number" == typeof e.length)
        return {
          next: function () {
            return (
              e && n >= e.length && (e = void 0),
              { value: e && e[n++], done: !e }
            );
          },
        };
      throw new TypeError(
        t ? "Object is not iterable." : "Symbol.iterator is not defined."
      );
    }
    function Ae(e, t) {
      var r = "function" == typeof Symbol && e[Symbol.iterator];
      if (!r) return e;
      var n,
        i,
        o = r.call(e),
        a = [];
      try {
        for (; (void 0 === t || t-- > 0) && !(n = o.next()).done; )
          a.push(n.value);
      } catch (e) {
        i = { error: e };
      } finally {
        try {
          n && !n.done && (r = o.return) && r.call(o);
        } finally {
          if (i) throw i.error;
        }
      }
      return a;
    }
    "function" == typeof SuppressedError && SuppressedError;
    var Pe = function (e, t) {
      var r,
        n,
        i = typeof e;
      if (i !== typeof t) return !1;
      try {
        for (
          var o = Oe(["string", "number", "boolean", "undefined"]),
            a = o.next();
          !a.done;
          a = o.next()
        ) {
          if (a.value === i) return e === t;
        }
      } catch (e) {
        r = { error: e };
      } finally {
        try {
          a && !a.done && (n = o.return) && n.call(o);
        } finally {
          if (r) throw r.error;
        }
      }
      if (null == e && null == t) return !0;
      if (null == e || null == t) return !1;
      if (e.length !== t.length) return !1;
      var s = Array.isArray(e),
        l = Array.isArray(t);
      if (s !== l) return !1;
      if (!s || !l) {
        var u = Object.keys(e).sort(),
          c = Object.keys(t).sort();
        if (!Pe(u, c)) return !1;
        var d = !0;
        return (
          Object.keys(e).forEach(function (r) {
            Pe(e[r], t[r]) || (d = !1);
          }),
          d
        );
      }
      for (var f = 0; f < e.length; f++) if (!Pe(e[f], t[f])) return !1;
      return !0;
    };
    Object.entries ||
      (Object.entries = function (e) {
        for (var t = Object.keys(e), r = t.length, n = new Array(r); r--; )
          n[r] = [t[r], e[t[r]]];
        return n;
      });
    var Ce = (function () {
        function e() {
          (this.identity = { userProperties: {} }),
            (this.listeners = new Set());
        }
        return (
          (e.prototype.editIdentity = function () {
            var e = this,
              t = _e({}, this.identity.userProperties),
              r = _e(_e({}, this.identity), { userProperties: t });
            return {
              setUserId: function (e) {
                return (r.userId = e), this;
              },
              setDeviceId: function (e) {
                return (r.deviceId = e), this;
              },
              setUserProperties: function (e) {
                return (r.userProperties = e), this;
              },
              setOptOut: function (e) {
                return (r.optOut = e), this;
              },
              updateUserProperties: function (e) {
                var t,
                  n,
                  i,
                  o,
                  a,
                  s,
                  l = r.userProperties || {};
                try {
                  for (
                    var u = Oe(Object.entries(e)), c = u.next();
                    !c.done;
                    c = u.next()
                  ) {
                    var d = Ae(c.value, 2),
                      f = d[0],
                      p = d[1];
                    switch (f) {
                      case "$set":
                        try {
                          for (
                            var v = ((i = void 0), Oe(Object.entries(p))),
                              h = v.next();
                            !h.done;
                            h = v.next()
                          ) {
                            var g = Ae(h.value, 2),
                              m = g[0],
                              y = g[1];
                            l[m] = y;
                          }
                        } catch (e) {
                          i = { error: e };
                        } finally {
                          try {
                            h && !h.done && (o = v.return) && o.call(v);
                          } finally {
                            if (i) throw i.error;
                          }
                        }
                        break;
                      case "$unset":
                        try {
                          for (
                            var b = ((a = void 0), Oe(Object.keys(p))),
                              w = b.next();
                            !w.done;
                            w = b.next()
                          ) {
                            delete l[(m = w.value)];
                          }
                        } catch (e) {
                          a = { error: e };
                        } finally {
                          try {
                            w && !w.done && (s = b.return) && s.call(b);
                          } finally {
                            if (a) throw a.error;
                          }
                        }
                        break;
                      case "$clearAll":
                        l = {};
                    }
                  }
                } catch (e) {
                  t = { error: e };
                } finally {
                  try {
                    c && !c.done && (n = u.return) && n.call(u);
                  } finally {
                    if (t) throw t.error;
                  }
                }
                return (r.userProperties = l), this;
              },
              commit: function () {
                return e.setIdentity(r), this;
              },
            };
          }),
          (e.prototype.getIdentity = function () {
            return _e({}, this.identity);
          }),
          (e.prototype.setIdentity = function (e) {
            var t = _e({}, this.identity);
            (this.identity = _e({}, e)),
              Pe(t, this.identity) ||
                this.listeners.forEach(function (t) {
                  t(e);
                });
          }),
          (e.prototype.addIdentityListener = function (e) {
            this.listeners.add(e);
          }),
          (e.prototype.removeIdentityListener = function (e) {
            this.listeners.delete(e);
          }),
          e
        );
      })(),
      Me =
        "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof global
          ? global
          : self,
      Te = (function () {
        function e() {
          (this.identityStore = new Ce()),
            (this.eventBridge = new Ee()),
            (this.applicationContextProvider = new Se());
        }
        return (
          (e.getInstance = function (t) {
            return (
              Me.analyticsConnectorInstances ||
                (Me.analyticsConnectorInstances = {}),
              Me.analyticsConnectorInstances[t] ||
                (Me.analyticsConnectorInstances[t] = new e()),
              Me.analyticsConnectorInstances[t]
            );
          }),
          e
        );
      })(),
      Ie =
        "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {};
    var je,
      Ne,
      Ve,
      Le =
        ((je = function (e, t) {
          !(function (r, n) {
            var i = "function",
              o = "undefined",
              a = "object",
              s = "string",
              l = "model",
              u = "name",
              c = "type",
              d = "vendor",
              f = "version",
              p = "architecture",
              v = "console",
              h = "mobile",
              g = "tablet",
              m = "smarttv",
              y = "wearable",
              b = "embedded",
              w = "Amazon",
              x = "Apple",
              S = "ASUS",
              k = "BlackBerry",
              E = "Browser",
              _ = "Chrome",
              O = "Firefox",
              A = "Google",
              P = "Huawei",
              C = "LG",
              M = "Microsoft",
              T = "Motorola",
              I = "Opera",
              j = "Samsung",
              N = "Sharp",
              V = "Sony",
              L = "Xiaomi",
              D = "Zebra",
              U = "Facebook",
              F = function (e) {
                for (var t = {}, r = 0; r < e.length; r++)
                  t[e[r].toUpperCase()] = e[r];
                return t;
              },
              R = function (e, t) {
                return typeof e === s && -1 !== B(t).indexOf(B(e));
              },
              B = function (e) {
                return e.toLowerCase();
              },
              K = function (e, t) {
                if (typeof e === s)
                  return (
                    (e = e.replace(/^\s\s*/, "")),
                    typeof t === o ? e : e.substring(0, 350)
                  );
              },
              q = function (e, t) {
                for (var r, o, s, l, u, c, d = 0; d < t.length && !u; ) {
                  var f = t[d],
                    p = t[d + 1];
                  for (r = o = 0; r < f.length && !u; )
                    if ((u = f[r++].exec(e)))
                      for (s = 0; s < p.length; s++)
                        (c = u[++o]),
                          typeof (l = p[s]) === a && l.length > 0
                            ? 2 === l.length
                              ? typeof l[1] == i
                                ? (this[l[0]] = l[1].call(this, c))
                                : (this[l[0]] = l[1])
                              : 3 === l.length
                              ? typeof l[1] !== i || (l[1].exec && l[1].test)
                                ? (this[l[0]] = c ? c.replace(l[1], l[2]) : n)
                                : (this[l[0]] = c
                                    ? l[1].call(this, c, l[2])
                                    : n)
                              : 4 === l.length &&
                                (this[l[0]] = c
                                  ? l[3].call(this, c.replace(l[1], l[2]))
                                  : n)
                            : (this[l] = c || n);
                  d += 2;
                }
              },
              z = function (e, t) {
                for (var r in t)
                  if (typeof t[r] === a && t[r].length > 0) {
                    for (var i = 0; i < t[r].length; i++)
                      if (R(t[r][i], e)) return "?" === r ? n : r;
                  } else if (R(t[r], e)) return "?" === r ? n : r;
                return e;
              },
              W = {
                ME: "4.90",
                "NT 3.11": "NT3.51",
                "NT 4.0": "NT4.0",
                2e3: "NT 5.0",
                XP: ["NT 5.1", "NT 5.2"],
                Vista: "NT 6.0",
                7: "NT 6.1",
                8: "NT 6.2",
                8.1: "NT 6.3",
                10: ["NT 6.4", "NT 10.0"],
                RT: "ARM",
              },
              H = {
                browser: [
                  [/\b(?:crmo|crios)\/([\w\.]+)/i],
                  [f, [u, "Chrome"]],
                  [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                  [f, [u, "Edge"]],
                  [
                    /(opera mini)\/([-\w\.]+)/i,
                    /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i,
                    /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i,
                  ],
                  [u, f],
                  [/opios[\/ ]+([\w\.]+)/i],
                  [f, [u, I + " Mini"]],
                  [/\bopr\/([\w\.]+)/i],
                  [f, [u, I]],
                  [
                    /(kindle)\/([\w\.]+)/i,
                    /(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i,
                    /(avant |iemobile|slim)(?:browser)?[\/ ]?([\w\.]*)/i,
                    /(ba?idubrowser)[\/ ]?([\w\.]+)/i,
                    /(?:ms|\()(ie) ([\w\.]+)/i,
                    /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale|qqbrowserlite|qq|duckduckgo)\/([-\w\.]+)/i,
                    /(weibo)__([\d\.]+)/i,
                  ],
                  [u, f],
                  [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],
                  [f, [u, "UC" + E]],
                  [
                    /microm.+\bqbcore\/([\w\.]+)/i,
                    /\bqbcore\/([\w\.]+).+microm/i,
                  ],
                  [f, [u, "WeChat(Win) Desktop"]],
                  [/micromessenger\/([\w\.]+)/i],
                  [f, [u, "WeChat"]],
                  [/konqueror\/([\w\.]+)/i],
                  [f, [u, "Konqueror"]],
                  [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],
                  [f, [u, "IE"]],
                  [/yabrowser\/([\w\.]+)/i],
                  [f, [u, "Yandex"]],
                  [/(avast|avg)\/([\w\.]+)/i],
                  [[u, /(.+)/, "$1 Secure " + E], f],
                  [/\bfocus\/([\w\.]+)/i],
                  [f, [u, O + " Focus"]],
                  [/\bopt\/([\w\.]+)/i],
                  [f, [u, I + " Touch"]],
                  [/coc_coc\w+\/([\w\.]+)/i],
                  [f, [u, "Coc Coc"]],
                  [/dolfin\/([\w\.]+)/i],
                  [f, [u, "Dolphin"]],
                  [/coast\/([\w\.]+)/i],
                  [f, [u, I + " Coast"]],
                  [/miuibrowser\/([\w\.]+)/i],
                  [f, [u, "MIUI " + E]],
                  [/fxios\/([-\w\.]+)/i],
                  [f, [u, O]],
                  [/\bqihu|(qi?ho?o?|360)browser/i],
                  [[u, "360 " + E]],
                  [/(oculus|samsung|sailfish|huawei)browser\/([\w\.]+)/i],
                  [[u, /(.+)/, "$1 " + E], f],
                  [/(comodo_dragon)\/([\w\.]+)/i],
                  [[u, /_/g, " "], f],
                  [
                    /(electron)\/([\w\.]+) safari/i,
                    /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i,
                    /m?(qqbrowser|baiduboxapp|2345Explorer)[\/ ]?([\w\.]+)/i,
                  ],
                  [u, f],
                  [
                    /(metasr)[\/ ]?([\w\.]+)/i,
                    /(lbbrowser)/i,
                    /\[(linkedin)app\]/i,
                  ],
                  [u],
                  [
                    /((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i,
                  ],
                  [[u, U], f],
                  [
                    /safari (line)\/([\w\.]+)/i,
                    /\b(line)\/([\w\.]+)\/iab/i,
                    /(chromium|instagram)[\/ ]([-\w\.]+)/i,
                  ],
                  [u, f],
                  [/\bgsa\/([\w\.]+) .*safari\//i],
                  [f, [u, "GSA"]],
                  [/headlesschrome(?:\/([\w\.]+)| )/i],
                  [f, [u, _ + " Headless"]],
                  [/ wv\).+(chrome)\/([\w\.]+)/i],
                  [[u, _ + " WebView"], f],
                  [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],
                  [f, [u, "Android " + E]],
                  [
                    /(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i,
                  ],
                  [u, f],
                  [/version\/([\w\.\,]+) .*mobile\/\w+ (safari)/i],
                  [f, [u, "Mobile Safari"]],
                  [/version\/([\w(\.|\,)]+) .*(mobile ?safari|safari)/i],
                  [f, u],
                  [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],
                  [
                    u,
                    [
                      f,
                      z,
                      {
                        "1.0": "/8",
                        1.2: "/1",
                        1.3: "/3",
                        "2.0": "/412",
                        "2.0.2": "/416",
                        "2.0.3": "/417",
                        "2.0.4": "/419",
                        "?": "/",
                      },
                    ],
                  ],
                  [/(webkit|khtml)\/([\w\.]+)/i],
                  [u, f],
                  [/(navigator|netscape\d?)\/([-\w\.]+)/i],
                  [[u, "Netscape"], f],
                  [/mobile vr; rv:([\w\.]+)\).+firefox/i],
                  [f, [u, O + " Reality"]],
                  [
                    /ekiohf.+(flow)\/([\w\.]+)/i,
                    /(swiftfox)/i,
                    /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i,
                    /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i,
                    /(firefox)\/([\w\.]+)/i,
                    /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i,
                    /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,
                    /(links) \(([\w\.]+)/i,
                  ],
                  [u, f],
                  [/(cobalt)\/([\w\.]+)/i],
                  [u, [f, /master.|lts./, ""]],
                ],
                cpu: [
                  [/(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i],
                  [[p, "amd64"]],
                  [/(ia32(?=;))/i],
                  [[p, B]],
                  [/((?:i[346]|x)86)[;\)]/i],
                  [[p, "ia32"]],
                  [/\b(aarch64|arm(v?8e?l?|_?64))\b/i],
                  [[p, "arm64"]],
                  [/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i],
                  [[p, "armhf"]],
                  [/windows (ce|mobile); ppc;/i],
                  [[p, "arm"]],
                  [/((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i],
                  [[p, /ower/, "", B]],
                  [/(sun4\w)[;\)]/i],
                  [[p, "sparc"]],
                  [
                    /((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i,
                  ],
                  [[p, B]],
                ],
                device: [
                  [
                    /\b(sch-i[89]0\d|shw-m380s|sm-[ptx]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i,
                  ],
                  [l, [d, j], [c, g]],
                  [
                    /\b((?:s[cgp]h|gt|sm)-\w+|galaxy nexus)/i,
                    /samsung[- ]([-\w]+)/i,
                    /sec-(sgh\w+)/i,
                  ],
                  [l, [d, j], [c, h]],
                  [/((ipod|iphone)\d+,\d+)/i],
                  [l, [d, x], [c, h]],
                  [/(ipad\d+,\d+)/i],
                  [l, [d, x], [c, g]],
                  [/\((ip(?:hone|od)[\w ]*);/i],
                  [l, [d, x], [c, h]],
                  [
                    /\((ipad);[-\w\),; ]+apple/i,
                    /applecoremedia\/[\w\.]+ \((ipad)/i,
                    /\b(ipad)\d\d?,\d\d?[;\]].+ios/i,
                  ],
                  [l, [d, x], [c, g]],
                  [/(macintosh);/i],
                  [l, [d, x]],
                  [
                    /\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i,
                  ],
                  [l, [d, P], [c, g]],
                  [
                    /(?:huawei|honor)([-\w ]+)[;\)]/i,
                    /\b(nexus 6p|\w{2,4}e?-[atu]?[ln][\dx][012359c][adn]?)\b(?!.+d\/s)/i,
                  ],
                  [l, [d, P], [c, h]],
                  [
                    /\b(poco[\w ]+)(?: bui|\))/i,
                    /\b; (\w+) build\/hm\1/i,
                    /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i,
                    /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i,
                    /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max|cc)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i,
                  ],
                  [
                    [l, /_/g, " "],
                    [d, L],
                    [c, h],
                  ],
                  [/\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i],
                  [
                    [l, /_/g, " "],
                    [d, L],
                    [c, g],
                  ],
                  [
                    /; (\w+) bui.+ oppo/i,
                    /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i,
                  ],
                  [l, [d, "OPPO"], [c, h]],
                  [
                    /vivo (\w+)(?: bui|\))/i,
                    /\b(v[12]\d{3}\w?[at])(?: bui|;)/i,
                  ],
                  [l, [d, "Vivo"], [c, h]],
                  [/\b(rmx[12]\d{3})(?: bui|;|\))/i],
                  [l, [d, "Realme"], [c, h]],
                  [
                    /\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i,
                    /\bmot(?:orola)?[- ](\w*)/i,
                    /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i,
                  ],
                  [l, [d, T], [c, h]],
                  [/\b(mz60\d|xoom[2 ]{0,2}) build\//i],
                  [l, [d, T], [c, g]],
                  [
                    /((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i,
                  ],
                  [l, [d, C], [c, g]],
                  [
                    /(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i,
                    /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i,
                    /\blg-?([\d\w]+) bui/i,
                  ],
                  [l, [d, C], [c, h]],
                  [
                    /(ideatab[-\w ]+)/i,
                    /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i,
                  ],
                  [l, [d, "Lenovo"], [c, g]],
                  [
                    /(?:maemo|nokia).*(n900|lumia \d+)/i,
                    /nokia[-_ ]?([-\w\.]*)/i,
                  ],
                  [
                    [l, /_/g, " "],
                    [d, "Nokia"],
                    [c, h],
                  ],
                  [/(pixel c)\b/i],
                  [l, [d, A], [c, g]],
                  [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],
                  [l, [d, A], [c, h]],
                  [
                    /droid.+ (a?\d[0-2]{2}so|[c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i,
                  ],
                  [l, [d, V], [c, h]],
                  [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i],
                  [
                    [l, "Xperia Tablet"],
                    [d, V],
                    [c, g],
                  ],
                  [
                    / (kb2005|in20[12]5|be20[12][59])\b/i,
                    /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i,
                  ],
                  [l, [d, "OnePlus"], [c, h]],
                  [
                    /(alexa)webm/i,
                    /(kf[a-z]{2}wi)( bui|\))/i,
                    /(kf[a-z]+)( bui|\)).+silk\//i,
                  ],
                  [l, [d, w], [c, g]],
                  [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],
                  [
                    [l, /(.+)/g, "Fire Phone $1"],
                    [d, w],
                    [c, h],
                  ],
                  [/(playbook);[-\w\),; ]+(rim)/i],
                  [l, d, [c, g]],
                  [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i],
                  [l, [d, k], [c, h]],
                  [
                    /(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i,
                  ],
                  [l, [d, S], [c, g]],
                  [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
                  [l, [d, S], [c, h]],
                  [/(nexus 9)/i],
                  [l, [d, "HTC"], [c, g]],
                  [
                    /(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i,
                    /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i,
                    /(alcatel|geeksphone|nexian|panasonic|sony(?!-bra))[-_ ]?([-\w]*)/i,
                  ],
                  [d, [l, /_/g, " "], [c, h]],
                  [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],
                  [l, [d, "Acer"], [c, g]],
                  [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i],
                  [l, [d, "Meizu"], [c, h]],
                  [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],
                  [l, [d, N], [c, h]],
                  [
                    /(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[-_ ]?([-\w]*)/i,
                    /(hp) ([\w ]+\w)/i,
                    /(asus)-?(\w+)/i,
                    /(microsoft); (lumia[\w ]+)/i,
                    /(lenovo)[-_ ]?([-\w]+)/i,
                    /(jolla)/i,
                    /(oppo) ?([\w ]+) bui/i,
                  ],
                  [d, l, [c, h]],
                  [
                    /(archos) (gamepad2?)/i,
                    /(hp).+(touchpad(?!.+tablet)|tablet)/i,
                    /(kindle)\/([\w\.]+)/i,
                    /(nook)[\w ]+build\/(\w+)/i,
                    /(dell) (strea[kpr\d ]*[\dko])/i,
                    /(le[- ]+pan)[- ]+(\w{1,9}) bui/i,
                    /(trinity)[- ]*(t\d{3}) bui/i,
                    /(gigaset)[- ]+(q\w{1,9}) bui/i,
                    /(vodafone) ([\w ]+)(?:\)| bui)/i,
                  ],
                  [d, l, [c, g]],
                  [/(surface duo)/i],
                  [l, [d, M], [c, g]],
                  [/droid [\d\.]+; (fp\du?)(?: b|\))/i],
                  [l, [d, "Fairphone"], [c, h]],
                  [/(u304aa)/i],
                  [l, [d, "AT&T"], [c, h]],
                  [/\bsie-(\w*)/i],
                  [l, [d, "Siemens"], [c, h]],
                  [/\b(rct\w+) b/i],
                  [l, [d, "RCA"], [c, g]],
                  [/\b(venue[\d ]{2,7}) b/i],
                  [l, [d, "Dell"], [c, g]],
                  [/\b(q(?:mv|ta)\w+) b/i],
                  [l, [d, "Verizon"], [c, g]],
                  [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],
                  [l, [d, "Barnes & Noble"], [c, g]],
                  [/\b(tm\d{3}\w+) b/i],
                  [l, [d, "NuVision"], [c, g]],
                  [/\b(k88) b/i],
                  [l, [d, "ZTE"], [c, g]],
                  [/\b(nx\d{3}j) b/i],
                  [l, [d, "ZTE"], [c, h]],
                  [/\b(gen\d{3}) b.+49h/i],
                  [l, [d, "Swiss"], [c, h]],
                  [/\b(zur\d{3}) b/i],
                  [l, [d, "Swiss"], [c, g]],
                  [/\b((zeki)?tb.*\b) b/i],
                  [l, [d, "Zeki"], [c, g]],
                  [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i],
                  [[d, "Dragon Touch"], l, [c, g]],
                  [/\b(ns-?\w{0,9}) b/i],
                  [l, [d, "Insignia"], [c, g]],
                  [/\b((nxa|next)-?\w{0,9}) b/i],
                  [l, [d, "NextBook"], [c, g]],
                  [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],
                  [[d, "Voice"], l, [c, h]],
                  [/\b(lvtel\-)?(v1[12]) b/i],
                  [[d, "LvTel"], l, [c, h]],
                  [/\b(ph-1) /i],
                  [l, [d, "Essential"], [c, h]],
                  [/\b(v(100md|700na|7011|917g).*\b) b/i],
                  [l, [d, "Envizen"], [c, g]],
                  [/\b(trio[-\w\. ]+) b/i],
                  [l, [d, "MachSpeed"], [c, g]],
                  [/\btu_(1491) b/i],
                  [l, [d, "Rotor"], [c, g]],
                  [/(shield[\w ]+) b/i],
                  [l, [d, "Nvidia"], [c, g]],
                  [/(sprint) (\w+)/i],
                  [d, l, [c, h]],
                  [/(kin\.[onetw]{3})/i],
                  [
                    [l, /\./g, " "],
                    [d, M],
                    [c, h],
                  ],
                  [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                  [l, [d, D], [c, g]],
                  [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],
                  [l, [d, D], [c, h]],
                  [/(ouya)/i, /(nintendo) ([wids3utch]+)/i],
                  [d, l, [c, v]],
                  [/droid.+; (shield) bui/i],
                  [l, [d, "Nvidia"], [c, v]],
                  [/(playstation [345portablevi]+)/i],
                  [l, [d, V], [c, v]],
                  [/\b(xbox(?: one)?(?!; xbox))[\); ]/i],
                  [l, [d, M], [c, v]],
                  [/smart-tv.+(samsung)/i],
                  [d, [c, m]],
                  [/hbbtv.+maple;(\d+)/i],
                  [
                    [l, /^/, "SmartTV"],
                    [d, j],
                    [c, m],
                  ],
                  [
                    /(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i,
                  ],
                  [
                    [d, C],
                    [c, m],
                  ],
                  [/(apple) ?tv/i],
                  [d, [l, x + " TV"], [c, m]],
                  [/crkey/i],
                  [
                    [l, _ + "cast"],
                    [d, A],
                    [c, m],
                  ],
                  [/droid.+aft(\w)( bui|\))/i],
                  [l, [d, w], [c, m]],
                  [/\(dtv[\);].+(aquos)/i, /(aquos-tv[\w ]+)\)/i],
                  [l, [d, N], [c, m]],
                  [/(bravia[\w ]+)( bui|\))/i],
                  [l, [d, V], [c, m]],
                  [/(mitv-\w{5}) bui/i],
                  [l, [d, L], [c, m]],
                  [
                    /\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i,
                    /hbbtv\/\d+\.\d+\.\d+ +\([\w ]*; *(\w[^;]*);([^;]*)/i,
                  ],
                  [
                    [d, K],
                    [l, K],
                    [c, m],
                  ],
                  [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],
                  [[c, m]],
                  [/((pebble))app/i],
                  [d, l, [c, y]],
                  [/droid.+; (glass) \d/i],
                  [l, [d, A], [c, y]],
                  [/droid.+; (wt63?0{2,3})\)/i],
                  [l, [d, D], [c, y]],
                  [/(quest( 2)?)/i],
                  [l, [d, U], [c, y]],
                  [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],
                  [d, [c, b]],
                  [/droid .+?; ([^;]+?)(?: bui|\) applew).+? mobile safari/i],
                  [l, [c, h]],
                  [
                    /droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i,
                  ],
                  [l, [c, g]],
                  [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],
                  [[c, g]],
                  [
                    /(phone|mobile(?:[;\/]| [ \w\/\.]*safari)|pda(?=.+windows ce))/i,
                  ],
                  [[c, h]],
                  [/(android[-\w\. ]{0,9});.+buil/i],
                  [l, [d, "Generic"]],
                ],
                engine: [
                  [/windows.+ edge\/([\w\.]+)/i],
                  [f, [u, "EdgeHTML"]],
                  [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                  [f, [u, "Blink"]],
                  [
                    /(presto)\/([\w\.]+)/i,
                    /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i,
                    /ekioh(flow)\/([\w\.]+)/i,
                    /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i,
                    /(icab)[\/ ]([23]\.[\d\.]+)/i,
                  ],
                  [u, f],
                  [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                  [f, u],
                ],
                os: [
                  [/microsoft (windows) (vista|xp)/i],
                  [u, f],
                  [
                    /(windows) nt 6\.2; (arm)/i,
                    /(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i,
                    /(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i,
                  ],
                  [u, [f, z, W]],
                  [/(win(?=3|9|n)|win 9x )([nt\d\.]+)/i],
                  [
                    [u, "Windows"],
                    [f, z, W],
                  ],
                  [
                    /ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i,
                    /cfnetwork\/.+darwin/i,
                  ],
                  [
                    [f, /_/g, "."],
                    [u, "iOS"],
                  ],
                  [
                    /(mac os x) ?([\w\. ]*)/i,
                    /(macintosh|mac_powerpc\b)(?!.+haiku)/i,
                  ],
                  [
                    [u, "Mac OS"],
                    [f, /_/g, "."],
                  ],
                  [/droid ([\w\.]+)\b.+(android[- ]x86|harmonyos)/i],
                  [f, u],
                  [
                    /(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i,
                    /(blackberry)\w*\/([\w\.]*)/i,
                    /(tizen|kaios)[\/ ]([\w\.]+)/i,
                    /\((series40);/i,
                  ],
                  [u, f],
                  [/\(bb(10);/i],
                  [f, [u, k]],
                  [/(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i],
                  [f, [u, "Symbian"]],
                  [
                    /mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i,
                  ],
                  [f, [u, O + " OS"]],
                  [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                  [f, [u, "webOS"]],
                  [/crkey\/([\d\.]+)/i],
                  [f, [u, _ + "cast"]],
                  [/(cros) [\w]+ ([\w\.]+\w)/i],
                  [[u, "Chromium OS"], f],
                  [
                    /(nintendo|playstation) ([wids345portablevuch]+)/i,
                    /(xbox); +xbox ([^\);]+)/i,
                    /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,
                    /(mint)[\/\(\) ]?(\w*)/i,
                    /(mageia|vectorlinux)[; ]/i,
                    /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i,
                    /(hurd|linux) ?([\w\.]*)/i,
                    /(gnu) ?([\w\.]*)/i,
                    /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i,
                    /(haiku) (\w+)/i,
                  ],
                  [u, f],
                  [/(sunos) ?([\w\.\d]*)/i],
                  [[u, "Solaris"], f],
                  [
                    /((?:open)?solaris)[-\/ ]?([\w\.]*)/i,
                    /(aix) ((\d)(?=\.|\)| )[\w\.])*/i,
                    /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux)/i,
                    /(unix) ?([\w\.]*)/i,
                  ],
                  [u, f],
                ],
              },
              J = function (e, t) {
                if (
                  (typeof e === a && ((t = e), (e = n)), !(this instanceof J))
                )
                  return new J(e, t).getResult();
                var i =
                    e ||
                    (typeof r !== o && r.navigator && r.navigator.userAgent
                      ? r.navigator.userAgent
                      : ""),
                  v = t
                    ? (function (e, t) {
                        var r = {};
                        for (var n in e)
                          t[n] && t[n].length % 2 == 0
                            ? (r[n] = t[n].concat(e[n]))
                            : (r[n] = e[n]);
                        return r;
                      })(H, t)
                    : H;
                return (
                  (this.getBrowser = function () {
                    var e = {};
                    return (
                      (e[u] = n),
                      (e[f] = n),
                      q.call(e, i, v.browser),
                      (e.major = (function (e) {
                        return typeof e === s
                          ? e.replace(/[^\d\.]/g, "").split(".")[0]
                          : n;
                      })(e.version)),
                      e
                    );
                  }),
                  (this.getCPU = function () {
                    var e = {};
                    return (e[p] = n), q.call(e, i, v.cpu), e;
                  }),
                  (this.getDevice = function () {
                    var e = {};
                    return (
                      (e[d] = n),
                      (e[l] = n),
                      (e[c] = n),
                      q.call(e, i, v.device),
                      e
                    );
                  }),
                  (this.getEngine = function () {
                    var e = {};
                    return (e[u] = n), (e[f] = n), q.call(e, i, v.engine), e;
                  }),
                  (this.getOS = function () {
                    var e = {};
                    return (e[u] = n), (e[f] = n), q.call(e, i, v.os), e;
                  }),
                  (this.getResult = function () {
                    return {
                      ua: this.getUA(),
                      browser: this.getBrowser(),
                      engine: this.getEngine(),
                      os: this.getOS(),
                      device: this.getDevice(),
                      cpu: this.getCPU(),
                    };
                  }),
                  (this.getUA = function () {
                    return i;
                  }),
                  (this.setUA = function (e) {
                    return (
                      (i = typeof e === s && e.length > 350 ? K(e, 350) : e),
                      this
                    );
                  }),
                  this.setUA(i),
                  this
                );
              };
            (J.VERSION = "0.7.33"),
              (J.BROWSER = F([u, f, "major"])),
              (J.CPU = F([p])),
              (J.DEVICE = F([l, d, c, v, h, m, g, y, b])),
              (J.ENGINE = J.OS = F([u, f])),
              e.exports && (t = e.exports = J),
              (t.UAParser = J);
            var G = typeof r !== o && (r.jQuery || r.Zepto);
            if (G && !G.ua) {
              var X = new J();
              (G.ua = X.getResult()),
                (G.ua.get = function () {
                  return X.getUA();
                }),
                (G.ua.set = function (e) {
                  X.setUA(e);
                  var t = X.getResult();
                  for (var r in t) G.ua[r] = t[r];
                });
            }
          })("object" == typeof window ? window : Ie);
        }),
        je(
          (Ve = {
            path: Ne,
            exports: {},
            require: function (e, t) {
              return (function () {
                throw new Error(
                  "Dynamic requires are not currently supported by @rollup/plugin-commonjs"
                );
              })(null == t && Ve.path);
            },
          }),
          Ve.exports
        ),
        Ve.exports),
      De = (function () {
        function e(e) {
          this.amplitudeInstance = e;
        }
        return (
          (e.prototype.getUser = function () {
            var e, t, r, n, i, o, a, s, l, u;
            return {
              device_id:
                null ===
                  (t =
                    null === (e = this.amplitudeInstance) || void 0 === e
                      ? void 0
                      : e.options) || void 0 === t
                  ? void 0
                  : t.deviceId,
              user_id:
                null ===
                  (n =
                    null === (r = this.amplitudeInstance) || void 0 === r
                      ? void 0
                      : r.options) || void 0 === n
                  ? void 0
                  : n.userId,
              version:
                null ===
                  (o =
                    null === (i = this.amplitudeInstance) || void 0 === i
                      ? void 0
                      : i.options) || void 0 === o
                  ? void 0
                  : o.versionName,
              language:
                null ===
                  (s =
                    null === (a = this.amplitudeInstance) || void 0 === a
                      ? void 0
                      : a.options) || void 0 === s
                  ? void 0
                  : s.language,
              platform:
                null ===
                  (u =
                    null === (l = this.amplitudeInstance) || void 0 === l
                      ? void 0
                      : l.options) || void 0 === u
                  ? void 0
                  : u.platform,
              os: this.getOs(),
              device_model: this.getDeviceModel(),
            };
          }),
          (e.prototype.getOs = function () {
            var e, t, r, n, i, o;
            return [
              null ===
                (r =
                  null ===
                    (t =
                      null === (e = this.amplitudeInstance) || void 0 === e
                        ? void 0
                        : e._ua) || void 0 === t
                    ? void 0
                    : t.browser) || void 0 === r
                ? void 0
                : r.name,
              null ===
                (o =
                  null ===
                    (i =
                      null === (n = this.amplitudeInstance) || void 0 === n
                        ? void 0
                        : n._ua) || void 0 === i
                    ? void 0
                    : i.browser) || void 0 === o
                ? void 0
                : o.major,
            ]
              .filter(function (e) {
                return null != e;
              })
              .join(" ");
          }),
          (e.prototype.getDeviceModel = function () {
            var e, t, r;
            return null ===
              (r =
                null ===
                  (t =
                    null === (e = this.amplitudeInstance) || void 0 === e
                      ? void 0
                      : e._ua) || void 0 === t
                  ? void 0
                  : t.os) || void 0 === r
              ? void 0
              : r.name;
          }),
          e
        );
      })(),
      Ue = (function () {
        function e(e) {
          this.amplitudeInstance = e;
        }
        return (
          (e.prototype.track = function (e) {
            this.amplitudeInstance.logEvent(e.name, e.properties);
          }),
          (e.prototype.setUserProperty = function (e) {
            var t, r;
            this.amplitudeInstance.setUserProperties(
              (((t = {})[e.userProperty] =
                null === (r = e.variant) || void 0 === r ? void 0 : r.value),
              t)
            );
          }),
          (e.prototype.unsetUserProperty = function (e) {
            var t;
            this.amplitudeInstance._logEvent("$identify", null, null, {
              $unset: ((t = {}), (t[e.userProperty] = "-"), t),
            });
          }),
          e
        );
      })(),
      Fe = function () {
        return (
          (Fe =
            Object.assign ||
            function (e) {
              for (var t, r = 1, n = arguments.length; r < n; r++)
                for (var i in (t = arguments[r]))
                  Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
              return e;
            }),
          Fe.apply(this, arguments)
        );
      };
    /* @amplitude/experiment-js-client v1.21.0 - For license info see https://app.unpkg.com/@amplitude/experiment-js-client@1.21.0/files/LICENSE */ function Re(
      e,
      t,
      r,
      n
    ) {
      return new (r || (r = Promise))(function (i, o) {
        function a(e) {
          try {
            l(n.next(e));
          } catch (e) {
            o(e);
          }
        }
        function s(e) {
          try {
            l(n.throw(e));
          } catch (e) {
            o(e);
          }
        }
        function l(e) {
          var t;
          e.done
            ? i(e.value)
            : ((t = e.value),
              t instanceof r
                ? t
                : new r(function (e) {
                    e(t);
                  })).then(a, s);
        }
        l((n = n.apply(e, t || [])).next());
      });
    }
    function Be(e, t) {
      var r,
        n,
        i,
        o = {
          label: 0,
          sent: function () {
            if (1 & i[0]) throw i[1];
            return i[1];
          },
          trys: [],
          ops: [],
        },
        a = Object.create(
          ("function" == typeof Iterator ? Iterator : Object).prototype
        );
      return (
        (a.next = s(0)),
        (a.throw = s(1)),
        (a.return = s(2)),
        "function" == typeof Symbol &&
          (a[Symbol.iterator] = function () {
            return this;
          }),
        a
      );
      function s(s) {
        return function (l) {
          return (function (s) {
            if (r) throw new TypeError("Generator is already executing.");
            for (; a && ((a = 0), s[0] && (o = 0)), o; )
              try {
                if (
                  ((r = 1),
                  n &&
                    (i =
                      2 & s[0]
                        ? n.return
                        : s[0]
                        ? n.throw || ((i = n.return) && i.call(n), 0)
                        : n.next) &&
                    !(i = i.call(n, s[1])).done)
                )
                  return i;
                switch (((n = 0), i && (s = [2 & s[0], i.value]), s[0])) {
                  case 0:
                  case 1:
                    i = s;
                    break;
                  case 4:
                    return o.label++, { value: s[1], done: !1 };
                  case 5:
                    o.label++, (n = s[1]), (s = [0]);
                    continue;
                  case 7:
                    (s = o.ops.pop()), o.trys.pop();
                    continue;
                  default:
                    if (
                      !((i = o.trys),
                      (i = i.length > 0 && i[i.length - 1]) ||
                        (6 !== s[0] && 2 !== s[0]))
                    ) {
                      o = 0;
                      continue;
                    }
                    if (3 === s[0] && (!i || (s[1] > i[0] && s[1] < i[3]))) {
                      o.label = s[1];
                      break;
                    }
                    if (6 === s[0] && o.label < i[1]) {
                      (o.label = i[1]), (i = s);
                      break;
                    }
                    if (i && o.label < i[2]) {
                      (o.label = i[2]), o.ops.push(s);
                      break;
                    }
                    i[2] && o.ops.pop(), o.trys.pop();
                    continue;
                }
                s = t.call(e, o);
              } catch (e) {
                (s = [6, e]), (n = 0);
              } finally {
                r = i = 0;
              }
            if (5 & s[0]) throw s[1];
            return { value: s[0] ? s[1] : void 0, done: !0 };
          })([s, l]);
        };
      }
    }
    function Ke(e) {
      var t = "function" == typeof Symbol && Symbol.iterator,
        r = t && e[t],
        n = 0;
      if (r) return r.call(e);
      if (e && "number" == typeof e.length)
        return {
          next: function () {
            return (
              e && n >= e.length && (e = void 0),
              { value: e && e[n++], done: !e }
            );
          },
        };
      throw new TypeError(
        t ? "Object is not iterable." : "Symbol.iterator is not defined."
      );
    }
    function qe(e, t) {
      var r = "function" == typeof Symbol && e[Symbol.iterator];
      if (!r) return e;
      var n,
        i,
        o = r.call(e),
        a = [];
      try {
        for (; (void 0 === t || t-- > 0) && !(n = o.next()).done; )
          a.push(n.value);
      } catch (e) {
        i = { error: e };
      } finally {
        try {
          n && !n.done && (r = o.return) && r.call(o);
        } finally {
          if (i) throw i.error;
        }
      }
      return a;
    }
    function ze(e, t, r) {
      if (r || 2 === arguments.length)
        for (var n, i = 0, o = t.length; i < o; i++)
          (!n && i in t) ||
            (n || (n = Array.prototype.slice.call(t, 0, i)), (n[i] = t[i]));
      return e.concat(n || Array.prototype.slice.call(t));
    }
    "function" == typeof SuppressedError && SuppressedError;
    var We = function (e, t) {
        var r, n;
        void 0 === t && (t = !1);
        var i = He(e, t),
          o = void 0,
          a = ye.document.cookie.split("; ");
        try {
          for (var s = Ke(a), l = s.next(); !l.done; l = s.next()) {
            var u = qe(l.value.split("=", 2), 2),
              c = u[0],
              d = u[1];
            c === i && (o = decodeURIComponent(d));
          }
        } catch (e) {
          r = { error: e };
        } finally {
          try {
            l && !l.done && (n = s.return) && n.call(s);
          } finally {
            if (r) throw r.error;
          }
        }
        if (o)
          try {
            if (t) {
              var f = atob(o);
              return JSON.parse(decodeURIComponent(f));
            }
            var p = o.split("."),
              v = void 0;
            return (
              p.length >= 2 && p[1] && (v = atob(p[1])),
              { deviceId: p[0], userId: v }
            );
          } catch (e) {
            return;
          }
      },
      He = function (e, t) {
        if (t) {
          if ((null == e ? void 0 : e.length) < 10) return;
          return "AMP_".concat(e.substring(0, 10));
        }
        if (!((null == e ? void 0 : e.length) < 6))
          return "amp_".concat(e.substring(0, 6));
      },
      Je = (function () {
        function e(e, t, r) {
          (this.type = "integration"),
            (this.apiKey = e),
            (this.identityStore = t.identityStore),
            (this.eventBridge = t.eventBridge),
            (this.contextProvider = t.applicationContextProvider),
            (this.timeoutMillis = r),
            this.loadPersistedState(),
            r <= 0 && (this.setup = void 0);
        }
        return (
          (e.prototype.setup = function (e, t) {
            return Re(this, void 0, void 0, function () {
              return Be(this, function (r) {
                return (
                  (null == e
                    ? void 0
                    : e.automaticFetchOnAmplitudeIdentityChange) &&
                    this.identityStore.addIdentityListener(function () {
                      null == t || t.fetch();
                    }),
                  [2, this.waitForConnectorIdentity(this.timeoutMillis)]
                );
              });
            });
          }),
          (e.prototype.getUser = function () {
            var e = this.identityStore.getIdentity();
            return {
              user_id: e.userId,
              device_id: e.deviceId,
              user_properties: e.userProperties,
              version: this.contextProvider.versionName,
            };
          }),
          (e.prototype.track = function (e) {
            return (
              !!this.eventBridge.receiver &&
              (this.eventBridge.logEvent({
                eventType: e.eventType,
                eventProperties: e.eventProperties,
              }),
              !0)
            );
          }),
          (e.prototype.loadPersistedState = function () {
            if (!this.apiKey || this.apiKey.startsWith("client-")) return !1;
            var e = We(this.apiKey, !0);
            return (
              (e ||
                (e = We(this.apiKey, !1)) ||
                (e = (function (e) {
                  var t = He(e, !0);
                  try {
                    var r = ye.localStorage.getItem(t);
                    if (!r) return;
                    var n = JSON.parse(r);
                    if ("object" != typeof n) return;
                    return n;
                  } catch (e) {
                    return;
                  }
                })(this.apiKey)) ||
                !!(e = (function (e) {
                  var t = He(e, !0);
                  try {
                    var r = ye.sessionStorage.getItem(t);
                    if (!r) return;
                    var n = JSON.parse(r);
                    if ("object" != typeof n) return;
                    return n;
                  } catch (e) {
                    return;
                  }
                })(this.apiKey))) &&
              (this.commitIdentityToConnector(e), !0)
            );
          }),
          (e.prototype.commitIdentityToConnector = function (e) {
            var t = this.identityStore.editIdentity();
            t.setDeviceId(e.deviceId),
              e.userId && t.setUserId(e.userId),
              t.commit();
          }),
          (e.prototype.waitForConnectorIdentity = function (e) {
            return Re(this, void 0, void 0, function () {
              var t,
                r = this;
              return Be(this, function (n) {
                return (t = this.identityStore.getIdentity()).userId ||
                  t.deviceId
                  ? [2]
                  : [
                      2,
                      Promise.race([
                        new Promise(function (e) {
                          var t = function () {
                            e(), r.identityStore.removeIdentityListener(t);
                          };
                          r.identityStore.addIdentityListener(t);
                        }),
                        new Promise(function (t, r) {
                          ye.setTimeout(
                            r,
                            e,
                            "Timed out waiting for Amplitude Analytics SDK to initialize."
                          );
                        }),
                      ]),
                    ];
              });
            });
          }),
          e
        );
      })();
    var Ge,
      Xe,
      Qe,
      $e =
        ye.fetch ||
        function (e, t) {
          return (
            (t = t || {}),
            new Promise(function (r, n) {
              var i = new XMLHttpRequest(),
                o = [],
                a = [],
                s = {},
                l = function () {
                  return {
                    ok: 2 == ((i.status / 100) | 0),
                    statusText: i.statusText,
                    status: i.status,
                    url: i.responseURL,
                    text: function () {
                      return Promise.resolve(i.responseText);
                    },
                    json: function () {
                      return Promise.resolve(JSON.parse(i.responseText));
                    },
                    blob: function () {
                      return Promise.resolve(new Blob([i.response]));
                    },
                    clone: l,
                    headers: {
                      keys: function () {
                        return o;
                      },
                      entries: function () {
                        return a;
                      },
                      get: function (e) {
                        return s[e.toLowerCase()];
                      },
                      has: function (e) {
                        return e.toLowerCase() in s;
                      },
                    },
                  };
                };
              for (var u in (i.open(t.method || "get", e, !0),
              (i.onload = function () {
                i
                  .getAllResponseHeaders()
                  .replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, function (e, t, r) {
                    o.push((t = t.toLowerCase())),
                      a.push([t, r]),
                      (s[t] = s[t] ? s[t] + "," + r : r);
                  }),
                  r(l());
              }),
              (i.onerror = n),
              (i.withCredentials = "include" == t.credentials),
              t.headers))
                i.setRequestHeader(u, t.headers[u]);
              i.send(t.body || null);
            })
          );
        },
      Ze = (function () {
        function e(e) {
          this.client = e;
        }
        return (
          (e.prototype.request = function (e) {
            return Re(this, void 0, void 0, function () {
              return Be(this, function (t) {
                switch (t.label) {
                  case 0:
                    return [
                      4,
                      this.client.request(
                        e.requestUrl,
                        e.method,
                        e.headers,
                        null,
                        e.timeoutMillis
                      ),
                    ];
                  case 1:
                    return [2, t.sent()];
                }
              });
            });
          }),
          e
        );
      })(),
      Ye = {
        request: function (e, t, r, n, i) {
          return (function (e, t) {
            return null == t || t <= 0
              ? e
              : new Promise(function (r, n) {
                  ye.setTimeout(function () {
                    n(new he("Request timeout after " + t + " milliseconds"));
                  }, t),
                    e.then(r, n);
                });
          })(
            Re(void 0, void 0, void 0, function () {
              var i, o;
              return Be(this, function (a) {
                switch (a.label) {
                  case 0:
                    return [4, $e(e, { method: t, headers: r, body: n })];
                  case 1:
                    return (
                      (i = a.sent()), (o = { status: i.status }), [4, i.text()]
                    );
                  case 2:
                    return (o.body = a.sent()), [2, o];
                }
              });
            }),
            i
          );
        },
      };
    !(function (e) {
      (e[(e.Disable = 0)] = "Disable"),
        (e[(e.Error = 1)] = "Error"),
        (e[(e.Warn = 2)] = "Warn"),
        (e[(e.Info = 3)] = "Info"),
        (e[(e.Debug = 4)] = "Debug"),
        (e[(e.Verbose = 5)] = "Verbose");
    })(Ge || (Ge = {})),
      (function (e) {
        (e.LocalStorage = "localStorage"),
          (e.InitialVariants = "initialVariants");
      })(Xe || (Xe = {})),
      (function (e) {
        (e.LocalStorage = "storage"),
          (e.InitialVariants = "initial"),
          (e.SecondaryLocalStorage = "secondary-storage"),
          (e.SecondaryInitialVariants = "secondary-initial"),
          (e.FallbackInline = "fallback-inline"),
          (e.FallbackConfig = "fallback-config"),
          (e.LocalEvaluation = "local-evaluation");
      })(Qe || (Qe = {}));
    var et = function (e) {
        return (
          !e ||
          e === Qe.FallbackInline ||
          e === Qe.FallbackConfig ||
          e === Qe.SecondaryInitialVariants
        );
      },
      tt = {
        debug: !1,
        logLevel: Ge.Error,
        loggerProvider: null,
        instanceName: "$default_instance",
        fallbackVariant: {},
        initialVariants: {},
        initialFlags: void 0,
        source: Xe.LocalStorage,
        serverUrl: "https://api.lab.amplitude.com",
        flagsServerUrl: "https://flag.lab.amplitude.com",
        serverZone: "US",
        fetchTimeoutMillis: 1e4,
        retryFetchOnFailure: !0,
        throwOnError: !1,
        automaticExposureTracking: !0,
        pollOnStart: !0,
        flagConfigPollingIntervalMillis: 3e5,
        fetchOnStart: !0,
        automaticFetchOnAmplitudeIdentityChange: !1,
        userProvider: null,
        analyticsProvider: null,
        exposureTrackingProvider: null,
        httpClient: Ye,
      },
      rt = "1.21.0",
      nt = (function () {
        function e(e, t) {
          var r,
            n = this;
          (this.isReady = new Promise(function (e) {
            n.resolve = e;
          })),
            (this.config = e),
            (this.client = t);
          var i =
            null !== (r = e.instanceName) && void 0 !== r ? r : tt.instanceName;
          (this.queue = new ot(i)), (this.cache = new it(i));
        }
        return (
          (e.prototype.ready = function () {
            return this.integration ? this.isReady : Promise.resolve();
          }),
          (e.prototype.setIntegration = function (e) {
            var t = this;
            this.integration &&
              this.integration.teardown &&
              this.integration.teardown(),
              (this.integration = e),
              e.setup
                ? this.integration.setup(this.config, this.client).then(
                    function () {
                      t.queue.setTracker(t.integration.track.bind(e)),
                        t.resolve();
                    },
                    function () {
                      t.queue.setTracker(t.integration.track.bind(e)),
                        t.resolve();
                    }
                  )
                : (this.queue.setTracker(this.integration.track.bind(e)),
                  this.resolve());
          }),
          (e.prototype.getUser = function () {
            return this.integration ? this.integration.getUser() : {};
          }),
          (e.prototype.track = function (e, t) {
            if (this.cache.shouldTrack(e, t)) {
              var r = this.getExposureEvent(e);
              this.queue.push(r);
            }
          }),
          (e.prototype.getExposureEvent = function (e) {
            var t,
              r,
              n,
              i = { eventType: "$exposure", eventProperties: e };
            return (
              (
                null === (t = e.metadata) || void 0 === t
                  ? void 0
                  : t.exposureEvent
              )
                ? (i = {
                    eventType:
                      null === (r = e.metadata) || void 0 === r
                        ? void 0
                        : r.exposureEvent,
                    eventProperties: e,
                  })
                : "web" ===
                    (null === (n = e.metadata) || void 0 === n
                      ? void 0
                      : n.deliveryMethod) &&
                  (i = { eventType: "$impression", eventProperties: e }),
              i
            );
          }),
          e
        );
      })(),
      it = (function () {
        function e(e) {
          (this.isSessionStorageAvailable = at()),
            (this.inMemoryCache = {}),
            (this.identity = {}),
            (this.storageKey = "EXP_sent_v3_".concat(e)),
            this.isSessionStorageAvailable &&
              (ye.sessionStorage.removeItem("EXP_sent_".concat(e)),
              ye.sessionStorage.removeItem("EXP_sent_v2_".concat(e)));
        }
        return (
          (e.prototype.shouldTrack = function (e, t) {
            var r, n;
            if (
              "web" ===
              (null === (r = e.metadata) || void 0 === r
                ? void 0
                : r.deliveryMethod)
            )
              return !0;
            var i = {
              userId: null == t ? void 0 : t.user_id,
              deviceId: null == t ? void 0 : t.device_id,
            };
            this.identityEquals(this.identity, i) || this.clearCache(),
              (this.identity = i),
              this.loadCache();
            var o = e.flag_key in this.inMemoryCache,
              a = this.inMemoryCache[e.flag_key],
              s = null !== (n = e.variant) && void 0 !== n ? n : null,
              l = !1;
            return (
              (o && (null != a ? a : null) === s) ||
                ((l = !0), (this.inMemoryCache[e.flag_key] = s)),
              this.storeCache(),
              l
            );
          }),
          (e.prototype.clearCache = function () {
            (this.inMemoryCache = {}),
              this.isSessionStorageAvailable &&
                ye.sessionStorage.removeItem(this.storageKey);
          }),
          (e.prototype.identityEquals = function (e, t) {
            return e.userId && t.userId
              ? e.userId === t.userId
              : !e.userId && !t.userId && e.deviceId === t.deviceId;
          }),
          (e.prototype.loadCache = function () {
            if (this.isSessionStorageAvailable) {
              var e = ye.sessionStorage.getItem(this.storageKey);
              this.inMemoryCache = e ? JSON.parse(e) : {};
            }
          }),
          (e.prototype.storeCache = function () {
            if (this.isSessionStorageAvailable)
              try {
                ye.sessionStorage.setItem(
                  this.storageKey,
                  JSON.stringify(this.inMemoryCache)
                );
              } catch (e) {}
          }),
          e
        );
      })(),
      ot = (function () {
        function e(e, t) {
          void 0 === t && (t = 512),
            (this.isLocalStorageAvailable = we()),
            (this.inMemoryQueue = []),
            (this.storageKey = "EXP_unsent_".concat(e)),
            (this.maxQueueSize = t);
        }
        return (
          (e.prototype.push = function (e) {
            this.loadQueue(),
              this.inMemoryQueue.push(e),
              this.flush(),
              this.storeQueue();
          }),
          (e.prototype.setTracker = function (e) {
            var t = this;
            (this.tracker = e),
              (this.poller = ye.setInterval(function () {
                t.loadFlushStore();
              }, 1e3)),
              this.loadFlushStore();
          }),
          (e.prototype.flush = function () {
            if (this.tracker && 0 !== this.inMemoryQueue.length) {
              for (var e = 0; e < this.inMemoryQueue.length; e++)
                try {
                  if (!this.tracker(this.inMemoryQueue[e])) break;
                } catch (e) {
                  break;
                }
              (this.inMemoryQueue = this.inMemoryQueue.slice(e)),
                0 === this.inMemoryQueue.length &&
                  this.poller &&
                  (ye.clearInterval(this.poller), (this.poller = void 0));
            }
          }),
          (e.prototype.loadQueue = function () {
            if (this.isLocalStorageAvailable) {
              var e = ye.localStorage.getItem(this.storageKey);
              this.inMemoryQueue = e ? JSON.parse(e) : [];
            }
          }),
          (e.prototype.storeQueue = function () {
            this.isLocalStorageAvailable &&
              (this.inMemoryQueue.length > this.maxQueueSize &&
                (this.inMemoryQueue = this.inMemoryQueue.slice(
                  this.inMemoryQueue.length - this.maxQueueSize
                )),
              ye.localStorage.setItem(
                this.storageKey,
                JSON.stringify(this.inMemoryQueue)
              ));
          }),
          (e.prototype.loadFlushStore = function () {
            this.loadQueue(), this.flush(), this.storeQueue();
          }),
          e
        );
      })(),
      at = function () {
        var e = be();
        if (e)
          try {
            var t = "EXP_test";
            return (
              e.sessionStorage.setItem(t, t), e.sessionStorage.removeItem(t), !0
            );
          } catch (e) {
            return !1;
          }
        return !1;
      },
      st = (function () {
        function e(e, t) {
          void 0 === t && (t = Ge.Error),
            (this.logger = e),
            (this.logLevel = t);
        }
        return (
          (e.prototype.error = function (e) {
            for (var t, r = [], n = 1; n < arguments.length; n++)
              r[n - 1] = arguments[n];
            this.logLevel >= Ge.Error &&
              (t = this.logger).error.apply(t, ze([e], qe(r), !1));
          }),
          (e.prototype.warn = function (e) {
            for (var t, r = [], n = 1; n < arguments.length; n++)
              r[n - 1] = arguments[n];
            this.logLevel >= Ge.Warn &&
              (t = this.logger).warn.apply(t, ze([e], qe(r), !1));
          }),
          (e.prototype.info = function (e) {
            for (var t, r = [], n = 1; n < arguments.length; n++)
              r[n - 1] = arguments[n];
            this.logLevel >= Ge.Info &&
              (t = this.logger).info.apply(t, ze([e], qe(r), !1));
          }),
          (e.prototype.debug = function (e) {
            for (var t, r = [], n = 1; n < arguments.length; n++)
              r[n - 1] = arguments[n];
            this.logLevel >= Ge.Debug &&
              (t = this.logger).debug.apply(t, ze([e], qe(r), !1));
          }),
          (e.prototype.verbose = function (e) {
            for (var t, r = [], n = 1; n < arguments.length; n++)
              r[n - 1] = arguments[n];
            this.logLevel >= Ge.Verbose &&
              (t = this.logger).verbose.apply(t, ze([e], qe(r), !1));
          }),
          e
        );
      })(),
      lt = (function () {
        function e() {}
        return (
          (e.prototype.error = function (e) {
            for (var t = [], r = 1; r < arguments.length; r++)
              t[r - 1] = arguments[r];
            console.error.apply(console, ze([e], qe(t), !1));
          }),
          (e.prototype.warn = function (e) {
            for (var t = [], r = 1; r < arguments.length; r++)
              t[r - 1] = arguments[r];
            console.warn.apply(console, ze([e], qe(t), !1));
          }),
          (e.prototype.info = function (e) {
            for (var t = [], r = 1; r < arguments.length; r++)
              t[r - 1] = arguments[r];
            console.info.apply(console, ze([e], qe(t), !1));
          }),
          (e.prototype.debug = function (e) {
            for (var t = [], r = 1; r < arguments.length; r++)
              t[r - 1] = arguments[r];
            console.debug.apply(console, ze([e], qe(t), !1));
          }),
          (e.prototype.verbose = function (e) {
            for (var t = [], r = 1; r < arguments.length; r++)
              t[r - 1] = arguments[r];
            console.debug.apply(console, ze([e], qe(t), !1));
          }),
          e
        );
      })(),
      ut = (function () {
        function e() {
          this.globalScope = be();
        }
        return (
          (e.prototype.get = function (e) {
            var t;
            return null === (t = this.globalScope) || void 0 === t
              ? void 0
              : t.localStorage.getItem(e);
          }),
          (e.prototype.put = function (e, t) {
            var r;
            null === (r = this.globalScope) ||
              void 0 === r ||
              r.localStorage.setItem(e, t);
          }),
          (e.prototype.delete = function (e) {
            var t;
            null === (t = this.globalScope) ||
              void 0 === t ||
              t.localStorage.removeItem(e);
          }),
          e
        );
      })(),
      ct = (function () {
        function e(e, t) {
          (this.namespace = e), (this.storage = t);
        }
        return (
          (e.prototype.get = function () {
            return this.value;
          }),
          (e.prototype.put = function (e) {
            this.value = e;
          }),
          (e.prototype.load = function () {
            var e = this.storage.get(this.namespace);
            e && (this.value = JSON.parse(e));
          }),
          (e.prototype.store = function () {
            void 0 === this.value
              ? this.storage.delete(this.namespace)
              : this.storage.put(this.namespace, JSON.stringify(this.value));
          }),
          e
        );
      })(),
      dt = (function () {
        function e(e, t, r) {
          (this.cache = {}),
            (this.namespace = e),
            (this.storage = t),
            (this.transformer = r);
        }
        return (
          (e.prototype.get = function (e) {
            return this.cache[e];
          }),
          (e.prototype.getAll = function () {
            return Fe({}, this.cache);
          }),
          (e.prototype.put = function (e, t) {
            this.cache[e] = t;
          }),
          (e.prototype.putAll = function (e) {
            var t, r;
            try {
              for (
                var n = Ke(Object.keys(e)), i = n.next();
                !i.done;
                i = n.next()
              ) {
                var o = i.value;
                this.cache[o] = e[o];
              }
            } catch (e) {
              t = { error: e };
            } finally {
              try {
                i && !i.done && (r = n.return) && r.call(n);
              } finally {
                if (t) throw t.error;
              }
            }
          }),
          (e.prototype.remove = function (e) {
            delete this.cache[e];
          }),
          (e.prototype.clear = function () {
            this.cache = {};
          }),
          (e.prototype.load = function () {
            var e,
              t,
              r,
              n = this.storage.get(this.namespace);
            try {
              r = JSON.parse(n) || {};
            } catch (e) {
              return;
            }
            var i = {};
            try {
              for (
                var o = Ke(Object.keys(r)), a = o.next();
                !a.done;
                a = o.next()
              ) {
                var s = a.value;
                try {
                  var l = void 0;
                  (l = this.transformer ? this.transformer(r[s]) : r[s]) &&
                    (i[s] = l);
                } catch (e) {}
              }
            } catch (t) {
              e = { error: t };
            } finally {
              try {
                a && !a.done && (t = o.return) && t.call(o);
              } finally {
                if (e) throw e.error;
              }
            }
            this.clear(), this.putAll(i);
          }),
          (e.prototype.store = function (e) {
            void 0 === e && (e = this.cache),
              this.storage.put(this.namespace, JSON.stringify(e));
          }),
          e
        );
      })(),
      ft = function (e) {
        if ("string" == typeof e) return { key: e, value: e };
        if ("object" == typeof e) {
          var t = e.key,
            r = e.value,
            n = e.payload,
            i = e.metadata,
            o = e.expKey;
          i && i.experimentKey
            ? (o = i.experimentKey)
            : o && ((i = i || {}).experimentKey = o);
          var a = {};
          return (
            t ? (a.key = t) : r && (a.key = r),
            r && (a.value = r),
            i && (a.metadata = i),
            n && (a.payload = n),
            o && (a.expKey = o),
            a
          );
        }
      },
      pt = (function () {
        function e() {
          this.globalScope = be();
        }
        return (
          (e.prototype.get = function (e) {
            var t;
            return null === (t = this.globalScope) || void 0 === t
              ? void 0
              : t.sessionStorage.getItem(e);
          }),
          (e.prototype.put = function (e, t) {
            var r;
            null === (r = this.globalScope) ||
              void 0 === r ||
              r.sessionStorage.setItem(e, t);
          }),
          (e.prototype.delete = function (e) {
            var t;
            null === (t = this.globalScope) ||
              void 0 === t ||
              t.sessionStorage.removeItem(e);
          }),
          e
        );
      })(),
      vt = function (e) {
        return null == e;
      },
      ht = function (e) {
        return !!vt(e) || (e && 0 === Object.keys(e).length);
      },
      gt = function (e) {
        var t;
        return (
          "local" ===
          (null === (t = null == e ? void 0 : e.metadata) || void 0 === t
            ? void 0
            : t.evaluationMode)
        );
      },
      mt = (function () {
        function e(e, t, r, n) {
          (this.started = !1),
            (this.done = !1),
            (this.attempts = e),
            (this.min = t),
            (this.max = r),
            (this.scalar = n);
        }
        return (
          (e.prototype.start = function (e) {
            return Re(this, void 0, void 0, function () {
              return Be(this, function (t) {
                switch (t.label) {
                  case 0:
                    if (this.started) throw Error("Backoff already started");
                    return (
                      (this.started = !0), [4, this.backoff(e, 0, this.min)]
                    );
                  case 1:
                    return t.sent(), [2];
                }
              });
            });
          }),
          (e.prototype.cancel = function () {
            (this.done = !0), clearTimeout(this.timeoutHandle);
          }),
          (e.prototype.backoff = function (e, t, r) {
            return Re(this, void 0, void 0, function () {
              var n = this;
              return Be(this, function (i) {
                return (
                  this.done ||
                    (this.timeoutHandle = ye.setTimeout(function () {
                      return Re(n, void 0, void 0, function () {
                        var n, i;
                        return Be(this, function (o) {
                          switch (o.label) {
                            case 0:
                              return o.trys.push([0, 2, , 3]), [4, e()];
                            case 1:
                              return o.sent(), [3, 3];
                            case 2:
                              return (
                                o.sent(),
                                (n = t + 1) < this.attempts &&
                                  ((i = Math.min(r * this.scalar, this.max)),
                                  this.backoff(e, n, i)),
                                [3, 3]
                              );
                            case 3:
                              return [2];
                          }
                        });
                      });
                    }, r)),
                  [2]
                );
              });
            });
          }),
          e
        );
      })(),
      yt = function (e) {
        var t, r, n, i;
        if (!e) return {};
        var o = { user: e },
          a = be();
        a && (o.page = { url: a.location.href });
        var s = {};
        if (!e.groups) return o;
        try {
          for (
            var l = Ke(Object.keys(e.groups)), u = l.next();
            !u.done;
            u = l.next()
          ) {
            var c = u.value,
              d = e.groups[c];
            if (d.length > 0 && d[0]) {
              var f = d[0],
                p = { group_name: f },
                v =
                  null ===
                    (i =
                      null === (n = e.group_properties) || void 0 === n
                        ? void 0
                        : n[c]) || void 0 === i
                    ? void 0
                    : i[f];
              v && Object.keys(v).length > 0 && (p.group_properties = v),
                (s[c] = p);
            }
          }
        } catch (e) {
          t = { error: e };
        } finally {
          try {
            u && !u.done && (r = l.return) && r.call(l);
          } finally {
            if (t) throw t.error;
          }
        }
        return (
          Object.keys(s).length > 0 && (o.groups = s),
          delete o.user.groups,
          delete o.user.group_properties,
          o
        );
      },
      bt = function (e) {
        return null == e ? {} : "string" == typeof e ? { key: e, value: e } : e;
      },
      wt = function (e) {
        if (!e) return {};
        var t = void 0;
        e.metadata && (t = e.metadata.experimentKey);
        var r = {};
        return (
          e.key && (r.key = e.key),
          e.value && (r.value = e.value),
          e.payload && (r.payload = e.payload),
          t && (r.expKey = t),
          e.metadata && (r.metadata = e.metadata),
          r
        );
      },
      xt = (function () {
        function e(e) {
          (this.setProperties = {}),
            (this.unsetProperties = {}),
            (this.analyticsProvider = e);
        }
        return (
          (e.prototype.track = function (e) {
            this.setProperties[e.key] != e.variant.value &&
              ((this.setProperties[e.key] = e.variant.value),
              delete this.unsetProperties[e.key],
              this.analyticsProvider.track(e));
          }),
          (e.prototype.setUserProperty = function (e) {
            this.setProperties[e.key] != e.variant.value &&
              this.analyticsProvider.setUserProperty(e);
          }),
          (e.prototype.unsetUserProperty = function (e) {
            this.unsetProperties[e.key] ||
              ((this.unsetProperties[e.key] = "unset"),
              delete this.setProperties[e.key],
              this.analyticsProvider.unsetUserProperty(e));
          }),
          e
        );
      })(),
      St = (function () {
        function e(e) {
          (this.tracked = {}),
            (this.identity = {}),
            (this.exposureTrackingProvider = e);
        }
        return (
          (e.prototype.track = function (e, t) {
            var r = {
              userId: null == t ? void 0 : t.user_id,
              deviceId: null == t ? void 0 : t.device_id,
            };
            this.identityEquals(this.identity, r) || (this.tracked = {}),
              (this.identity = r);
            var n = e.flag_key in this.tracked,
              i = this.tracked[e.flag_key];
            (n && i === e.variant) ||
              ((this.tracked[e.flag_key] = e.variant),
              this.exposureTrackingProvider.track(e));
          }),
          (e.prototype.identityEquals = function (e, t) {
            return e.userId === t.userId && e.deviceId === t.deviceId;
          }),
          e
        );
      })(),
      kt = (function () {
        function e(t, r) {
          var n,
            i,
            o,
            a,
            s = this;
          (this.engine = new H()),
            (this.isRunning = !1),
            (this.apiKey = t),
            (r = (function (e) {
              var t, r;
              if (!e || "object" != typeof e) return {};
              var n = {};
              try {
                for (
                  var i = Ke(Object.entries(e)), o = i.next();
                  !o.done;
                  o = i.next()
                ) {
                  var a = qe(o.value, 2),
                    s = a[0],
                    l = a[1];
                  vt(l) || (n[s] = l);
                }
              } catch (e) {
                t = { error: e };
              } finally {
                try {
                  o && !o.done && (r = i.return) && r.call(i);
                } finally {
                  if (t) throw t.error;
                }
              }
              return n;
            })(r)),
            (this.config = Fe(Fe(Fe({}, tt), r), {
              serverUrl:
                (null == r ? void 0 : r.serverUrl) ||
                ("eu" ===
                (null === (n = null == r ? void 0 : r.serverZone) ||
                void 0 === n
                  ? void 0
                  : n.toLowerCase())
                  ? "https://api.lab.eu.amplitude.com"
                  : tt.serverUrl),
              flagsServerUrl:
                (null == r ? void 0 : r.flagsServerUrl) ||
                ("eu" ===
                (null === (i = null == r ? void 0 : r.serverZone) ||
                void 0 === i
                  ? void 0
                  : i.toLowerCase())
                  ? "https://flag.lab.eu.amplitude.com"
                  : tt.flagsServerUrl),
              flagConfigPollingIntervalMillis:
                r.flagConfigPollingIntervalMillis < 6e4
                  ? 6e4
                  : null !== (o = r.flagConfigPollingIntervalMillis) &&
                    void 0 !== o
                  ? o
                  : tt.flagConfigPollingIntervalMillis,
            })),
            (this.logger = new st(
              this.config.loggerProvider || new lt(),
              e.getLogLevel(r)
            ));
          var l =
            null === (a = this.config) || void 0 === a
              ? void 0
              : a.internalInstanceNameSuffix;
          if (
            ((this.isWebExperiment = "web" === l),
            (this.poller = new xe(function () {
              return Re(s, void 0, void 0, function () {
                var e;
                return Be(this, function (t) {
                  switch (t.label) {
                    case 0:
                      return t.trys.push([0, 2, , 3]), [4, this.doFlags()];
                    case 1:
                      return t.sent(), [3, 3];
                    case 2:
                      return (e = t.sent()), this.logger.info(e), [3, 3];
                    case 3:
                      return [2];
                  }
                });
              });
            }, this.config.flagConfigPollingIntervalMillis)),
            this.config.initialVariants)
          )
            for (var u in this.config.initialVariants)
              this.config.initialVariants[u] = ft(
                this.config.initialVariants[u]
              );
          this.config.userProvider &&
            (this.userProvider = this.config.userProvider),
            this.config.analyticsProvider &&
              (this.analyticsProvider = new xt(this.config.analyticsProvider)),
            this.config.exposureTrackingProvider &&
              (this.userSessionExposureTracker = new St(
                this.config.exposureTrackingProvider
              )),
            (this.integrationManager = new nt(this.config, this));
          var c,
            d = new Ze(this.config.httpClient || Ye);
          (this.flagApi = new me(this.apiKey, this.config.flagsServerUrl, d)),
            (this.evaluationApi = new ge(
              this.apiKey,
              this.config.serverUrl,
              d
            ));
          var f = l
            ? "".concat(this.config.instanceName, "-").concat(l)
            : this.config.instanceName;
          (c = this.isWebExperiment ? new pt() : new ut()),
            (this.variants = (function (e, t, r) {
              var n = e.substring(e.length - 6),
                i = "amp-exp-".concat(t, "-").concat(n);
              return new dt(i, r, ft);
            })(this.apiKey, f, c)),
            (this.flags = (function (e, t, r) {
              void 0 === r && (r = new ut());
              var n = e.substring(e.length - 6),
                i = "amp-exp-".concat(t, "-").concat(n, "-flags");
              return new dt(i, r);
            })(this.apiKey, f, c)),
            (this.fetchVariantsOptions = (function (e, t, r) {
              void 0 === r && (r = new ut());
              var n = e.substring(e.length - 6),
                i = "amp-exp-".concat(t, "-").concat(n, "-variants-options");
              return new ct(i, r);
            })(this.apiKey, f, c));
          try {
            this.flags.load(),
              this.variants.load(),
              this.fetchVariantsOptions.load();
          } catch (e) {}
          this.mergeInitialFlagsWithStorage();
        }
        return (
          (e.prototype.start = function (e) {
            return Re(this, void 0, void 0, function () {
              var t, r, n;
              return Be(this, function (i) {
                switch (i.label) {
                  case 0:
                    if (this.isRunning) return [2];
                    (this.isRunning = !0), this.setUser(e), (i.label = 1);
                  case 1:
                    return (
                      i.trys.push([1, 6, , 7]),
                      (t = this.doFlags()),
                      null === (n = this.config.fetchOnStart) ||
                      void 0 === n ||
                      n
                        ? [4, Promise.all([this.fetch(e), t])]
                        : [3, 3]
                    );
                  case 2:
                    return i.sent(), [3, 5];
                  case 3:
                    return [4, t];
                  case 4:
                    i.sent(), (i.label = 5);
                  case 5:
                    return [3, 7];
                  case 6:
                    if (((r = i.sent()), this.config.throwOnError)) throw r;
                    return [3, 7];
                  case 7:
                    return this.config.pollOnStart && this.poller.start(), [2];
                }
              });
            });
          }),
          (e.prototype.stop = function () {
            this.isRunning && (this.poller.stop(), (this.isRunning = !1));
          }),
          (e.prototype.fetch = function () {
            return Re(this, arguments, void 0, function (e, t) {
              var r;
              return (
                void 0 === e && (e = this.user),
                Be(this, function (n) {
                  switch (n.label) {
                    case 0:
                      this.setUser(e || {}), (n.label = 1);
                    case 1:
                      return (
                        n.trys.push([1, 3, , 4]),
                        [
                          4,
                          this.fetchInternal(
                            e,
                            this.config.fetchTimeoutMillis,
                            this.config.retryFetchOnFailure,
                            t
                          ),
                        ]
                      );
                    case 2:
                      return n.sent(), [3, 4];
                    case 3:
                      if (((r = n.sent()), this.config.throwOnError)) throw r;
                      return (
                        r instanceof he
                          ? this.logger.debug(r)
                          : this.logger.error(r),
                        [3, 4]
                      );
                    case 4:
                      return [2, this];
                  }
                })
              );
            });
          }),
          (e.prototype.variant = function (e, t) {
            var r, n;
            if (!this.apiKey) return { value: void 0 };
            var i = this.variantAndSource(e, t);
            return (
              this.config.automaticExposureTracking &&
                this.exposureInternal(e, i),
              this.logger.debug(
                "[Experiment] variant for "
                  .concat(e, " is ")
                  .concat(
                    (null === (r = i.variant) || void 0 === r
                      ? void 0
                      : r.key) ||
                      (null === (n = i.variant) || void 0 === n
                        ? void 0
                        : n.value)
                  )
              ),
              i.variant || {}
            );
          }),
          (e.prototype.exposure = function (e) {
            var t = this.variantAndSource(e);
            this.exposureInternal(e, t);
          }),
          (e.prototype.all = function () {
            if (!this.apiKey) return {};
            var e = this.evaluate();
            for (var t in e) {
              var r = this.flags.get(t);
              gt(r) || delete e[t];
            }
            return Fe(
              Fe(Fe({}, this.secondaryVariants()), this.sourceVariants()),
              e
            );
          }),
          (e.prototype.clear = function () {
            this.variants.clear();
            try {
              this.variants.store();
            } catch (e) {}
          }),
          (e.prototype.getUser = function () {
            var e;
            if (!this.user) return this.user;
            if (
              null === (e = this.user) || void 0 === e
                ? void 0
                : e.user_properties
            ) {
              var t = Fe({}, this.user.user_properties);
              return Fe(Fe({}, this.user), { user_properties: t });
            }
            return Fe({}, this.user);
          }),
          (e.prototype.setUser = function (e) {
            var t;
            if (e)
              if (
                null === (t = this.user) || void 0 === t
                  ? void 0
                  : t.user_properties
              ) {
                var r = Fe({}, e.user_properties);
                this.user = Fe(Fe({}, e), { user_properties: r });
              } else this.user = Fe({}, e);
            else this.user = null;
          }),
          (e.prototype.getUserProvider = function () {
            return this.userProvider;
          }),
          (e.prototype.setUserProvider = function (e) {
            return (this.userProvider = e), this;
          }),
          (e.prototype.mergeInitialFlagsWithStorage = function () {
            var e = this;
            this.config.initialFlags &&
              JSON.parse(this.config.initialFlags).forEach(function (t) {
                e.flags.get(t.key) || e.flags.put(t.key, t);
              });
          }),
          (e.prototype.evaluate = function (e) {
            var t,
              r,
              n = this.addContext(this.user),
              i = J(this.flags.getAll(), e),
              o = yt(n),
              a = this.engine.evaluate(o, i),
              s = {};
            try {
              for (
                var l = Ke(Object.keys(a)), u = l.next();
                !u.done;
                u = l.next()
              ) {
                var c = u.value;
                s[c] = wt(a[c]);
              }
            } catch (e) {
              t = { error: e };
            } finally {
              try {
                u && !u.done && (r = l.return) && r.call(l);
              } finally {
                if (t) throw t.error;
              }
            }
            return s;
          }),
          (e.prototype.getEvaluationTraces = function (e) {
            var t = this.addContext(this.user),
              r = J(this.flags.getAll(), e),
              n = yt(t);
            return this.engine.evaluateWithTraces(n, r).traces;
          }),
          (e.prototype.variantAndSource = function (e, t) {
            var r = {};
            this.config.source === Xe.LocalStorage
              ? (r = this.localStorageVariantAndSource(e, t))
              : this.config.source === Xe.InitialVariants &&
                (r = this.initialVariantsVariantAndSource(e, t));
            var n = this.flags.get(e);
            return (
              (gt(n) || (!r.variant && n)) &&
                (r = this.localEvaluationVariantAndSource(e, n, t)),
              r
            );
          }),
          (e.prototype.localEvaluationVariantAndSource = function (e, t, r) {
            var n,
              i = {},
              o = this.evaluate([t.key])[e],
              a = Qe.LocalEvaluation,
              s =
                null === (n = null == o ? void 0 : o.metadata) || void 0 === n
                  ? void 0
                  : n.default;
            if (!vt(o) && !s)
              return { variant: bt(o), source: a, hasDefaultVariant: !1 };
            if (
              (s && (i = { variant: bt(o), source: a, hasDefaultVariant: !0 }),
              !vt(r))
            )
              return {
                variant: bt(r),
                source: Qe.FallbackInline,
                hasDefaultVariant: i.hasDefaultVariant,
              };
            var l = this.config.initialVariants[e];
            if (!vt(l))
              return {
                variant: bt(l),
                source: Qe.SecondaryInitialVariants,
                hasDefaultVariant: i.hasDefaultVariant,
              };
            var u = bt(this.config.fallbackVariant),
              c = {
                variant: u,
                source: Qe.FallbackConfig,
                hasDefaultVariant: i.hasDefaultVariant,
              };
            return ht(u) ? i : c;
          }),
          (e.prototype.localStorageVariantAndSource = function (e, t) {
            var r,
              n = {},
              i = this.variants.get(e),
              o =
                null === (r = null == i ? void 0 : i.metadata) || void 0 === r
                  ? void 0
                  : r.default;
            if (!vt(i) && !o)
              return {
                variant: bt(i),
                source: Qe.LocalStorage,
                hasDefaultVariant: !1,
              };
            if (
              (o &&
                (n = {
                  variant: bt(i),
                  source: Qe.LocalStorage,
                  hasDefaultVariant: !0,
                }),
              !vt(t))
            )
              return {
                variant: bt(t),
                source: Qe.FallbackInline,
                hasDefaultVariant: n.hasDefaultVariant,
              };
            var a = this.config.initialVariants[e];
            if (!vt(a))
              return {
                variant: bt(a),
                source: Qe.SecondaryInitialVariants,
                hasDefaultVariant: n.hasDefaultVariant,
              };
            var s = bt(this.config.fallbackVariant),
              l = {
                variant: s,
                source: Qe.FallbackConfig,
                hasDefaultVariant: n.hasDefaultVariant,
              };
            return ht(s) ? n : l;
          }),
          (e.prototype.initialVariantsVariantAndSource = function (e, t) {
            var r,
              n = {},
              i = this.config.initialVariants[e];
            if (!vt(i))
              return {
                variant: bt(i),
                source: Qe.InitialVariants,
                hasDefaultVariant: !1,
              };
            var o = this.variants.get(e),
              a =
                null === (r = null == o ? void 0 : o.metadata) || void 0 === r
                  ? void 0
                  : r.default;
            if (!vt(o) && !a)
              return {
                variant: bt(o),
                source: Qe.LocalStorage,
                hasDefaultVariant: !1,
              };
            if (
              (a &&
                (n = {
                  variant: bt(o),
                  source: Qe.LocalStorage,
                  hasDefaultVariant: !0,
                }),
              !vt(t))
            )
              return {
                variant: bt(t),
                source: Qe.FallbackInline,
                hasDefaultVariant: n.hasDefaultVariant,
              };
            var s = bt(this.config.fallbackVariant),
              l = {
                variant: s,
                source: Qe.FallbackConfig,
                hasDefaultVariant: n.hasDefaultVariant,
              };
            return ht(s) ? n : l;
          }),
          (e.prototype.fetchInternal = function (e, t, r, n) {
            return Re(this, void 0, void 0, function () {
              var i, o, a;
              return Be(this, function (s) {
                switch (s.label) {
                  case 0:
                    if (!this.apiKey)
                      throw Error("Experiment API key is empty");
                    this.logger.debug(
                      "[Experiment] Fetch all: retry=".concat(r)
                    ),
                      r && this.stopRetries(),
                      (s.label = 1);
                  case 1:
                    return (
                      s.trys.push([1, 4, , 5]),
                      [
                        4,
                        this.doFetch(
                          e,
                          t,
                          Fe(
                            {
                              trackingOption:
                                null ===
                                  (a = this.fetchVariantsOptions.get()) ||
                                void 0 === a
                                  ? void 0
                                  : a.trackingOption,
                            },
                            n
                          )
                        ),
                      ]
                    );
                  case 2:
                    return (i = s.sent()), [4, this.storeVariants(i, n)];
                  case 3:
                    return s.sent(), [2, i];
                  case 4:
                    throw (
                      ((o = s.sent()),
                      r && this.shouldRetryFetch(o) && this.startRetries(e, n),
                      o)
                    );
                  case 5:
                    return [2];
                }
              });
            });
          }),
          (e.prototype.setTracksAssignment = function (e) {
            return Re(this, void 0, void 0, function () {
              return Be(this, function (t) {
                return (
                  this.fetchVariantsOptions.put(
                    Fe(Fe({}, this.fetchVariantsOptions.get() || {}), {
                      trackingOption: e ? "track" : "no-track",
                    })
                  ),
                  this.fetchVariantsOptions.store(),
                  [2]
                );
              });
            });
          }),
          (e.prototype.cleanUserPropsForFetch = function (e) {
            var t = Fe({}, e);
            return delete t.cookie, t;
          }),
          (e.prototype.doFetch = function (e, t, r) {
            return Re(this, void 0, void 0, function () {
              var n, i, o, a, s, l, u;
              return Be(this, function (c) {
                switch (c.label) {
                  case 0:
                    return [4, this.addContextOrWait(e)];
                  case 1:
                    return (
                      (e = c.sent()),
                      (e = this.cleanUserPropsForFetch(e)),
                      this.logger.debug(
                        "[Experiment] Fetch variants for user: ",
                        e
                      ),
                      [
                        4,
                        this.evaluationApi.getVariants(
                          e,
                          Fe({ timeoutMillis: t }, r)
                        ),
                      ]
                    );
                  case 2:
                    (n = c.sent()), (i = {});
                    try {
                      for (
                        o = Ke(Object.keys(n)), a = o.next();
                        !a.done;
                        a = o.next()
                      )
                        (s = a.value), (i[s] = wt(n[s]));
                    } catch (e) {
                      l = { error: e };
                    } finally {
                      try {
                        a && !a.done && (u = o.return) && u.call(o);
                      } finally {
                        if (l) throw l.error;
                      }
                    }
                    return (
                      this.logger.debug("[Experiment] Received variants: ", i),
                      [2, i]
                    );
                }
              });
            });
          }),
          (e.prototype.doFlags = function () {
            return Re(this, void 0, void 0, function () {
              var e, t, r;
              return Be(this, function (n) {
                switch (n.label) {
                  case 0:
                    return (
                      n.trys.push([0, 4, , 5]),
                      (e = void 0),
                      this.isWebExperiment
                        ? [4, this.addContextOrWait(this.getUser())]
                        : [3, 2]
                    );
                  case 1:
                    (e = n.sent()), (n.label = 2);
                  case 2:
                    return [
                      4,
                      this.flagApi.getFlags({
                        libraryName: "experiment-js-client",
                        libraryVersion: rt,
                        timeoutMillis: this.config.fetchTimeoutMillis,
                        deliveryMethod: this.isWebExperiment ? "web" : void 0,
                        user:
                          (null == e ? void 0 : e.user_id) ||
                          (null == e ? void 0 : e.device_id)
                            ? {
                                user_id: null == e ? void 0 : e.user_id,
                                device_id: null == e ? void 0 : e.device_id,
                              }
                            : void 0,
                      }),
                    ];
                  case 3:
                    return (
                      (t = n.sent()),
                      this.flags.clear(),
                      this.flags.putAll(t),
                      [3, 5]
                    );
                  case 4:
                    if (!((r = n.sent()) instanceof he)) throw r;
                    if ((this.logger.debug(r), this.config.throwOnError))
                      throw r;
                    return [3, 5];
                  case 5:
                    try {
                      this.flags.store();
                    } catch (e) {}
                    return this.mergeInitialFlagsWithStorage(), [2];
                }
              });
            });
          }),
          (e.prototype.storeVariants = function (e, t) {
            return Re(this, void 0, void 0, function () {
              var r, n, i, o;
              return Be(this, function (a) {
                for (o in (0 ===
                  (r = t && t.flagKeys ? t.flagKeys : []).length &&
                  this.variants.clear(),
                (n = function (t) {
                  (r = r.filter(function (e) {
                    return e !== t;
                  })),
                    i.variants.put(t, e[t]);
                }),
                (i = this),
                e))
                  n(o);
                for (o in r) this.variants.remove(o);
                try {
                  this.variants.store();
                } catch (e) {}
                return (
                  this.logger.debug("[Experiment] Stored variants: ", e), [2]
                );
              });
            });
          }),
          (e.prototype.startRetries = function (e, t) {
            return Re(this, void 0, void 0, function () {
              var r = this;
              return Be(this, function (n) {
                return (
                  this.logger.debug("[Experiment] Retry fetch"),
                  (this.retriesBackoff = new mt(8, 500, 1e4, 1.5)),
                  this.retriesBackoff.start(function () {
                    return Re(r, void 0, void 0, function () {
                      return Be(this, function (r) {
                        switch (r.label) {
                          case 0:
                            return [4, this.fetchInternal(e, 1e4, !1, t)];
                          case 1:
                            return r.sent(), [2];
                        }
                      });
                    });
                  }),
                  [2]
                );
              });
            });
          }),
          (e.prototype.stopRetries = function () {
            this.retriesBackoff && this.retriesBackoff.cancel();
          }),
          (e.prototype.addContext = function (e) {
            var t,
              r =
                null === (t = this.userProvider) || void 0 === t
                  ? void 0
                  : t.getUser(),
              n = this.integrationManager.getUser(),
              i = Fe(
                Fe(
                  Fe({}, null == r ? void 0 : r.user_properties),
                  n.user_properties
                ),
                null == e ? void 0 : e.user_properties
              );
            return Fe(
              Fe(
                Fe(Fe({ library: "experiment-js-client/".concat(rt) }, r), n),
                e
              ),
              { user_properties: i }
            );
          }),
          (e.prototype.addContextOrWait = function (e) {
            return Re(this, void 0, void 0, function () {
              return Be(this, function (t) {
                switch (t.label) {
                  case 0:
                    return [4, this.integrationManager.ready()];
                  case 1:
                    return t.sent(), [2, this.addContext(e)];
                }
              });
            });
          }),
          (e.prototype.sourceVariants = function () {
            return this.config.source == Xe.LocalStorage
              ? this.variants.getAll()
              : this.config.source == Xe.InitialVariants
              ? this.config.initialVariants
              : void 0;
          }),
          (e.prototype.secondaryVariants = function () {
            return this.config.source == Xe.LocalStorage
              ? this.config.initialVariants
              : this.config.source == Xe.InitialVariants
              ? this.variants.getAll()
              : void 0;
          }),
          (e.prototype.exposureInternal = function (e, t) {
            var r, n, i, o, a, s, l, u, c;
            if (
              null ===
                (i =
                  null ===
                    (n =
                      null === (r = t.variant) || void 0 === r
                        ? void 0
                        : r.metadata) || void 0 === n
                    ? void 0
                    : n.trackExposure) ||
              void 0 === i ||
              i
            ) {
              this.legacyExposureInternal(e, t.variant, t.source);
              var d = { flag_key: e },
                f = et(t.source);
              if (!f || t.hasDefaultVariant) {
                (null === (o = t.variant) || void 0 === o
                  ? void 0
                  : o.expKey) &&
                  (d.experiment_key =
                    null === (a = t.variant) || void 0 === a
                      ? void 0
                      : a.expKey);
                var p =
                  null === (s = t.variant) || void 0 === s
                    ? void 0
                    : s.metadata;
                if (
                  (f ||
                    (null == p ? void 0 : p.default) ||
                    ((null === (l = t.variant) || void 0 === l ? void 0 : l.key)
                      ? (d.variant = t.variant.key)
                      : (null === (u = t.variant) || void 0 === u
                          ? void 0
                          : u.value) && (d.variant = t.variant.value)),
                  p && (d.metadata = p),
                  this.isWebExperiment && (d.time = Date.now()),
                  this.isWebExperiment)
                ) {
                  var v = be();
                  if (null == v ? void 0 : v.location)
                    try {
                      var h = v.location.href;
                      d.metadata.url = h.split("?")[0] || "";
                    } catch (e) {}
                }
                var g = this.addContext(this.getUser());
                null === (c = this.userSessionExposureTracker) ||
                  void 0 === c ||
                  c.track(d, g),
                  this.integrationManager.track(d, g);
              }
            }
          }),
          (e.prototype.legacyExposureInternal = function (e, t, r) {
            var n, i, o, a, s;
            if (this.analyticsProvider) {
              var l = (function (e, t, r, n) {
                var i,
                  o = null == r ? void 0 : r.value,
                  a = "[Experiment] ".concat(t);
                return {
                  name: "[Experiment] Exposure",
                  user: e,
                  key: t,
                  variant: r,
                  userProperty: a,
                  properties: { key: t, variant: o, source: n },
                  userProperties: ((i = {}), (i[a] = o), i),
                };
              })(this.addContext(this.getUser()), e, t, r);
              et(r) || !(null == t ? void 0 : t.value)
                ? null ===
                    (i =
                      null === (n = this.analyticsProvider) || void 0 === n
                        ? void 0
                        : n.unsetUserProperty) ||
                  void 0 === i ||
                  i.call(n, l)
                : (null == t ? void 0 : t.value) &&
                  (null ===
                    (a =
                      null === (o = this.analyticsProvider) || void 0 === o
                        ? void 0
                        : o.setUserProperty) ||
                    void 0 === a ||
                    a.call(o, l),
                  null === (s = this.analyticsProvider) ||
                    void 0 === s ||
                    s.track(l));
            }
          }),
          (e.getLogLevel = function (e) {
            var t;
            return !0 === e.debug
              ? Ge.Debug
              : null !== (t = e.logLevel) && void 0 !== t
              ? t
              : Ge.Error;
          }),
          (e.prototype.shouldRetryFetch = function (e) {
            return (
              !(e instanceof ve) ||
              e.statusCode < 400 ||
              e.statusCode >= 500 ||
              429 === e.statusCode
            );
          }),
          (e.prototype.addPlugin = function (e) {
            "integration" === e.type &&
              this.integrationManager.setIntegration(e);
          }),
          e
        );
      })(),
      Et = (function () {
        function e(e, t) {
          var r, n, i;
          (this.globalScope = be()),
            (this.userAgent =
              void 0 !==
              (null === (r = this.globalScope) || void 0 === r
                ? void 0
                : r.navigator)
                ? null === (n = this.globalScope) || void 0 === n
                  ? void 0
                  : n.navigator.userAgent
                : void 0),
            (this.ua = new Le.UAParser(this.userAgent).getResult()),
            (this.localStorage = new ut()),
            (this.sessionStorage = new pt()),
            (this.userProvider = e),
            (this.apiKey = t),
            (this.storageKey = "EXP_".concat(
              null === (i = this.apiKey) || void 0 === i
                ? void 0
                : i.slice(0, 10),
              "_DEFAULT_USER_PROVIDER"
            ));
        }
        return (
          (e.prototype.getUser = function () {
            var e,
              t,
              r,
              n,
              i,
              o =
                (null === (e = this.userProvider) || void 0 === e
                  ? void 0
                  : e.getUser()) || {};
            return Fe(
              {
                language: this.getLanguage(),
                platform: "Web",
                os: this.getOs(this.ua),
                device_model: this.getDeviceModel(this.ua),
                device_category:
                  null !==
                    (r =
                      null === (t = this.ua.device) || void 0 === t
                        ? void 0
                        : t.type) && void 0 !== r
                    ? r
                    : "desktop",
                referring_url:
                  null ===
                    (i =
                      null === (n = this.globalScope) || void 0 === n
                        ? void 0
                        : n.document) || void 0 === i
                    ? void 0
                    : i.referrer.replace(/\/$/, ""),
                cookie: this.getCookie(),
                browser: this.getBrowser(this.ua),
                landing_url: this.getLandingUrl(),
                first_seen: this.getFirstSeen(),
                url_param: this.getUrlParam(),
                user_agent: this.userAgent,
              },
              o
            );
          }),
          (e.prototype.getLanguage = function () {
            return (
              ("undefined" != typeof navigator &&
                ((navigator.languages && navigator.languages[0]) ||
                  navigator.language)) ||
              ""
            );
          }),
          (e.prototype.getOs = function (e) {
            var t, r;
            return [
              null === (t = e.browser) || void 0 === t ? void 0 : t.name,
              null === (r = e.browser) || void 0 === r ? void 0 : r.major,
            ]
              .filter(function (e) {
                return null != e;
              })
              .join(" ");
          }),
          (e.prototype.getDeviceModel = function (e) {
            var t;
            return null === (t = e.os) || void 0 === t ? void 0 : t.name;
          }),
          (e.prototype.getBrowser = function (e) {
            var t,
              r = null === (t = e.browser) || void 0 === t ? void 0 : t.name;
            return (
              (null == r ? void 0 : r.includes("Chrom")) && (r = "Chrome"),
              (null == r ? void 0 : r.includes("Firefox")) && (r = "Firefox"),
              (null == r ? void 0 : r.includes("Safari")) && (r = "Safari"),
              (null == r ? void 0 : r.includes("Edge")) && (r = "Edge"),
              (null == r ? void 0 : r.includes("Opera")) && (r = "Opera"),
              r
            );
          }),
          (e.prototype.getCookie = function () {
            var e, t, r, n, i;
            if (
              null ===
                (t =
                  null === (e = this.globalScope) || void 0 === e
                    ? void 0
                    : e.document) || void 0 === t
                ? void 0
                : t.cookie
            )
              return Object.fromEntries(
                null ===
                  (i =
                    null ===
                      (n =
                        null === (r = this.globalScope) || void 0 === r
                          ? void 0
                          : r.document) || void 0 === n
                      ? void 0
                      : n.cookie) || void 0 === i
                  ? void 0
                  : i.split("; ").map(function (e) {
                      return e.split("=");
                    })
              );
          }),
          (e.prototype.getLandingUrl = function () {
            var e, t;
            try {
              var r = JSON.parse(
                this.sessionStorage.get(this.storageKey) || "{}"
              );
              return (
                r.landing_url ||
                  ((r.landing_url =
                    null ===
                      (t =
                        null === (e = this.globalScope) || void 0 === e
                          ? void 0
                          : e.location) || void 0 === t
                      ? void 0
                      : t.href.replace(/\/$/, "")),
                  this.sessionStorage.put(this.storageKey, JSON.stringify(r))),
                r.landing_url
              );
            } catch (e) {
              return;
            }
          }),
          (e.prototype.getFirstSeen = function () {
            try {
              var e = JSON.parse(
                this.localStorage.get(this.storageKey) || "{}"
              );
              return (
                e.first_seen ||
                  ((e.first_seen = (Date.now() / 1e3).toString()),
                  this.localStorage.put(this.storageKey, JSON.stringify(e))),
                e.first_seen
              );
            } catch (e) {
              return;
            }
          }),
          (e.prototype.getUrlParam = function () {
            var e, t, r;
            if (this.globalScope) {
              var n = {};
              try {
                var i = new URL(this.globalScope.location.href);
                try {
                  for (
                    var o = Ke(i.searchParams), a = o.next();
                    !a.done;
                    a = o.next()
                  ) {
                    var s = qe(a.value, 2),
                      l = s[0],
                      u = s[1];
                    n[l] = ze(
                      ze(
                        [],
                        qe(null !== (r = n[l]) && void 0 !== r ? r : []),
                        !1
                      ),
                      qe(u.split(",")),
                      !1
                    );
                  }
                } catch (t) {
                  e = { error: t };
                } finally {
                  try {
                    a && !a.done && (t = o.return) && t.call(o);
                  } finally {
                    if (e) throw e.error;
                  }
                }
              } catch (e) {
                return;
              }
              return Object.entries(n).reduce(function (e, t) {
                var r = qe(t, 2),
                  n = r[0],
                  i = r[1];
                return (e[n] = 1 == i.length ? i[0] : i), e;
              }, {});
            }
          }),
          e
        );
      })();
    ye.experimentInstances = {};
    var _t = ye.experimentInstances,
      Ot = function (e, t) {
        return Ct(e, t);
      },
      At = function (e, t) {
        return Ct(e, t, function () {
          return new Je(e, Te.getInstance(Pt(t)), 1e4);
        });
      },
      Pt = function (e) {
        return (null == e ? void 0 : e.instanceName) || tt.instanceName;
      },
      Ct = function (e, t, r) {
        var n = (function (e, t) {
            var r = Pt(t),
              n = null == t ? void 0 : t.internalInstanceNameSuffix;
            return n
              ? "".concat(r, ".").concat(e, ".").concat(n)
              : "".concat(r, ".").concat(e);
          })(e, t),
          i = _t[n];
        return (
          i ||
          ((i = (function (e, t) {
            return new kt(
              e,
              Fe(Fe({}, t), {
                userProvider: new Et(null == t ? void 0 : t.userProvider, e),
              })
            );
          })(e, t)),
          r && i.addPlugin(r()),
          (_t[n] = i),
          i)
        );
      },
      Mt = { initialize: Ot, initializeWithAmplitudeAnalytics: At },
      Tt = (function () {
        function e() {}
        return (
          (e.prototype.getUser = function () {
            return {};
          }),
          (e.prototype.start = function (e) {
            return Re(this, void 0, void 0, function () {
              return Be(this, function (e) {
                return [2];
              });
            });
          }),
          (e.prototype.stop = function () {}),
          (e.prototype.setUser = function (e) {}),
          (e.prototype.fetch = function (e, t) {
            return Re(this, void 0, void 0, function () {
              return Be(this, function (e) {
                return [2, this];
              });
            });
          }),
          (e.prototype.getUserProvider = function () {
            return null;
          }),
          (e.prototype.setUserProvider = function (e) {
            return this;
          }),
          (e.prototype.variant = function (e, t) {
            return tt.fallbackVariant;
          }),
          (e.prototype.all = function () {
            return {};
          }),
          (e.prototype.clear = function () {}),
          (e.prototype.exposure = function (e) {}),
          e
        );
      })(),
      It = Object.freeze({
        __proto__: null,
        AmplitudeAnalyticsProvider: Ue,
        AmplitudeIntegrationPlugin: Je,
        AmplitudeUserProvider: De,
        ConsoleLogger: lt,
        Experiment: Mt,
        ExperimentClient: kt,
        get LogLevel() {
          return Ge;
        },
        get Source() {
          return Xe;
        },
        StubExperimentClient: Tt,
        initialize: Ot,
        initializeWithAmplitudeAnalytics: At,
      });
    function jt() {
      return (
        (jt = Object.assign
          ? Object.assign.bind()
          : function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                for (var n in r)
                  ({}.hasOwnProperty.call(r, n) && (e[n] = r[n]));
              }
              return e;
            }),
        jt.apply(null, arguments)
      );
    }
    var Nt = ["selector", "action", "value", "attribute"],
      Vt = /^[a-zA-Z:_][a-zA-Z0-9:_.-]*$/,
      Lt = { revert: function () {} },
      Dt = new Map(),
      Ut = [],
      Ft = new Set(),
      Rt = !1,
      Bt = 1;
    function Kt(e) {
      return "html" === e
        ? {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeOldValue: !0,
            characterData: !0,
            characterDataOldValue: !0,
          }
        : { childList: !1, subtree: !1, attributes: !0, attributeFilter: [e] };
    }
    function qt(e) {
      var t = Dt.get(e);
      return t || ((t = { element: e, attributes: {} }), Dt.set(e, t)), t;
    }
    function zt(e, t) {
      return (
        e.parentNode === t.parentNode &&
        e.insertBeforeNode === t.insertBeforeNode
      );
    }
    function Wt(e, t) {
      Ft.add(e), (e.__params = t), Rt || e.observe.apply(e, e.__params);
    }
    function Ht(e, t, r, n, i) {
      var o,
        a = r(e),
        s = function (e) {
          Er(), i(e), _r();
        },
        l = {
          isDirty: !1,
          originalValue: a,
          virtualValue: a,
          mutations: [],
          el: e,
          rateLimitCount: 0,
          observer: new MutationObserver(function (n) {
            if (!(l.rateLimitCount >= 10)) {
              if (
                (l.rateLimitCount++,
                setTimeout(function () {
                  (l.rateLimitCount = l.rateLimitCount - 1),
                    l.rateLimitCount <= 0 && (l.rateLimitCount = 0);
                }, 1e3),
                "html" === t)
              )
                return (
                  Er(),
                  n.forEach(function (t) {
                    var r = t.target,
                      n = t.type,
                      i = t.oldValue;
                    if ("childList" === n)
                      return (
                        t.removedNodes.forEach(function (e) {
                          r.insertBefore(e, t.nextSibling);
                        }),
                        void t.addedNodes.forEach(function (e) {
                          e.remove();
                        })
                      );
                    if ("characterData" !== n) {
                      if ("attributes" === n && r instanceof Element) {
                        if (r === e) return;
                        var o = t.attributeName;
                        if (!o) return;
                        null === i
                          ? r.removeAttribute(o)
                          : r.setAttribute(o, i);
                      }
                    } else r.nodeValue = i;
                  }),
                  void _r()
                );
              var i = r(e);
              if ("position" === t) {
                if (zt(i, l.virtualValue)) return;
                var o = l.mutations.at(-1);
                if (!o) return;
                if (gr(l.virtualValue.parentNode, o)) return;
              }
              i !== l.virtualValue &&
                ("position" !== t && (l.originalValue = i), s(l));
            }
          }),
          mutationRunner: s,
          setValue: n,
          getCurrentValue: r,
        };
      return (
        (o =
          "position" === t && e.parentNode
            ? [
                e.parentNode,
                {
                  childList: !0,
                  subtree: !0,
                  attributes: !1,
                  characterData: !1,
                },
              ]
            : [e, Kt(t)]),
        Wt(l.observer, o),
        l
      );
    }
    function Jt(e, t) {
      var r = t.getCurrentValue(t.el);
      (t.virtualValue = e),
        !e ||
        "string" == typeof e ||
        "string" == typeof r ||
        Array.isArray(e) ||
        Array.isArray(r)
          ? e !== r && ((t.isDirty = !0), vr())
          : (r && zt(r, e)) || ((t.isDirty = !0), vr());
    }
    var Gt = new DOMParser();
    function Xt(e) {
      var t = e.originalValue,
        r = t
          .map(function (e) {
            return e instanceof Element ? e.outerHTML : e.nodeValue;
          })
          .join("");
      e.mutations.forEach(function (n) {
        if (
          ((r = n.mutate(r)), n.cachedHtml !== r || !n.cachedNodes.has(e.el))
        ) {
          n.cachedHtml = r;
          var i = Array.from(
            Gt.parseFromString(r, "text/html").body.childNodes
          );
          n.cachedNodes.set(e.el, i);
        }
        t = n.cachedNodes.get(e.el);
      }),
        Jt(t, e);
    }
    function Qt(e) {
      var t = new Set(e.originalValue.split(/\s+/).filter(Boolean));
      e.mutations.forEach(function (e) {
        return e.mutate(t);
      }),
        Jt(Array.from(t).filter(Boolean).join(" "), e);
    }
    function $t(e) {
      var t = e.originalValue;
      e.mutations.forEach(function (e) {
        t = e.mutate(t);
      }),
        Jt(t, e);
    }
    function Zt(e) {
      if ("insertSelector" in e) {
        var t,
          r = e.insertSelector,
          n = e.direction,
          i = document.querySelector(r);
        if (!i) return null;
        switch (n) {
          case "prepend":
            t = { parentNode: i, insertBeforeNode: i.firstChild };
            break;
          case "append":
            t = { parentNode: i, insertBeforeNode: null };
            break;
          case "before":
            t = { parentNode: i.parentElement, insertBeforeNode: i };
            break;
          case "after":
            t = {
              parentNode: i.parentElement,
              insertBeforeNode: i.nextSibling,
            };
        }
        return jt({}, t, { insertNode: i, direction: n });
      }
      var o = e.parentSelector,
        a = e.insertBeforeSelector,
        s = document.querySelector(o);
      if (!s) return null;
      var l = a ? document.querySelector(a) : null;
      return a && !l ? null : { parentNode: s, insertBeforeNode: l };
    }
    function Yt(e) {
      for (var t = e.originalValue, r = e.mutations.length - 1; r >= 0; r--) {
        var n,
          i = e.mutations[r];
        if (
          !i.newPosition ||
          !i.newPosition.parentNode.isConnected ||
          !1 ===
            (null == (n = i.newPosition.insertBeforeNode)
              ? void 0
              : n.isConnected)
        ) {
          var o = Zt(i.mutate());
          i.newPosition = o;
        }
        if (i.newPosition) {
          t = i.newPosition;
          break;
        }
      }
      Jt(t, e);
    }
    var er = function (e) {
        return Array.from(e.childNodes);
      },
      tr = function (e, t) {
        (e.innerHTML = ""), e.append.apply(e, t);
      };
    function rr(e) {
      var t = qt(e);
      return t.html || (t.html = Ht(e, "html", er, tr, Xt)), t.html;
    }
    var nr = function (e) {
        return { parentNode: e.parentElement, insertBeforeNode: e.nextSibling };
      },
      ir = function (e, t) {
        var r;
        if ("insertNode" in t) {
          t.insertNode[t.direction](e),
            (t.insertBeforeNode = e.nextSibling || null);
        } else {
          if (t.insertBeforeNode && !t.parentNode.contains(t.insertBeforeNode))
            return;
          t.parentNode.insertBefore(e, t.insertBeforeNode);
        }
        var n = null == (r = qt(e).position) ? void 0 : r.observer;
        null != n &&
          n.__params &&
          (n.disconnect(), Wt(n, [e.parentNode, n.__params[1]]));
      };
    function or(e) {
      var t = qt(e);
      return (
        t.position || (t.position = Ht(e, "position", nr, ir, Yt)), t.position
      );
    }
    var ar = function (e, t) {
        t ? (e.className = t) : e.removeAttribute("class");
      },
      sr = function (e) {
        return e.className;
      };
    function lr(e) {
      var t = qt(e);
      return t.classes || (t.classes = Ht(e, "class", sr, ar, Qt)), t.classes;
    }
    var ur = function (e) {
        return function (t) {
          var r;
          return "style" === e
            ? t.style.cssText
            : null != (r = t.getAttribute(e))
            ? r
            : null;
        };
      },
      cr = function (e) {
        return function (t, r) {
          null !== r
            ? "style" === e
              ? r
                ? (t.style.cssText = r)
                : t.removeAttribute("style")
              : t.setAttribute(e, r)
            : t.removeAttribute(e);
        };
      };
    function dr(e, t) {
      var r = qt(e);
      return (
        r.attributes[t] || (r.attributes[t] = Ht(e, t, ur(t), cr(t), $t)),
        r.attributes[t]
      );
    }
    function fr(e, t, r) {
      if (r.isDirty) {
        r.isDirty = !1;
        var n = r.virtualValue;
        r.mutations.length ||
          (function (e, t) {
            var r,
              n = Dt.get(e);
            if (n) {
              var i, o;
              if ("html" === t)
                (i = null == (o = n.html) ? void 0 : o.observer), delete n.html;
              else if ("class" === t) {
                var a;
                (i = null == (a = n.classes) ? void 0 : a.observer),
                  delete n.classes;
              } else if ("position" === t) {
                var s;
                (i = null == (s = n.position) ? void 0 : s.observer),
                  delete n.position;
              } else {
                var l;
                (i =
                  null == (l = n.attributes) || null == (l = l[t])
                    ? void 0
                    : l.observer),
                  delete n.attributes[t];
              }
              null == (r = i) || r.disconnect(), Ft.delete(i);
            }
          })(e, t),
          r.setValue(e, n);
      }
    }
    function pr(e, t) {
      e.html && fr(t, "html", e.html),
        e.classes && fr(t, "class", e.classes),
        e.position && fr(t, "position", e.position),
        Object.keys(e.attributes).forEach(function (r) {
          fr(t, r, e.attributes[r]);
        });
    }
    function vr() {
      Dt.forEach(pr);
    }
    function hr(e, t) {
      var r = null;
      "html" === e.kind
        ? (r = rr(t))
        : "class" === e.kind
        ? (r = lr(t))
        : "attribute" === e.kind
        ? (r = dr(t, e.attribute))
        : "position" === e.kind && (r = or(t)),
        r && (r.mutations.push(e), r.mutationRunner(r));
    }
    function gr(e, t) {
      for (var r = t._priority || 0, n = e; n; ) {
        var i;
        if (
          ((null == (i = Dt.get(n)) ||
          null == (i = i.html) ||
          null == (i = i.mutations.at(-1))
            ? void 0
            : i._priority) || 0) > r
        )
          return !0;
        n = n.parentElement;
      }
      return !1;
    }
    function mr(e) {
      if (
        !(
          ("position" === e.kind && e.elements.size > 0) ||
          Array.from(e.elements).some(function (e) {
            return e.isConnected;
          })
        )
      ) {
        var t = new Set(e.elements);
        document.querySelectorAll(e.selector).forEach(function (r) {
          t.has(r) || gr(r.parentElement, e) || (e.elements.add(r), hr(e, r));
        });
      }
    }
    function yr(e) {
      for (
        var t = Ut.indexOf(e), r = [], n = Er(!0), i = Ut.length - 1;
        i > t;
        i--
      ) {
        var o = Ut[i];
        if ("position" === o.kind) {
          var a = o.newPosition;
          if (a) {
            var s = !("direction" in a) || "before" === a.direction,
              l = br(a.insertBeforeNode, e.elements, s);
            if (((a.insertBeforeNode = l), "insertNode" in a))
              if ("before" === a.direction)
                null === l
                  ? ((a.insertNode = a.parentNode), (a.direction = "append"))
                  : (a.insertNode = l);
              else if ("after" === a.direction) {
                var u,
                  c = new Set(
                    Array.from(e.elements).concat(Array.from(o.elements))
                  ),
                  d = wr(
                    (null == (u = a.insertBeforeNode)
                      ? void 0
                      : u.previousElementSibling) ||
                      a.parentNode.lastElementChild,
                    c
                  );
                null === d
                  ? ((a.direction = "prepend"), (a.insertNode = a.parentNode))
                  : (a.insertNode = d);
              }
          }
        }
        r.push(o), yr(o);
      }
      e.elements.forEach(function (t) {
        return (function (e, t) {
          var r = null;
          if (
            ("html" === e.kind
              ? (r = rr(t))
              : "class" === e.kind
              ? (r = lr(t))
              : "attribute" === e.kind
              ? (r = dr(t, e.attribute))
              : "position" === e.kind && (r = or(t)),
            r)
          ) {
            var n = r.mutations.indexOf(e);
            -1 !== n && r.mutations.splice(n, 1),
              e.rollback && (r.originalValue = e.rollback(r.originalValue)),
              r.mutationRunner(r);
          }
        })(e, t);
      }),
        Ut.splice(t, 1),
        n();
      for (
        var f = function () {
          var e = r.pop();
          if (!e) return 1;
          Ar(e),
            e.elements.forEach(function (t) {
              return hr(e, t);
            });
        };
        r.length > 0;

      )
        f();
    }
    function br(e, t, r) {
      for (var n = e; n instanceof Element && t.has(n); )
        n = r ? n.nextElementSibling : n.nextSibling;
      return n;
    }
    function wr(e, t) {
      for (var r = e; r instanceof Element && t.has(r); )
        r = r.previousElementSibling;
      return r;
    }
    function xr() {
      Ut.forEach(mr);
    }
    var Sr,
      kr = !1;
    function Er(e) {
      return (
        void 0 === e && (e = !1),
        (Rt = !0),
        Ft.forEach(function (e) {
          return e.disconnect();
        }),
        e && !kr
          ? ((kr = !0),
            function () {
              (kr = !1), _r();
            })
          : function () {}
      );
    }
    function _r() {
      Rt &&
        !kr &&
        ((Rt = !1),
        Ft.forEach(function (e) {
          return e.__params && e.observe.apply(e, e.__params);
        }),
        xr());
    }
    function Or() {
      "undefined" != typeof document &&
        (Sr ||
          (Sr = new MutationObserver(function () {
            xr();
          })),
        xr(),
        Wt(Sr, [
          document.documentElement,
          { childList: !0, subtree: !0, attributes: !1, characterData: !1 },
        ]));
    }
    Or();
    function Ar(e) {
      return "undefined" == typeof document
        ? Lt
        : ((e._priority = Bt++),
          Ut.push(e),
          mr(e),
          {
            __mutation: e,
            revert: function () {
              yr(e);
            },
          });
    }
    function Pr(e, t) {
      return Ar({
        kind: "html",
        elements: new Set(),
        mutate: t,
        selector: e,
        cachedNodes: new Map(),
      });
    }
    function Cr(e, t) {
      return Ar({
        kind: "position",
        elements: new Set(),
        mutate: t,
        selector: e,
      });
    }
    function Mr(e, t, r) {
      return Ar({
        kind: "class",
        elements: new Set(),
        mutate: t,
        selector: e,
        rollback: r,
      });
    }
    function Tr(e, t, r, n) {
      return Vt.test(t)
        ? "class" === t || "className" === t
          ? Mr(
              e,
              function (e) {
                var t = r(Array.from(e).join(" "));
                e.clear(),
                  t &&
                    t
                      .split(/\s+/g)
                      .filter(Boolean)
                      .forEach(function (t) {
                        return e.add(t);
                      });
              },
              n
            )
          : Ar({
              kind: "attribute",
              attribute: t,
              elements: new Set(),
              mutate: r,
              selector: e,
              rollback: n,
            })
        : Lt;
    }
    var Ir = {
        html: Pr,
        classes: Mr,
        attribute: Tr,
        position: Cr,
        declarative: function (e) {
          var t = e.selector,
            r = e.action,
            n = e.value,
            i = e.attribute,
            o = (function (e, t) {
              if (null == e) return {};
              var r = {};
              for (var n in e)
                if ({}.hasOwnProperty.call(e, n)) {
                  if (-1 !== t.indexOf(n)) continue;
                  r[n] = e[n];
                }
              return r;
            })(e, Nt);
          if ("html" === i) {
            if ("append" === r)
              return Pr(t, function (e) {
                return e + (null != n ? n : "");
              });
            if ("set" === r)
              return Pr(t, function () {
                return null != n ? n : "";
              });
          } else if ("class" === i) {
            if ("append" === r)
              return Mr(
                t,
                function (e) {
                  n && e.add(n);
                },
                function (e) {
                  if (n && e) {
                    var t = new Set(e.split(/\s+/).filter(Boolean));
                    return t.delete(n), Array.from(t).join(" ");
                  }
                  return e;
                }
              );
            if ("remove" === r)
              return Mr(t, function (e) {
                n && e.delete(n);
              });
            if ("set" === r)
              return Mr(t, function (e) {
                e.clear(), n && e.add(n);
              });
          } else if ("position" === i) {
            if ("set" === r) {
              if ("insertSelector" in o)
                return Cr(t, function () {
                  return {
                    insertSelector: o.insertSelector,
                    direction: o.direction,
                  };
                });
              if ("parentSelector" in o)
                return Cr(t, function () {
                  return {
                    insertBeforeSelector: o.insertBeforeSelector,
                    parentSelector: o.parentSelector,
                  };
                });
            }
          } else {
            var a = n || "";
            if ("append" === r)
              return "style" === i
                ? Tr(
                    t,
                    i,
                    function (e) {
                      return e ? e + a : a;
                    },
                    function (e) {
                      if (null === e) return null;
                      var t = e.lastIndexOf(a);
                      return -1 !== t
                        ? e.substring(0, t) + e.substring(t + a.length)
                        : e;
                    }
                  )
                : Tr(t, i, function (e) {
                    return null !== e ? e + a : a;
                  });
            if ("set" === r)
              return Tr(t, i, function () {
                return a;
              });
            if ("remove" === r)
              return Tr(t, i, function () {
                return null;
              });
          }
          return Lt;
        },
      },
      jr = Object.freeze({
        __proto__: null,
        default: Ir,
        connectGlobalObserver: Or,
        disconnectGlobalObserver: function () {
          var e;
          null == (e = Sr) || e.disconnect();
        },
        getHtmlMutationRecordsFromSelector: function (e) {
          var t = document.querySelectorAll(e),
            r = [];
          return (
            t.forEach(function (e) {
              var t = rr(e);
              t && r.push(t);
            }),
            r
          );
        },
        isGlobalObserverPaused: function () {
          return Rt;
        },
        pauseGlobalObserver: Er,
        resumeGlobalObserver: _r,
        validAttributeName: Vt,
      }),
      Nr = (function () {
        function e(e) {
          (this.modal = null), (this.options = e);
        }
        return (
          (e.prototype.show = function () {
            document.getElementById("amp-preview-modal") ||
              (this.createModal(), this.attachEventListeners());
          }),
          (e.prototype.hide = function () {
            var e, t;
            this.modal && (this.modal.remove(), (this.modal = null)),
              null === (t = (e = this.options).onDismiss) ||
                void 0 === t ||
                t.call(e);
          }),
          (e.prototype.createModal = function () {
            var e = this;
            if (document.body) {
              (this.modal = document.createElement("div")),
                (this.modal.id = "amp-preview-modal"),
                (this.modal.className = "amp-preview-modal");
              var t = document.createElement("div");
              (t.className = "amp-preview-modal-container"),
                Object.entries(this.options.flags).forEach(function (e) {
                  var r = o(e, 2),
                    n = r[0],
                    i = r[1],
                    a = document.createElement("div");
                  a.className = "amp-preview-modal-row";
                  var s = document.createElement("div");
                  (s.className = "amp-preview-modal-icon"),
                    (s.innerHTML =
                      '\n        <svg class="amp-preview-modal-icon-img" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\n          <path d="M13.1389 11.4324L18.2087 18.1956H6.04109L11.1109 11.4324V6.02794H13.1389V11.4324ZM16.1402 4H8.10959C7.68372 4 7.45051 4.4867 7.71414 4.82131L9.083 6.53492V10.7632L3.20198 18.6011C2.70514 19.2704 3.1817 20.2235 4.01316 20.2235H20.2366C21.0681 20.2235 21.5447 19.2704 21.0478 18.6011L15.1668 10.7632V6.53492L16.5357 4.82131C16.7993 4.4867 16.5661 4 16.1402 4Z" fill="currentColor"/>\n        </svg>\n      ');
                  var l = document.createElement("span");
                  (l.className = "amp-preview-modal-title"),
                    (l.textContent = n);
                  var u = document.createElement("div");
                  (u.className =
                    "amp-preview-modal-badge amp-preview-modal-preview-badge"),
                    (u.innerHTML =
                      '\n        <svg class="amp-preview-modal-preview-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\n          <path d="M12 6C15.79 6 19.17 8.13 20.82 11.5C19.17 14.87 15.79 17 12 17C8.21 17 4.83 14.87 3.18 11.5C4.83 8.13 8.21 6 12 6ZM12 4C7 4 2.73 7.11 1 11.5C2.73 15.89 7 19 12 19C17 19 21.27 15.89 23 11.5C21.27 7.11 17 4 12 4ZM12 9C13.38 9 14.5 10.12 14.5 11.5C14.5 12.88 13.38 14 12 14C10.62 14 9.5 12.88 9.5 11.5C9.5 10.12 10.62 9 12 9ZM12 7C9.52 7 7.5 9.02 7.5 11.5C7.5 13.98 9.52 16 12 16C14.48 16 16.5 13.98 16.5 11.5C16.5 9.02 14.48 7 12 7Z" fill="currentColor"/>\n        </svg>\n        Preview Mode\n      ');
                  var c = document.createElement("span");
                  c.className =
                    "amp-preview-modal-badge amp-preview-modal-variant-badge amp-preview-modal-variant-".concat(
                      i.toLowerCase()
                    );
                  var d = document.createElement("span");
                  (d.className = "amp-preview-modal-variant-dot"),
                    c.appendChild(d),
                    c.appendChild(document.createTextNode(i)),
                    a.appendChild(s),
                    a.appendChild(l),
                    a.appendChild(u),
                    a.appendChild(c),
                    t.appendChild(a);
                });
              var r = document.createElement("button");
              (r.className = "amp-preview-modal-close"),
                r.setAttribute(
                  "aria-label",
                  "Dismiss preview mode notification"
                ),
                (r.innerHTML = "×"),
                this.modal.appendChild(t),
                this.modal.appendChild(r),
                this.injectStyles(),
                requestAnimationFrame(function () {
                  e.modal &&
                    document.body &&
                    document.body.appendChild(e.modal);
                });
            }
          }),
          (e.prototype.attachEventListeners = function () {
            var e = this;
            if (this.modal) {
              var t = this.modal.querySelector(".amp-preview-modal-close");
              t &&
                t.addEventListener("click", function () {
                  return e.hide();
                });
            }
          }),
          (e.prototype.injectStyles = function () {
            if (!document.getElementById("amp-preview-modal-styles")) {
              var e = document.createElement("style");
              (e.id = "amp-preview-modal-styles"),
                (e.textContent =
                  "\n      .amp-preview-modal {\n        position: fixed;\n        top: 20px;\n        right: 20px;\n        z-index: 10000;\n        background-color: #ffffff;\n        border: 1px solid #e2e8f0;\n        border-radius: 8px;\n        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.12);\n        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;\n        font-size: 14px;\n        line-height: 1.4;\n        color: #2d3748;\n        animation: amp-preview-modal-slide-in 0.3s ease-out;\n        display: flex;\n        align-items: flex-start;\n        gap: 8px;\n        padding: 12px 16px;\n        max-width: 600px;\n      }\n\n      @keyframes amp-preview-modal-slide-in {\n        from {\n          transform: translateX(100%);\n          opacity: 0;\n        }\n        to {\n          transform: translateX(0);\n          opacity: 1;\n        }\n      }\n\n      .amp-preview-modal-container {\n        flex: 1;\n        display: flex;\n        flex-direction: column;\n        gap: 8px;\n      }\n\n      .amp-preview-modal-row {\n        display: flex;\n        align-items: center;\n        gap: 8px;\n      }\n\n      .amp-preview-modal-icon {\n        flex-shrink: 0;\n        display: flex;\n        align-items: center;\n        justify-content: center;\n      }\n\n      .amp-preview-modal-icon-img {\n        width: 16px;\n        height: 16px;\n        color: #718096;\n      }\n\n      .amp-preview-modal-title {\n        font-weight: 600;\n        color: #1a202c;\n        font-size: 14px;\n        white-space: nowrap;\n        max-width: 300px;\n        overflow: hidden;\n        text-overflow: ellipsis;\n      }\n\n      /* Base badge styles */\n      .amp-preview-modal-badge {\n        background-color: #ffffff;\n        color: #4a5568;\n        padding: 4px 8px;\n        border-radius: 12px;\n        font-size: 12px;\n        font-weight: 500;\n        white-space: nowrap;\n        display: flex;\n        align-items: center;\n        gap: 6px;\n        border: 1px solid #e2e8f0;\n      }\n\n      .amp-preview-modal-preview-badge {\n        color: #718096;\n      }\n\n      .amp-preview-modal-preview-icon {\n        width: 14px;\n        height: 14px;\n        color: currentColor;\n      }\n\n      .amp-preview-modal-variant-dot {\n        width: 8px;\n        height: 8px;\n        border-radius: 50%;\n        background-color: #68d391;\n        flex-shrink: 0;\n      }\n\n      .amp-preview-modal-variant-badge.amp-preview-modal-variant-a .amp-preview-modal-variant-dot {\n        background-color: #68d391;\n      }\n\n      .amp-preview-modal-variant-badge.amp-preview-modal-variant-b .amp-preview-modal-variant-dot {\n        background-color: #fc8181;\n      }\n\n      .amp-preview-modal-variant-badge.amp-preview-modal-variant-testing .amp-preview-modal-variant-dot {\n        background-color: #63b3ed;\n      }\n\n      .amp-preview-modal-close {\n        background: none;\n        border: none;\n        cursor: pointer;\n        padding: 4px;\n        border-radius: 6px;\n        color: #a0aec0;\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        flex-shrink: 0;\n        font-size: 18px;\n        line-height: 1;\n        width: 24px;\n        height: 24px;\n        transition: all 0.2s ease;\n        align-self: flex-start;\n      }\n\n      .amp-preview-modal-close:hover {\n        background-color: #f7fafc;\n        color: #718096;\n      }\n\n      .amp-preview-modal-close:focus {\n        outline: 2px solid #3182ce;\n        outline-offset: 1px;\n      }\n\n      /* Dark mode support */\n      @media (prefers-color-scheme: dark) {\n        .amp-preview-modal {\n          background-color: #2d3748;\n          border-color: #4a5568;\n          color: #e2e8f0;\n        }\n\n        .amp-preview-modal-title {\n          color: #f7fafc;\n        }\n\n        .amp-preview-modal-badge {\n          background-color: #2d3748;\n          color: #e2e8f0;\n          border-color: #4a5568;\n        }\n\n        .amp-preview-modal-preview-badge {\n          color: #a0aec0;\n        }\n\n        .amp-preview-modal-variant-dot {\n          background-color: #68d391;\n        }\n\n        .amp-preview-modal-variant-badge.amp-preview-modal-variant-a .amp-preview-modal-variant-dot {\n          background-color: #68d391;\n        }\n\n        .amp-preview-modal-variant-badge.amp-preview-modal-variant-b .amp-preview-modal-variant-dot {\n          background-color: #fc8181;\n        }\n\n        .amp-preview-modal-variant-badge.amp-preview-modal-variant-testing .amp-preview-modal-variant-dot {\n          background-color: #63b3ed;\n        }\n\n        .amp-preview-modal-close {\n          color: #718096;\n        }\n\n        .amp-preview-modal-close:hover {\n          background-color: #4a5568;\n          color: #e2e8f0;\n        }\n      }\n    "),
                document.head.appendChild(e);
            }
          }),
          e
        );
      })();
    function Vr(e) {
      var t = new Nr(e),
        r = !1,
        n = !1,
        i = function () {
          r && n && t.show();
        };
      return (
        "loading" === document.readyState
          ? document.addEventListener("DOMContentLoaded", function () {
              (r = !0), i();
            })
          : (r = !0),
        setTimeout(function () {
          (n = !0), i();
        }, 500),
        t
      );
    }
    var Lr = (function () {
        function e() {
          (this.messageToSubscriberGroup = new Map()),
            (this.subscriberGroupCallback = new Map());
        }
        return (
          (e.prototype.subscribe = function (e, t, r) {
            void 0 === r && (r = void 0);
            var n = this.messageToSubscriberGroup.get(e);
            n ||
              ((n = { subscribers: [] }),
              this.messageToSubscriberGroup.set(e, n));
            var i = { identifier: r, callback: t };
            n.subscribers.push(i);
          }),
          (e.prototype.groupSubscribe = function (e, t) {
            this.subscriberGroupCallback.set(e, t),
              this.messageToSubscriberGroup.has(e) ||
                this.messageToSubscriberGroup.set(e, { subscribers: [] });
          }),
          (e.prototype.publish = function (e, t) {
            var r,
              n = this.messageToSubscriberGroup.get(e);
            n &&
              ((t = t || {}),
              n.subscribers.forEach(function (e) {
                e.callback(t);
              }),
              null === (r = this.subscriberGroupCallback.get(e)) ||
                void 0 === r ||
                r(t));
          }),
          (e.prototype.unsubscribeAll = function () {
            (this.messageToSubscriberGroup = new Map()),
              (this.subscriberGroupCallback = new Map());
          }),
          e
        );
      })(),
      Dr = [],
      Ur = !1,
      Fr = "not_started",
      Rr = null,
      Br = function (e) {
        var t;
        if (!0 !== e.__AMP_DEBUG)
          try {
            Ur =
              "true" ===
              (null === (t = e.localStorage) || void 0 === t
                ? void 0
                : t.getItem("amp-ve-debug"));
          } catch (e) {
            Ur = !1;
          }
        else Ur = !0;
      },
      Kr = function () {
        return Ur;
      },
      qr = function (e, t) {
        Ur && Dr.push({ timestamp: Date.now(), event: e, detail: t });
      },
      zr = function (e) {
        Fr = e;
      },
      Wr = function (e) {
        Rr = e;
      },
      Hr = function () {
        var e,
          r =
            null !== (e = null == Rr ? void 0 : Rr()) && void 0 !== e
              ? e
              : { flags: {}, visualEditor: { isActive: !1 }, currentUrl: "" };
        return {
          flags: r.flags,
          visualEditor: t(t({}, r.visualEditor), { messengerState: Fr }),
          events: Dr,
          currentUrl: r.currentUrl,
          timestamp: Date.now(),
        };
      };
    function Jr(e, t) {
      var r,
        n,
        o,
        a,
        s = [];
      try {
        for (var l = i(Object.values(e)), u = l.next(); !u.done; u = l.next()) {
          var c = u.value;
          try {
            for (
              var d = ((o = void 0), i(Object.values(c))), f = d.next();
              !f.done;
              f = d.next()
            ) {
              var p = f.value;
              t.includes(p.trigger_type) && s.push(p);
            }
          } catch (e) {
            o = { error: e };
          } finally {
            try {
              f && !f.done && (a = d.return) && a.call(d);
            } finally {
              if (o) throw o.error;
            }
          }
        }
      } catch (e) {
        r = { error: e };
      } finally {
        try {
          u && !u.done && (n = l.return) && n.call(l);
        } finally {
          if (r) throw r.error;
        }
      }
      return s;
    }
    var Gr = "amp-device-iframe",
      Xr = "amp-overlay-device-iframe-container";
    function Qr() {
      try {
        return (
          "true" === sessionStorage.getItem("amp-visual-editor-mobile-mode")
        );
      } catch (e) {
        return !1;
      }
    }
    function $r() {
      return document.getElementById(Gr);
    }
    function Zr(e, t) {
      var r = t.location.href;
      r &&
        r !== e.location.href &&
        e.history.replaceState(e.history.state, "", r);
    }
    function Yr(e) {
      var t = e.document,
        r = function () {
          var r = t.createElement("style");
          for (
            r.setAttribute("data-amp-shell-guard", ""),
              r.textContent =
                "body > *:not(#"
                  .concat(Xr, "):not(#")
                  .concat("overlay-shadow-host", ") ") +
                "{ display: none !important; }",
              t.head.appendChild(r);
            t.body.firstChild;

          )
            t.body.removeChild(t.body.firstChild);
          t.body.style.cssText =
            '\n      margin: 0;\n      padding: 0;\n      overflow: auto;\n      min-height: 100vh;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n      background-color: #fff;\n      background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAABZSURBVHgB7dG7DYBADANQJxexAiXSTXw9uyExBih34SOxQhr83Li2ASIiIiIiIpo7QbLW1tms1zijq9puSDaGLxhhuBPaqyKZTFK+/r6AZOJlg8shqv5ccAGZWRnaKiSy9QAAAABJRU5ErkJggg==");\n    ';
          var n = t.createElement("div");
          (n.id = Xr),
            (n.style.cssText =
              "\n      width: 100%;\n      height: 100%;\n      display: flex;\n      align-items: center;\n      justify-content: center;\n    ");
          var i = t.createElement("iframe");
          (i.id = Gr),
            (i.src = e.location.href),
            (i.style.cssText = "\n      width: "
              .concat(402, "px;\n      height: ")
              .concat(
                874,
                "px;\n      border: 1px solid #dedfe2;\n      border-radius: 20px;\n      box-shadow: 0px 1px 4px rgba(0, 0, 0, 0.1);\n      background: #fff;\n      transition: all 0.1s ease;\n    "
              )),
            i.addEventListener("load", function () {
              var t = i.contentWindow;
              if (t)
                try {
                  Zr(e, t),
                    (function (e, t) {
                      var r = t.history,
                        n = function (r) {
                          return function (n, i, o) {
                            r.call(this, n, i, o), Zr(e, t);
                          };
                        };
                      (r.pushState = n(r.pushState.bind(r))),
                        (r.replaceState = n(r.replaceState.bind(r))),
                        t.addEventListener("popstate", function () {
                          Zr(e, t);
                        });
                    })(e, t);
                } catch (e) {}
            }),
            n.appendChild(i),
            t.body.appendChild(n);
        };
      return new Promise(function (n) {
        if ("complete" === t.readyState && t.body) r(), n();
        else {
          var i = function () {
            "complete" === t.readyState && t.body
              ? (r(), n())
              : e.requestAnimationFrame(i);
          };
          e.requestAnimationFrame(i);
        }
      });
    }
    var en = {
        observerOptions: {
          childList: !0,
          subtree: !0,
          attributes: !0,
          attributeFilter: ["style", "class"],
        },
        debounceMs: 100,
      },
      tn = (function () {
        function e(r, n, i, s) {
          void 0 === i && (i = []), void 0 === s && (s = {});
          var l = this;
          (this.mutationObserver = null),
            (this.pendingMutations = []),
            (this.processMutationsImmediately = function () {
              if (l.mutationObserver)
                try {
                  l.pendingMutations.length > 0 &&
                    l.onMutations(l.pendingMutations);
                } catch (e) {
                } finally {
                  l.pendingMutations = [];
                }
            }),
            (this.handleMutations = function (t) {
              var r, n;
              try {
                var i = t.filter(function (e) {
                  return l.shouldProcessMutation(e);
                });
                if (0 === i.length) return;
                if (
                  l.pendingMutations.length + i.length >
                  e.MAX_PENDING_MUTATIONS
                )
                  return (
                    (r = l.pendingMutations).push.apply(r, a([], o(i), !1)),
                    l.processMutationsDebounced.cancel(),
                    void l.processMutationsImmediately()
                  );
                (n = l.pendingMutations).push.apply(n, a([], o(i), !1)),
                  l.processMutationsDebounced();
              } catch (e) {}
            }),
            (this.target = r),
            (this.onMutations = n),
            (this.filters = i),
            (this.options = t(t({}, en), s)),
            (this.processMutationsDebounced = (function (e, t, r) {
              void 0 === r && (r = {});
              var n = null,
                i = null,
                s = function () {
                  for (var s = [], l = 0; l < arguments.length; l++)
                    s[l] = arguments[l];
                  r.maxWait &&
                    !i &&
                    (i = setTimeout(function () {
                      n && (clearTimeout(n), (n = null)),
                        (i = null),
                        e.apply(void 0, a([], o(s), !1));
                    }, r.maxWait)),
                    n && clearTimeout(n),
                    (n = setTimeout(function () {
                      i && (clearTimeout(i), (i = null)),
                        e.apply(void 0, a([], o(s), !1));
                    }, t));
                };
              return (
                (s.cancel = function () {
                  n && clearTimeout(n),
                    i && clearTimeout(i),
                    (n = null),
                    (i = null);
                }),
                s
              );
            })(this.processMutationsImmediately, this.options.debounceMs, {
              maxWait: 2 * this.options.debounceMs,
            }));
        }
        return (
          (e.prototype.shouldProcessMutation = function (e) {
            if (0 === this.filters.length) return !0;
            try {
              return this.filters.every(function (t) {
                return t(e);
              });
            } catch (e) {
              return !1;
            }
          }),
          (e.prototype.cleanup = function () {
            var e;
            this.processMutationsDebounced.cancel(),
              null === (e = this.mutationObserver) ||
                void 0 === e ||
                e.disconnect(),
              (this.pendingMutations = []),
              (this.mutationObserver = null);
          }),
          (e.prototype.observe = function () {
            var e = this;
            return (
              this.mutationObserver && this.cleanup(),
              (this.mutationObserver = new MutationObserver(
                this.handleMutations
              )),
              this.mutationObserver.observe(
                this.target,
                this.options.observerOptions
              ),
              function () {
                e.cleanup();
              }
            );
          }),
          (e.MAX_PENDING_MUTATIONS = 1e3),
          e
        );
      })(),
      rn = new H(),
      nn = (function () {
        function e(e, r, n, a, s) {
          var l = this;
          (this.pageChangeSubscribers = new Set()),
            (this.lastNotifiedActivePages = {}),
            (this.intersectionObservers = new Map()),
            (this.elementVisibilityState = new Map()),
            (this.elementAppearedState = new Set()),
            (this.manuallyActivatedPageObjects = new Set()),
            (this.targetedElementSelectors = new Set()),
            (this.scrolledToObservers = new Map()),
            (this.scrolledToElementState = new Map()),
            (this.analyticsEventState = new Set()),
            (this.maxScrollPercentage = 0),
            (this.timeOnPageTimeouts = {}),
            (this.firedUserInteractions = new Set()),
            (this.clickTimeouts = new Map()),
            (this.hoverTimeouts = new WeakMap()),
            (this.focusTimeouts = new WeakMap()),
            (this.userInteractionAbortController = null),
            (this.pageLoadTime = Number.POSITIVE_INFINITY),
            (this.lastPublishedUrl = null),
            (this.debugStateSubscribers = new Set()),
            (this.debugDebounceTimer = null),
            (this.setPageObjects = function (e) {
              l.pageObjects = e;
            }),
            (this.markUrlAsPublished = function (e) {
              l.lastPublishedUrl = e;
            }),
            (this.initSubscriptions = function () {
              l.setupPageObjectSubscriptions(),
                l.options.useDefaultNavigationHandler &&
                  l.setupLocationChangePublisher(),
                l.setupMutationObserverPublisher(),
                l.setupVisibilityPublisher(),
                l.setupUserInteractionPublisher(),
                l.setupExitIntentPublisher(),
                l.setupScrolledToPublisher(),
                l.setupTimeOnPagePublisher(),
                l.setupVisibilityChangeHandler(),
                l.checkInitialElements();
            }),
            (this.addPageChangeSubscriber = function (e) {
              return (
                l.pageChangeSubscribers.add(e),
                function () {
                  l.pageChangeSubscribers.delete(e);
                }
              );
            }),
            (this.addDebugStateSubscriber = function (e) {
              return (
                l.debugStateSubscribers.add(e),
                function () {
                  l.debugStateSubscribers.delete(e);
                }
              );
            }),
            (this.scheduleDebugNotification = function () {
              l.options.isDebugActive &&
                0 !== l.debugStateSubscribers.size &&
                (null !== l.debugDebounceTimer &&
                  l.globalScope.clearTimeout(l.debugDebounceTimer),
                (l.debugDebounceTimer = l.globalScope.setTimeout(function () {
                  var e, t;
                  l.debugDebounceTimer = null;
                  var r = l.webExperimentClient.getDebugState();
                  try {
                    for (
                      var n = i(l.debugStateSubscribers), o = n.next();
                      !o.done;
                      o = n.next()
                    ) {
                      (0, o.value)(r);
                    }
                  } catch (t) {
                    e = { error: t };
                  } finally {
                    try {
                      o && !o.done && (t = n.return) && t.call(n);
                    } finally {
                      if (e) throw e.error;
                    }
                  }
                }, 100)));
            }),
            (this.setupPageObjectSubscriptions = function () {
              var e,
                r,
                n,
                a,
                s,
                u,
                c,
                d,
                f = { url_change: new Set() };
              try {
                for (
                  var p = i(Object.entries(l.pageObjects)), v = p.next();
                  !v.done;
                  v = p.next()
                ) {
                  var h = o(v.value, 2),
                    g = h[0],
                    m = h[1];
                  try {
                    for (
                      var y = ((n = void 0), i(Object.values(m))), b = y.next();
                      !b.done;
                      b = y.next()
                    ) {
                      var w = b.value;
                      f[w.trigger_type] || (f[w.trigger_type] = new Set()),
                        f[w.trigger_type].add(g);
                    }
                  } catch (e) {
                    n = { error: e };
                  } finally {
                    try {
                      b && !b.done && (a = y.return) && a.call(y);
                    } finally {
                      if (n) throw n.error;
                    }
                  }
                }
              } catch (t) {
                e = { error: t };
              } finally {
                try {
                  v && !v.done && (r = p.return) && r.call(p);
                } finally {
                  if (e) throw e.error;
                }
              }
              var x = function (e, t) {
                var r,
                  n,
                  o = function (t) {
                    l.messageBus.subscribe(t.trigger_type, function (r) {
                      var n,
                        i = !!(null ===
                          (n = l.webExperimentClient.getActivePages()[e]) ||
                        void 0 === n
                          ? void 0
                          : n[t.id]),
                        o = l.isPageObjectActive(t, r);
                      l.webExperimentClient.updateActivePages(e, t, o),
                        o &&
                          !i &&
                          qr(
                            "trigger_fired",
                            "flag="
                              .concat(e, ", page=")
                              .concat(t.name || t.id, ", ") +
                              "type=".concat(t.trigger_type)
                          );
                    });
                  };
                try {
                  for (
                    var a = ((r = void 0), i(Object.values(t))), s = a.next();
                    !s.done;
                    s = a.next()
                  ) {
                    o(s.value);
                  }
                } catch (e) {
                  r = { error: e };
                } finally {
                  try {
                    s && !s.done && (n = a.return) && n.call(a);
                  } finally {
                    if (r) throw r.error;
                  }
                }
              };
              try {
                for (
                  var S = i(Object.entries(l.pageObjects)), k = S.next();
                  !k.done;
                  k = S.next()
                ) {
                  var E = o(k.value, 2);
                  x((g = E[0]), (m = E[1]));
                }
              } catch (e) {
                s = { error: e };
              } finally {
                try {
                  k && !k.done && (u = S.return) && u.call(S);
                } finally {
                  if (s) throw s.error;
                }
              }
              var _ = function (e) {
                l.messageBus.groupSubscribe(e, function (r) {
                  var n,
                    a,
                    s = "url_change" === e;
                  s &&
                    (qr(
                      "url_change",
                      "navigated to ".concat(l.globalScope.location.href)
                    ),
                    l.resetTriggerStates(),
                    l.revertInjections());
                  var u = l.webExperimentClient.getActivePages(),
                    c = !(function (e, t) {
                      var r,
                        n,
                        o,
                        a,
                        s = Object.keys(e),
                        l = Object.keys(t);
                      if (s.length !== l.length) return !1;
                      try {
                        for (
                          var u = i(s), c = u.next();
                          !c.done;
                          c = u.next()
                        ) {
                          var d = c.value,
                            f = e[d],
                            p = t[d];
                          if (!p) return !1;
                          var v = Object.keys(f),
                            h = Object.keys(p);
                          if (v.length !== h.length) return !1;
                          try {
                            for (
                              var g = ((o = void 0), i(v)), m = g.next();
                              !m.done;
                              m = g.next()
                            ) {
                              var y = m.value,
                                b = f[y],
                                w = p[y];
                              if (!w || b.id !== w.id) return !1;
                            }
                          } catch (e) {
                            o = { error: e };
                          } finally {
                            try {
                              m && !m.done && (a = g.return) && a.call(g);
                            } finally {
                              if (o) throw o.error;
                            }
                          }
                        }
                      } catch (e) {
                        r = { error: e };
                      } finally {
                        try {
                          c && !c.done && (n = u.return) && n.call(u);
                        } finally {
                          if (r) throw r.error;
                        }
                      }
                      return !0;
                    })(u, l.lastNotifiedActivePages);
                  if (
                    !("updateActivePages" in r && r.updateActivePages) &&
                    !l.options.isVisualEditorMode &&
                    (c || s)
                  ) {
                    var d = s ? void 0 : Array.from(f[e] || []);
                    if (
                      (l.webExperimentClient.applyVariants({
                        flagKeys:
                          null == d
                            ? void 0
                            : d.filter(function (e) {
                                return !l.webExperimentClient.previewFlags[e];
                              }),
                      }),
                      l.webExperimentClient.isPreviewMode)
                    ) {
                      var p = d
                        ? Object.fromEntries(
                            Object.entries(
                              l.webExperimentClient.previewFlags
                            ).filter(function (e) {
                              var t = o(e, 1)[0];
                              return d.includes(t);
                            })
                          )
                        : l.webExperimentClient.previewFlags;
                      l.webExperimentClient.previewVariants({
                        keyToVariant: p,
                      });
                    }
                  }
                  l.lastNotifiedActivePages = (function (e) {
                    var r = {};
                    for (var n in e)
                      for (var i in ((r[n] = {}), e[n]))
                        r[n][i] = t({}, e[n][i]);
                    return r;
                  })(u);
                  try {
                    for (
                      var v = ((n = void 0), i(l.pageChangeSubscribers)),
                        h = v.next();
                      !h.done;
                      h = v.next()
                    ) {
                      (0, h.value)({ activePages: u });
                    }
                  } catch (e) {
                    n = { error: e };
                  } finally {
                    try {
                      h && !h.done && (a = v.return) && a.call(v);
                    } finally {
                      if (n) throw n.error;
                    }
                  }
                  (c || s) && l.scheduleDebugNotification();
                });
              };
              try {
                for (
                  var O = i(Object.keys(f)), A = O.next();
                  !A.done;
                  A = O.next()
                ) {
                  _(A.value);
                }
              } catch (e) {
                c = { error: e };
              } finally {
                try {
                  A && !A.done && (d = O.return) && d.call(O);
                } finally {
                  if (c) throw c.error;
                }
              }
            }),
            (this.toggleManualPageObject = function (e, t) {
              t
                ? l.manuallyActivatedPageObjects.add(e)
                : l.manuallyActivatedPageObjects.delete(e),
                l.messageBus.publish("manual");
            }),
            (this.resetTriggerStates = function () {
              var e, t, r, n, a, s;
              qr("trigger_reset", "all non-url_change triggers cleared"),
                l.elementAppearedState.clear(),
                l.elementVisibilityState.clear(),
                l.firedUserInteractions.clear(),
                l.scrolledToElementState.clear(),
                l.manuallyActivatedPageObjects.clear(),
                (l.maxScrollPercentage = 0),
                (l.pageLoadTime = Date.now()),
                l.analyticsEventState.clear();
              try {
                for (
                  var u = i(l.clickTimeouts.values()), c = u.next();
                  !c.done;
                  c = u.next()
                ) {
                  var d = c.value;
                  l.globalScope.clearTimeout(d);
                }
              } catch (t) {
                e = { error: t };
              } finally {
                try {
                  c && !c.done && (t = u.return) && t.call(u);
                } finally {
                  if (e) throw e.error;
                }
              }
              l.clickTimeouts.clear();
              try {
                for (
                  var f = i(Object.entries(l.pageObjects)), p = f.next();
                  !p.done;
                  p = f.next()
                ) {
                  var v = o(p.value, 2),
                    h = v[0],
                    g = v[1];
                  try {
                    for (
                      var m = ((a = void 0), i(Object.values(g))), y = m.next();
                      !y.done;
                      y = m.next()
                    ) {
                      var b = y.value;
                      "url_change" !== b.trigger_type &&
                        l.webExperimentClient.updateActivePages(h, b, !1);
                    }
                  } catch (e) {
                    a = { error: e };
                  } finally {
                    try {
                      y && !y.done && (s = m.return) && s.call(m);
                    } finally {
                      if (a) throw a.error;
                    }
                  }
                }
              } catch (e) {
                r = { error: e };
              } finally {
                try {
                  p && !p.done && (n = f.return) && n.call(f);
                } finally {
                  if (r) throw r.error;
                }
              }
              l.setupTimeOnPagePublisher(), l.checkInitialElements();
            }),
            (this.revertInjections = function () {
              Object.values(l.webExperimentClient.appliedMutations).forEach(
                function (e) {
                  Object.values(e).forEach(function (e) {
                    e[Jn] &&
                      Object.values(e[Jn]).forEach(function (e) {
                        var t;
                        null === (t = e.revert) || void 0 === t || t.call(e);
                      });
                  });
                }
              );
              var e = l.webExperimentClient.appliedMutations;
              Object.keys(e).forEach(function (t) {
                var r = e[t];
                Object.keys(r).forEach(function (e) {
                  r[e][Jn] &&
                    (delete r[e][Jn],
                    0 === Object.keys(r[e]).length && delete r[e]);
                }),
                  0 === Object.keys(r).length && delete e[t];
              });
            }),
            (this.updateElementAppearedState = function (e, t) {
              var r, n, o, a;
              try {
                for (var s = i(e), u = s.next(); !u.done; u = s.next()) {
                  var c = u.value;
                  if (0 === t.length || l.isMutationRelevantToSelector(t, c))
                    try {
                      var d = l.contentDocument.querySelectorAll(c);
                      try {
                        for (
                          var f = ((o = void 0), i(Array.from(d))),
                            p = f.next();
                          !p.done;
                          p = f.next()
                        ) {
                          var v = p.value,
                            h = l.contentWindow.getComputedStyle(v);
                          if (
                            "none" !== h.display &&
                            "hidden" !== h.visibility
                          ) {
                            l.elementAppearedState.add(c);
                            break;
                          }
                        }
                      } catch (e) {
                        o = { error: e };
                      } finally {
                        try {
                          p && !p.done && (a = f.return) && a.call(f);
                        } finally {
                          if (o) throw o.error;
                        }
                      }
                    } catch (e) {}
                }
              } catch (e) {
                r = { error: e };
              } finally {
                try {
                  u && !u.done && (n = s.return) && n.call(s);
                } finally {
                  if (r) throw r.error;
                }
              }
            }),
            (this.checkInitialElements = function () {
              l.updateElementAppearedState(l.targetedElementSelectors, []),
                l.messageBus.publish("element_appeared", { mutationList: [] });
            }),
            (this.setupMutationObserverPublisher = function () {
              if (
                ((l.targetedElementSelectors = (function (e) {
                  var t,
                    r,
                    n,
                    o,
                    a = new Set();
                  try {
                    for (
                      var s = i(Object.values(e)), l = s.next();
                      !l.done;
                      l = s.next()
                    ) {
                      var u = l.value;
                      try {
                        for (
                          var c = ((n = void 0), i(Object.values(u))),
                            d = c.next();
                          !d.done;
                          d = c.next()
                        ) {
                          var f = d.value;
                          if (
                            "element_appeared" === f.trigger_type ||
                            "element_visible" === f.trigger_type
                          ) {
                            var p = (v = f.trigger_value).selector;
                            p && a.add(p);
                          } else if ("scrolled_to" === f.trigger_type) {
                            var v;
                            "element" === (v = f.trigger_value).mode &&
                              v.selector &&
                              a.add(v.selector);
                          }
                        }
                      } catch (e) {
                        n = { error: e };
                      } finally {
                        try {
                          d && !d.done && (o = c.return) && o.call(c);
                        } finally {
                          if (n) throw n.error;
                        }
                      }
                    }
                  } catch (e) {
                    t = { error: e };
                  } finally {
                    try {
                      l && !l.done && (r = s.return) && r.call(s);
                    } finally {
                      if (t) throw t.error;
                    }
                  }
                  return a;
                })(l.pageObjects)),
                0 !== l.targetedElementSelectors.size)
              ) {
                var e = [
                  function (e) {
                    return Array.from(l.targetedElementSelectors).some(
                      function (t) {
                        return l.isMutationRelevantToSelector([e], t);
                      }
                    );
                  },
                ];
                return new tn(
                  l.contentDocument.documentElement,
                  function (e) {
                    l.updateElementAppearedState(l.targetedElementSelectors, e),
                      l.messageBus.publish("element_appeared", {
                        mutationList: e,
                      });
                  },
                  e
                ).observe();
              }
            }),
            (this.setupVisibilityPublisher = function () {
              var e, t, r, n, a;
              if (0 !== Jr(l.pageObjects, ["element_visible"]).length) {
                try {
                  for (
                    var s = i(Object.values(l.pageObjects)), u = s.next();
                    !u.done;
                    u = s.next()
                  ) {
                    var c = u.value,
                      d = function (e) {
                        if ("element_visible" === e.trigger_type) {
                          var t = e.trigger_value,
                            r = t.selector,
                            n =
                              null !== (a = t.visibilityRatio) && void 0 !== a
                                ? a
                                : 0,
                            i = "".concat(r, "\0").concat(n);
                          if (l.intersectionObservers.has(i)) return "continue";
                          var o = new IntersectionObserver(
                            function (e) {
                              e.forEach(function (e) {
                                var t = e.intersectionRatio >= n;
                                l.elementVisibilityState.set(i, t),
                                  t && l.messageBus.publish("element_visible");
                              });
                            },
                            { threshold: n }
                          );
                          l.intersectionObservers.set(i, o);
                          try {
                            l.contentDocument
                              .querySelectorAll(r)
                              .forEach(function (e) {
                                o.observe(e);
                              });
                          } catch (e) {}
                        }
                      };
                    try {
                      for (
                        var f = ((r = void 0), i(Object.values(c))),
                          p = f.next();
                        !p.done;
                        p = f.next()
                      ) {
                        d(p.value);
                      }
                    } catch (e) {
                      r = { error: e };
                    } finally {
                      try {
                        p && !p.done && (n = f.return) && n.call(f);
                      } finally {
                        if (r) throw r.error;
                      }
                    }
                  }
                } catch (t) {
                  e = { error: t };
                } finally {
                  try {
                    u && !u.done && (t = s.return) && t.call(s);
                  } finally {
                    if (e) throw e.error;
                  }
                }
                l.messageBus.subscribe("element_appeared", function (e) {
                  var t,
                    r,
                    n = e.mutationList,
                    a = function (e, t) {
                      var r = o(e.split("\0"), 1)[0];
                      if (
                        0 === n.length ||
                        l.isMutationRelevantToSelector(n, r)
                      )
                        try {
                          l.contentDocument
                            .querySelectorAll(r)
                            .forEach(function (e) {
                              t.observe(e);
                            });
                        } catch (e) {}
                    };
                  try {
                    for (
                      var s = i(l.intersectionObservers.entries()),
                        u = s.next();
                      !u.done;
                      u = s.next()
                    ) {
                      var c = o(u.value, 2);
                      a(c[0], c[1]);
                    }
                  } catch (e) {
                    t = { error: e };
                  } finally {
                    try {
                      u && !u.done && (r = s.return) && r.call(s);
                    } finally {
                      if (t) throw t.error;
                    }
                  }
                });
              }
            }),
            (this.setupExitIntentPublisher = function () {
              var e, t, r;
              l.pageLoadTime = Date.now();
              var n = Object.values(l.pageObjects).flatMap(function (e) {
                return Object.values(e).filter(function (e) {
                  return "exit_intent" === e.trigger_type;
                });
              });
              if (0 !== n.length) {
                var o = 1 / 0;
                try {
                  for (var a = i(n), s = a.next(); !s.done; s = a.next()) {
                    var u = s.value.trigger_value;
                    o = Math.min(
                      o,
                      null !== (r = u.minTimeOnPageMs) && void 0 !== r ? r : 0
                    );
                  }
                } catch (t) {
                  e = { error: t };
                } finally {
                  try {
                    s && !s.done && (t = a.return) && t.call(a);
                  } finally {
                    if (e) throw e.error;
                  }
                }
                var c = function (e) {
                  e.clientY <= 50 &&
                    null === e.relatedTarget &&
                    l.messageBus.publish("exit_intent", {
                      durationMs: Date.now() - l.pageLoadTime,
                    });
                };
                o > 0
                  ? l.globalScope.setTimeout(function () {
                      l.contentDocument.addEventListener("mouseleave", c);
                    }, o)
                  : l.contentDocument.addEventListener("mouseleave", c);
              }
            }),
            (this.setupLocationChangePublisher = function () {
              l.globalScope.addEventListener("popstate", function () {
                var e = l.globalScope.location.href;
                e !== l.lastPublishedUrl &&
                  ((l.lastPublishedUrl = e),
                  l.messageBus.publish("url_change"));
              });
              var e,
                t,
                r = function () {
                  var e = l.globalScope.location.href;
                  e !== l.lastPublishedUrl &&
                    ((l.lastPublishedUrl = e),
                    l.messageBus.publish("url_change"),
                    (l.globalScope.webExperiment.previousUrl = e));
                };
              (e = history.pushState),
                (t = history.replaceState),
                (history.pushState = function () {
                  for (var t = [], n = 0; n < arguments.length; n++)
                    t[n] = arguments[n];
                  var i = e.apply(this, t);
                  return r(), i;
                }),
                (history.replaceState = function () {
                  for (var e = [], n = 0; n < arguments.length; n++)
                    e[n] = arguments[n];
                  var i = t.apply(this, e);
                  return r(), i;
                });
            }),
            (this.setupUserInteractionPublisher = function () {
              var e, t, r, n, o, a, s, u;
              null === (o = l.userInteractionAbortController) ||
                void 0 === o ||
                o.abort(),
                (l.userInteractionAbortController = new AbortController());
              var c = l.userInteractionAbortController.signal,
                d = new Map(),
                f = new Map(),
                p = new Map();
              try {
                for (
                  var v = i(Object.values(l.pageObjects)), h = v.next();
                  !h.done;
                  h = v.next()
                ) {
                  var g = h.value;
                  try {
                    for (
                      var m = ((r = void 0), i(Object.values(g))), y = m.next();
                      !y.done;
                      y = m.next()
                    ) {
                      var b = y.value;
                      if ("user_interaction" === b.trigger_type) {
                        var w = b.trigger_value,
                          x = w.selector,
                          S = w.interactionType,
                          k = w.minThresholdMs;
                        "click" === S
                          ? (d.has(x) || d.set(x, new Set()),
                            null === (a = d.get(x)) ||
                              void 0 === a ||
                              a.add(k || 0))
                          : "hover" === S
                          ? (f.has(x) || f.set(x, new Set()),
                            null === (s = f.get(x)) ||
                              void 0 === s ||
                              s.add(k || 0))
                          : "focus" === S &&
                            (p.has(x) || p.set(x, new Set()),
                            null === (u = p.get(x)) ||
                              void 0 === u ||
                              u.add(k || 0));
                      }
                    }
                  } catch (e) {
                    r = { error: e };
                  } finally {
                    try {
                      y && !y.done && (n = m.return) && n.call(m);
                    } finally {
                      if (r) throw r.error;
                    }
                  }
                }
              } catch (t) {
                e = { error: t };
              } finally {
                try {
                  h && !h.done && (t = v.return) && t.call(v);
                } finally {
                  if (e) throw e.error;
                }
              }
              (0 === d.size && 0 === f.size && 0 === p.size) ||
                (d.size > 0 && l.setupClickDelegation(d, c),
                f.size > 0 && l.setupHoverDelegation(f, c),
                p.size > 0 && l.setupFocusDelegation(p, c));
            }),
            (this.setupClickDelegation = function (e, t) {
              l.contentDocument.addEventListener(
                "click",
                function (t) {
                  var r,
                    n,
                    a,
                    s,
                    u = t.target;
                  if (u)
                    try {
                      for (var c = i(e), d = c.next(); !d.done; d = c.next()) {
                        var f = o(d.value, 2),
                          p = f[0],
                          v = f[1];
                        try {
                          if (u.closest(p)) {
                            var h = function (e) {
                              var t = "".concat(p, "\0click\0").concat(e);
                              if (l.firedUserInteractions.has(t))
                                return "continue";
                              if (l.clickTimeouts.has(t)) return "continue";
                              var r = function () {
                                l.firedUserInteractions.add(t),
                                  l.messageBus.publish("user_interaction"),
                                  l.clickTimeouts.delete(t);
                              };
                              if (e > 0) {
                                var n = l.globalScope.setTimeout(r, e);
                                l.clickTimeouts.set(t, n);
                              } else r();
                            };
                            try {
                              for (
                                var g = ((a = void 0), i(v)), m = g.next();
                                !m.done;
                                m = g.next()
                              ) {
                                h(m.value);
                              }
                            } catch (e) {
                              a = { error: e };
                            } finally {
                              try {
                                m && !m.done && (s = g.return) && s.call(g);
                              } finally {
                                if (a) throw a.error;
                              }
                            }
                            break;
                          }
                        } catch (e) {}
                      }
                    } catch (e) {
                      r = { error: e };
                    } finally {
                      try {
                        d && !d.done && (n = c.return) && n.call(c);
                      } finally {
                        if (r) throw r.error;
                      }
                    }
                },
                { signal: t }
              );
            }),
            (this.setupThresholdBasedDelegation = function (e, t, r) {
              l.contentDocument.addEventListener(
                r.startEvent,
                function (t) {
                  var n,
                    a,
                    s,
                    u,
                    c = t.target;
                  if (c)
                    try {
                      for (var d = i(e), f = d.next(); !f.done; f = d.next()) {
                        var p = o(f.value, 2),
                          v = p[0],
                          h = p[1];
                        try {
                          var g = c.closest(v);
                          if (g) {
                            var m = function (e) {
                              var t = ""
                                .concat(v, "\0")
                                .concat(r.interactionType, "\0")
                                .concat(e);
                              if (l.firedUserInteractions.has(t))
                                return "continue";
                              var n = r.timeoutStorage.get(g);
                              n ||
                                ((n = new Map()), r.timeoutStorage.set(g, n));
                              var i = "".concat(v, "\0").concat(e);
                              if (!n.get(i)) {
                                var o = function () {
                                  l.firedUserInteractions.add(t),
                                    l.messageBus.publish("user_interaction"),
                                    null == n || n.delete(i);
                                };
                                if (e) {
                                  var a = l.globalScope.setTimeout(o, e);
                                  n.set(i, a);
                                } else o();
                              }
                            };
                            try {
                              for (
                                var y = ((s = void 0), i(h)), b = y.next();
                                !b.done;
                                b = y.next()
                              ) {
                                m(b.value);
                              }
                            } catch (e) {
                              s = { error: e };
                            } finally {
                              try {
                                b && !b.done && (u = y.return) && u.call(y);
                              } finally {
                                if (s) throw s.error;
                              }
                            }
                            break;
                          }
                        } catch (e) {}
                      }
                    } catch (e) {
                      n = { error: e };
                    } finally {
                      try {
                        f && !f.done && (a = d.return) && a.call(d);
                      } finally {
                        if (n) throw n.error;
                      }
                    }
                },
                { signal: t }
              ),
                l.contentDocument.addEventListener(
                  r.endEvent,
                  function (t) {
                    var n,
                      a,
                      s,
                      u,
                      c = t.target;
                    if (c) {
                      var d = t.relatedTarget;
                      try {
                        for (
                          var f = i(e), p = f.next();
                          !p.done;
                          p = f.next()
                        ) {
                          var v = o(p.value, 1)[0];
                          try {
                            var h = c.closest(v);
                            if (h) {
                              if (!d || !h.contains(d)) {
                                var g = r.timeoutStorage.get(h);
                                if (g) {
                                  try {
                                    for (
                                      var m = ((s = void 0), i(g.values())),
                                        y = m.next();
                                      !y.done;
                                      y = m.next()
                                    ) {
                                      var b = y.value;
                                      l.globalScope.clearTimeout(b);
                                    }
                                  } catch (e) {
                                    s = { error: e };
                                  } finally {
                                    try {
                                      y &&
                                        !y.done &&
                                        (u = m.return) &&
                                        u.call(m);
                                    } finally {
                                      if (s) throw s.error;
                                    }
                                  }
                                  r.timeoutStorage.delete(h);
                                }
                              }
                              break;
                            }
                          } catch (e) {}
                        }
                      } catch (e) {
                        n = { error: e };
                      } finally {
                        try {
                          p && !p.done && (a = f.return) && a.call(f);
                        } finally {
                          if (n) throw n.error;
                        }
                      }
                    }
                  },
                  { signal: t }
                );
            }),
            (this.setupHoverDelegation = function (e, t) {
              l.setupThresholdBasedDelegation(e, t, {
                interactionType: "hover",
                startEvent: "mouseover",
                endEvent: "mouseout",
                timeoutStorage: l.hoverTimeouts,
              });
            }),
            (this.setupFocusDelegation = function (e, t) {
              l.setupThresholdBasedDelegation(e, t, {
                interactionType: "focus",
                startEvent: "focusin",
                endEvent: "focusout",
                timeoutStorage: l.focusTimeouts,
              });
            }),
            (this.setupTimeOnPagePublisher = function () {
              var e, t, r, n;
              Object.values(l.timeOnPageTimeouts).forEach(clearTimeout),
                (l.timeOnPageTimeouts = {});
              var o = new Set();
              try {
                for (
                  var a = i(Object.values(l.pageObjects)), s = a.next();
                  !s.done;
                  s = a.next()
                ) {
                  var u = s.value;
                  try {
                    for (
                      var c = ((r = void 0), i(Object.values(u))), d = c.next();
                      !d.done;
                      d = c.next()
                    ) {
                      var f = d.value;
                      if ("time_on_page" === f.trigger_type) {
                        var p = f.trigger_value;
                        o.add(p.durationMs);
                      }
                    }
                  } catch (e) {
                    r = { error: e };
                  } finally {
                    try {
                      d && !d.done && (n = c.return) && n.call(c);
                    } finally {
                      if (r) throw r.error;
                    }
                  }
                }
              } catch (t) {
                e = { error: t };
              } finally {
                try {
                  s && !s.done && (t = a.return) && t.call(a);
                } finally {
                  if (e) throw e.error;
                }
              }
              0 !== o.size && l.setUpTimeouts(o);
            }),
            (this.setUpTimeouts = function (e) {
              e.forEach(function (e) {
                l.timeOnPageTimeouts[e] = l.globalScope.setTimeout(function () {
                  l.messageBus.publish("time_on_page", { durationMs: e }),
                    delete l.timeOnPageTimeouts[e];
                }, e);
              });
            }),
            (this.setupVisibilityChangeHandler = function () {
              if (0 !== Jr(l.pageObjects, ["time_on_page"]).length) {
                l.globalScope.document.addEventListener(
                  "visibilitychange",
                  function () {
                    if (l.globalScope.document.hidden)
                      Object.values(l.timeOnPageTimeouts).forEach(clearTimeout);
                    else {
                      var e = new Set(
                        Object.keys(l.timeOnPageTimeouts).map(Number)
                      );
                      l.setUpTimeouts(e);
                    }
                  }
                );
              }
            }),
            (this.setupScrolledToPublisher = function () {
              var e,
                t,
                r,
                n,
                a = Jr(l.pageObjects, ["scrolled_to"]);
              if (0 !== a.length) {
                var s = !1,
                  u = !1;
                try {
                  for (var c = i(a), d = c.next(); !d.done; d = c.next()) {
                    var f = d.value.trigger_value;
                    "percent" === f.mode
                      ? (s = !0)
                      : "element" === f.mode && (u = !0);
                  }
                } catch (t) {
                  e = { error: t };
                } finally {
                  try {
                    d && !d.done && (t = c.return) && t.call(c);
                  } finally {
                    if (e) throw e.error;
                  }
                }
                if (s) {
                  var p = null,
                    v = function () {
                      var e = l.calculateScrollPercentage();
                      e > l.maxScrollPercentage &&
                        ((l.maxScrollPercentage = e),
                        l.messageBus.publish("scrolled_to", {}));
                    };
                  l.contentWindow.addEventListener(
                    "scroll",
                    function () {
                      null === p &&
                        (p = l.globalScope.requestAnimationFrame(function () {
                          v(), (p = null);
                        }));
                    },
                    { passive: !0 }
                  ),
                    v();
                }
                if (u) {
                  var h = function (e) {
                    if ("scrolled_to" === e.trigger_type) {
                      var t = e.trigger_value;
                      if ("element" === t.mode) {
                        var r = t.selector,
                          n = t.offsetPx || 0,
                          i = "".concat(r, "\0").concat(n);
                        if (l.scrolledToObservers.has(i)) return "continue";
                        var o = "0px 0px ".concat(n, "px 0px"),
                          a = new IntersectionObserver(
                            function (e) {
                              e.forEach(function (e) {
                                e.isIntersecting &&
                                  (l.scrolledToElementState.set(i, !0),
                                  l.messageBus.publish("scrolled_to", {}));
                              });
                            },
                            { rootMargin: o, threshold: 0 }
                          );
                        l.scrolledToObservers.set(i, a);
                        try {
                          l.contentDocument
                            .querySelectorAll(r)
                            .forEach(function (e) {
                              a.observe(e);
                            });
                        } catch (e) {}
                      }
                    }
                  };
                  try {
                    for (var g = i(a), m = g.next(); !m.done; m = g.next()) {
                      h(m.value);
                    }
                  } catch (e) {
                    r = { error: e };
                  } finally {
                    try {
                      m && !m.done && (n = g.return) && n.call(g);
                    } finally {
                      if (r) throw r.error;
                    }
                  }
                  l.messageBus.subscribe("element_appeared", function (e) {
                    var t,
                      r,
                      n = e.mutationList,
                      a = function (e, t) {
                        var r = o(e.split("\0"), 1)[0];
                        if (
                          0 === n.length ||
                          l.isMutationRelevantToSelector(n, r)
                        )
                          try {
                            l.contentDocument
                              .querySelectorAll(r)
                              .forEach(function (e) {
                                t.observe(e);
                              });
                          } catch (e) {}
                      };
                    try {
                      for (
                        var s = i(l.scrolledToObservers.entries()),
                          u = s.next();
                        !u.done;
                        u = s.next()
                      ) {
                        var c = o(u.value, 2);
                        a(c[0], c[1]);
                      }
                    } catch (e) {
                      t = { error: e };
                    } finally {
                      try {
                        u && !u.done && (r = s.return) && r.call(s);
                      } finally {
                        if (t) throw t.error;
                      }
                    }
                  });
                }
              }
            }),
            (this.isPageObjectActive = function (e, t) {
              var r,
                n,
                i,
                o = { page: { url: l.globalScope.location.href } };
              if (
                e.conditions &&
                e.conditions.length > 0 &&
                !rn.evaluateConditions({ context: o, result: {} }, e.conditions)
              )
                return !1;
              switch (e.trigger_type) {
                case "url_change":
                  return !0;
                case "manual":
                  var a = e.trigger_value;
                  return l.manuallyActivatedPageObjects.has(a.name);
                case "analytics_event":
                  var s = e.id;
                  if (l.analyticsEventState.has(s)) return !0;
                  a = e.trigger_value;
                  var u = t,
                    c = {
                      type: "analytics_event",
                      data: { event: u.event, properties: u.properties },
                    },
                    d = rn.evaluateConditions({ context: c, result: {} }, a);
                  return d && l.analyticsEventState.add(s), d;
                case "element_appeared":
                  var f = (a = e.trigger_value).selector;
                  return l.elementAppearedState.has(f);
                case "element_visible":
                  f = (a = e.trigger_value).selector;
                  var p =
                      null !== (r = a.visibilityRatio) && void 0 !== r ? r : 0,
                    v = "".concat(f, "\0").concat(p);
                  return (
                    null !== (n = l.elementVisibilityState.get(v)) &&
                    void 0 !== n &&
                    n
                  );
                case "exit_intent":
                  var h = t.durationMs;
                  return (
                    void 0 === (a = e.trigger_value).minTimeOnPageMs ||
                    h >= a.minTimeOnPageMs
                  );
                case "user_interaction":
                  a = e.trigger_value;
                  var g = ""
                    .concat(a.selector, "\0")
                    .concat(a.interactionType, "\0")
                    .concat(a.minThresholdMs || 0);
                  return l.firedUserInteractions.has(g);
                case "time_on_page":
                  var m = t;
                  a = e.trigger_value;
                  return m.durationMs >= a.durationMs;
                case "scrolled_to":
                  if ("percent" === (a = e.trigger_value).mode)
                    return l.maxScrollPercentage >= a.percentage;
                  if ("element" === a.mode) {
                    var y = a.offsetPx || 0;
                    v = "".concat(a.selector, "\0").concat(y);
                    return (
                      null !== (i = l.scrolledToElementState.get(v)) &&
                      void 0 !== i &&
                      i
                    );
                  }
                  return !1;
                default:
                  return !1;
              }
            }),
            (this.webExperimentClient = e),
            (this.messageBus = r),
            (this.pageObjects = n),
            (this.options = a),
            (this.globalScope = s);
        }
        return (
          Object.defineProperty(e.prototype, "contentDocument", {
            get: function () {
              return (
                (e = this.globalScope),
                Qr() &&
                null !==
                  (r =
                    null === (t = $r()) || void 0 === t
                      ? void 0
                      : t.contentDocument) &&
                void 0 !== r
                  ? r
                  : e.document
              );
              var e, t, r;
            },
            enumerable: !1,
            configurable: !0,
          }),
          Object.defineProperty(e.prototype, "contentWindow", {
            get: function () {
              return (
                (e = this.globalScope),
                Qr() &&
                null !==
                  (r =
                    null === (t = $r()) || void 0 === t
                      ? void 0
                      : t.contentWindow) &&
                void 0 !== r
                  ? r
                  : e
              );
              var e, t, r;
            },
            enumerable: !1,
            configurable: !0,
          }),
          (e.prototype.getDebugPageObjects = function () {
            var e,
              t,
              r = this,
              n = {},
              a = this.webExperimentClient.getActivePages(),
              s = function (e, t) {
                n[e] = Object.values(t).map(function (t) {
                  var n = r.evaluateUrlConditions(t),
                    i = r.buildTriggerDebugInfo(t, e, a);
                  return {
                    id: t.id,
                    name: t.name,
                    urlConditionsPassed: n,
                    triggerPassed: i.passed,
                    trigger: i,
                    overallStatus: n && i.passed ? "pass" : "fail",
                  };
                });
              };
            try {
              for (
                var l = i(Object.entries(this.pageObjects)), u = l.next();
                !u.done;
                u = l.next()
              ) {
                var c = o(u.value, 2);
                s(c[0], c[1]);
              }
            } catch (t) {
              e = { error: t };
            } finally {
              try {
                u && !u.done && (t = l.return) && t.call(l);
              } finally {
                if (e) throw e.error;
              }
            }
            return n;
          }),
          (e.prototype.evaluateUrlConditions = function (e) {
            return (
              !e.conditions ||
              0 === e.conditions.length ||
              rn.evaluateConditions(
                {
                  context: { page: { url: this.globalScope.location.href } },
                  result: {},
                },
                e.conditions
              )
            );
          }),
          (e.prototype.buildTriggerDebugInfo = function (e, t, r) {
            var n, i, o;
            switch (e.trigger_type) {
              case "url_change":
                return { type: "url_change", passed: !0 };
              case "element_appeared":
                var a = e.trigger_value.selector;
                return {
                  type: "element_appeared",
                  passed: this.elementAppearedState.has(a),
                  config: { selector: a },
                };
              case "element_visible":
                var s = e.trigger_value,
                  l = ((a = s.selector), s.visibilityRatio),
                  u = null != l ? l : 0,
                  c = "".concat(a, "\0").concat(u);
                return {
                  type: "element_visible",
                  passed:
                    null !== (n = this.elementVisibilityState.get(c)) &&
                    void 0 !== n &&
                    n,
                  config: { selector: a, visibilityRatio: u },
                };
              case "manual":
                var d = e.trigger_value.name;
                return {
                  type: "manual",
                  passed: this.manuallyActivatedPageObjects.has(d),
                  config: { name: d },
                };
              case "analytics_event":
                return {
                  type: "analytics_event",
                  passed: this.analyticsEventState.has(e.id),
                  config: { conditions: e.trigger_value },
                };
              case "user_interaction":
                var f = e.trigger_value,
                  p = ((a = f.selector), f.interactionType),
                  v = f.minThresholdMs || 0;
                c = "".concat(a, "\0").concat(p, "\0").concat(v);
                return {
                  type: "user_interaction",
                  passed: this.firedUserInteractions.has(c),
                  config: {
                    selector: a,
                    interactionType: p,
                    minThresholdMs: v,
                  },
                };
              case "exit_intent":
                var h = e.trigger_value.minTimeOnPageMs;
                return {
                  type: "exit_intent",
                  passed: !!(null === (i = r[t]) || void 0 === i
                    ? void 0
                    : i[e.id]),
                  config: { minTimeOnPageMs: h },
                };
              case "time_on_page":
                var g = e.trigger_value.durationMs,
                  m = Math.max(0, Date.now() - this.pageLoadTime);
                return {
                  type: "time_on_page",
                  passed: !(g in this.timeOnPageTimeouts),
                  config: { durationMs: g },
                  elapsedMs: m,
                };
              case "scrolled_to":
                var y = e.trigger_value;
                if ("percent" === y.mode) {
                  var b = y.percentage;
                  return {
                    type: "scrolled_to",
                    passed: this.maxScrollPercentage >= b,
                    config: { mode: "percent", percentage: b },
                    currentPercentage: Math.round(this.maxScrollPercentage),
                  };
                }
                a = y.selector;
                var w = y.offsetPx,
                  x = w || 0;
                c = "".concat(a, "\0").concat(x);
                return {
                  type: "scrolled_to",
                  passed:
                    null !== (o = this.scrolledToElementState.get(c)) &&
                    void 0 !== o &&
                    o,
                  config: { mode: "element", selector: a, offsetPx: w },
                };
              default:
                return { type: "url_change", passed: !1 };
            }
          }),
          (e.prototype.isMutationRelevantToSelector = function (e, t) {
            var r, n, o, a;
            try {
              for (var s = i(e), l = s.next(); !l.done; l = s.next()) {
                var u = l.value;
                if (u.addedNodes.length > 0)
                  try {
                    for (
                      var c = ((o = void 0), i(Array.from(u.addedNodes))),
                        d = c.next();
                      !d.done;
                      d = c.next()
                    ) {
                      var f = d.value;
                      if (f.nodeType === Node.ELEMENT_NODE)
                        try {
                          var p = f;
                          if (p.matches(t)) return !0;
                          if (p.querySelector(t)) return !0;
                        } catch (e) {}
                    }
                  } catch (e) {
                    o = { error: e };
                  } finally {
                    try {
                      d && !d.done && (a = c.return) && a.call(c);
                    } finally {
                      if (o) throw o.error;
                    }
                  }
                if (u.target.nodeType === Node.ELEMENT_NODE)
                  try {
                    var v = u.target;
                    if (v.matches(t)) return !0;
                    if (v.querySelector(t)) return !0;
                  } catch (e) {}
              }
            } catch (e) {
              r = { error: e };
            } finally {
              try {
                l && !l.done && (n = s.return) && n.call(s);
              } finally {
                if (r) throw r.error;
              }
            }
            return !1;
          }),
          (e.prototype.calculateScrollPercentage = function () {
            var e = this.contentWindow.innerHeight,
              t = this.contentDocument.documentElement.scrollHeight,
              r = this.contentWindow.scrollY,
              n = t - e;
            return n <= 0 ? 0 : (r / n) * 100;
          }),
          e
        );
      })(),
      on = { useDefaultNavigationHandler: !0 },
      an = function () {
        var e = be();
        if (!(null == e ? void 0 : e.document.getElementById("amp-exp-css"))) {
          var t = document.createElement("style");
          (t.id = "amp-exp-css"),
            (t.innerText =
              "* { visibility: hidden !important; background-image: none !important; }"),
            document.head.appendChild(t),
            null == e ||
              e.window.setTimeout(function () {
                t.remove();
              }, 1e3);
        }
      },
      sn = "AMP",
      ln = "dclid",
      un = "fbclid",
      cn = "gbraid",
      dn = "gclid",
      fn = "ko_click_id",
      pn = "li_fat_id",
      vn = "msclkid",
      hn = "rdt_cid",
      gn = "ttclid",
      mn = "twclid",
      yn = "wbraid",
      bn = {
        utm_campaign: void 0,
        utm_content: void 0,
        utm_id: void 0,
        utm_medium: void 0,
        utm_source: void 0,
        utm_term: void 0,
        referrer: void 0,
        referring_domain: void 0,
        dclid: void 0,
        gbraid: void 0,
        gclid: void 0,
        fbclid: void 0,
        ko_click_id: void 0,
        li_fat_id: void 0,
        msclkid: void 0,
        rdt_cid: void 0,
        ttclid: void 0,
        twclid: void 0,
        wbraid: void 0,
      },
      wn = "MKTG",
      xn = function () {
        var e = "ampIntegrationContext";
        return "undefined" != typeof globalThis && void 0 !== globalThis[e]
          ? globalThis[e]
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof window
          ? window
          : "undefined" != typeof self
          ? self
          : "undefined" != typeof global
          ? global
          : void 0;
      },
      Sn = function () {
        var e,
          t = xn();
        return (
          null === (e = null == t ? void 0 : t.location) || void 0 === e
            ? void 0
            : e.search
        )
          ? t.location.search
              .substring(1)
              .split("&")
              .filter(Boolean)
              .reduce(function (e, t) {
                var r = t.split("=", 2),
                  n = kn(r[0]),
                  i = kn(r[1]);
                return i ? ((e[n] = i), e) : e;
              }, {})
          : {};
      },
      kn = function (e) {
        void 0 === e && (e = "");
        try {
          return decodeURIComponent(e);
        } catch (e) {
          return "";
        }
      },
      En = (function () {
        function e(e, r) {
          void 0 === r && (r = {}),
            (this.options = t({}, e)),
            (this.config = r);
        }
        return (
          (e.prototype.isEnabled = function () {
            return r(this, void 0, void 0, function () {
              var r,
                i,
                o,
                a,
                s = this;
              return n(this, function (n) {
                switch (n.label) {
                  case 0:
                    return (
                      (r = "AMP_TEST"),
                      (i = t({}, this.options)),
                      (o = new e(i)),
                      (a = String(Date.now())),
                      [
                        4,
                        o.transaction(r, function (e) {
                          var t, n;
                          try {
                            e.set(a);
                            var i = e.get() === a;
                            return (
                              !i &&
                                s.config.diagnosticsClient &&
                                (null === (t = s.config.diagnosticsClient) ||
                                  void 0 === t ||
                                  t.recordEvent("cookies.isEnabled.failure", {
                                    reason: "Test Value mismatch",
                                    testKey: r,
                                    testValue: a,
                                    sync: !0,
                                  })),
                              i
                            );
                          } catch (e) {
                            if (s.config.diagnosticsClient) {
                              var o =
                                e instanceof Error ? e.message : String(e);
                              null === (n = s.config.diagnosticsClient) ||
                                void 0 === n ||
                                n.recordEvent("cookies.isEnabled.failure", {
                                  reason: "Cookie getter/setter failed",
                                  testKey: r,
                                  testValue: a,
                                  error: o,
                                  sync: !0,
                                });
                            }
                            return !1;
                          } finally {
                            e.set(null);
                          }
                        }),
                      ]
                    );
                  case 1:
                    return [2, n.sent()];
                }
              });
            });
          }),
          (e.prototype.get = function (e) {
            return r(this, void 0, void 0, function () {
              var t;
              return n(this, function (r) {
                switch (r.label) {
                  case 0:
                    return [4, this.getRaw(e)];
                  case 1:
                    return (t = r.sent()), [2, this.decodeCookieValue(e, t)];
                }
              });
            });
          }),
          (e.prototype.decodeCookieValue = function (e, t) {
            if (t)
              try {
                var r = _n(t);
                return void 0 === r
                  ? void console.error(
                      "Amplitude Logger [Error]: Failed to decode cookie value for key: "
                        .concat(e, ", value: ")
                        .concat(t)
                    )
                  : JSON.parse(r);
              } catch (r) {
                return void console.error(
                  "Amplitude Logger [Error]: Failed to parse cookie value for key: "
                    .concat(e, ", value: ")
                    .concat(t)
                );
              }
          }),
          (e.prototype.getSync = function (e) {
            var t = this.getRawSync(e);
            return this.decodeCookieValue(e, t);
          }),
          (e.prototype.getRaw = function (e) {
            var t, o;
            return r(this, void 0, void 0, function () {
              var r, a, s, l, u, c, d, f, p;
              return n(this, function (n) {
                switch (n.label) {
                  case 0:
                    (r = xn()), (a = r), (n.label = 1);
                  case 1:
                    return (
                      n.trys.push([1, 4, , 5]),
                      (s = null == a ? void 0 : a.cookieStore)
                        ? [4, s.getAll(e)]
                        : [3, 3]
                    );
                  case 2:
                    if ((l = n.sent())) {
                      l.length > 1 &&
                        (null === (t = this.config.diagnosticsClient) ||
                          void 0 === t ||
                          t.recordEvent("cookies.duplicate", {
                            cookies: l.map(function (e) {
                              return e.domain;
                            }),
                          }),
                        null === (o = this.config.diagnosticsClient) ||
                          void 0 === o ||
                          o.increment(
                            "cookies.duplicate.occurrence.cookieStore"
                          ));
                      try {
                        for (u = i(l), c = u.next(); !c.done; c = u.next())
                          if (
                            ((d = c.value), On(d.domain, this.options.domain))
                          )
                            return [2, d.value];
                      } catch (e) {
                        f = { error: e };
                      } finally {
                        try {
                          c && !c.done && (p = u.return) && p.call(u);
                        } finally {
                          if (f) throw f.error;
                        }
                      }
                    }
                    n.label = 3;
                  case 3:
                    return [3, 5];
                  case 4:
                    return n.sent(), [3, 5];
                  case 5:
                    return [2, this.getRawSync(e)];
                }
              });
            });
          }),
          (e.prototype.getRawSync = function (e) {
            var t,
              r,
              n = this,
              i = xn(),
              o = (
                null !==
                  (r =
                    null === (t = null == i ? void 0 : i.document) ||
                    void 0 === t
                      ? void 0
                      : t.cookie.split("; ")) && void 0 !== r
                  ? r
                  : []
              ).filter(function (t) {
                return 0 === t.indexOf(e + "=");
              }),
              a = void 0,
              s = this.config.duplicateResolverFn;
            if (
              ("function" == typeof s &&
                o.length > 1 &&
                (a = o.find(function (t) {
                  var r;
                  try {
                    var i = s(t.substring(e.length + 1));
                    return (
                      i ||
                        null === (r = n.config.diagnosticsClient) ||
                        void 0 === r ||
                        r.increment(
                          "cookies.duplicate.occurrence.document.cookie"
                        ),
                      i
                    );
                  } catch (e) {
                    return !1;
                  }
                })),
              a || (a = o[0]),
              a)
            )
              return a.substring(e.length + 1);
          }),
          (e.prototype.set = function (e, t) {
            return r(this, void 0, void 0, function () {
              return n(this, function (r) {
                return this.setSync(e, t), [2];
              });
            });
          }),
          (e.prototype.setSync = function (e, t) {
            var r;
            try {
              var n =
                  null !== (r = this.options.expirationDays) && void 0 !== r
                    ? r
                    : 0,
                i = null !== t ? n : -1,
                o = void 0;
              if (i) {
                var a = new Date();
                a.setTime(a.getTime() + 24 * i * 60 * 60 * 1e3), (o = a);
              }
              var s = ""
                .concat(e, "=")
                .concat(btoa(encodeURIComponent(JSON.stringify(t))));
              o && (s += "; expires=".concat(o.toUTCString())),
                (s += "; path=/"),
                this.options.domain &&
                  (s += "; domain=".concat(this.options.domain)),
                this.options.secure && (s += "; Secure"),
                this.options.sameSite &&
                  (s += "; SameSite=".concat(this.options.sameSite));
              var l = xn();
              (null == l ? void 0 : l.document) && (l.document.cookie = s);
            } catch (t) {
              var u = t instanceof Error ? t.message : String(t);
              console.error(
                "Amplitude Logger [Error]: Failed to set cookie for key: "
                  .concat(e, ". Error: ")
                  .concat(u)
              );
            }
          }),
          (e.prototype.remove = function (e) {
            return r(this, void 0, void 0, function () {
              return n(this, function (t) {
                switch (t.label) {
                  case 0:
                    return [4, this.set(e, null)];
                  case 1:
                    return t.sent(), [2];
                }
              });
            });
          }),
          (e.prototype.reset = function () {
            return r(this, void 0, void 0, function () {
              return n(this, function (e) {
                return [2];
              });
            });
          }),
          (e.isDomainWritable = function (t) {
            return r(this, void 0, void 0, function () {
              var r, i;
              return n(this, function (n) {
                switch (n.label) {
                  case 0:
                    if (e.cachedTlds[t]) return [2, !0];
                    (r = "AMP_TLDTEST"),
                      (i = new e({ domain: "." + t })),
                      (n.label = 1);
                  case 1:
                    return (
                      n.trys.push([1, 3, , 4]),
                      [
                        4,
                        i.transaction(r, function (r) {
                          if (e.cachedTlds[t]) return !0;
                          try {
                            r.set(1);
                            var n = !!r.get();
                            return n && (e.cachedTlds[t] = !0), n;
                          } finally {
                            r.set(null);
                          }
                        }),
                      ]
                    );
                  case 2:
                    return [2, !!n.sent()];
                  case 3:
                    return n.sent(), [2, !1];
                  case 4:
                    return [2];
                }
              });
            });
          }),
          (e.prototype.transaction = function (e, t) {
            return r(this, void 0, void 0, function () {
              var r,
                i,
                o = this;
              return n(this, function (n) {
                switch (n.label) {
                  case 0:
                    if (
                      ((r = (function () {
                        var e,
                          t = xn();
                        return null ===
                          (e = null == t ? void 0 : t.navigator) || void 0 === e
                          ? void 0
                          : e.locks;
                      })()),
                      (i = function () {
                        return t({
                          get: function () {
                            return o.getSync(e);
                          },
                          set: function (t) {
                            return o.setSync(e, t);
                          },
                        });
                      }),
                      !r)
                    )
                      return [2, i()];
                    n.label = 1;
                  case 1:
                    return (
                      n.trys.push([1, 3, , 4]),
                      [4, r.request("com.amplitude:cookie-lock:".concat(e), i)]
                    );
                  case 2:
                    return [2, n.sent()];
                  case 3:
                    return n.sent(), [2, i()];
                  case 4:
                    return [2];
                }
              });
            });
          }),
          (e.cachedTlds = {}),
          e
        );
      })(),
      _n = function (e) {
        var t;
        return null !==
          (t = (function (e) {
            try {
              return decodeURIComponent(atob(e));
            } catch (e) {
              return;
            }
          })(e)) && void 0 !== t
          ? t
          : (function (e) {
              try {
                return decodeURIComponent(atob(decodeURIComponent(e)));
              } catch (e) {
                return;
              }
            })(e);
      },
      On = function (e, t) {
        if ("" === e && "" === t) return !0;
        if (!e || !t) return !1;
        var r = e.startsWith(".") ? e.substring(1) : e,
          n = t.startsWith(".") ? t.substring(1) : t;
        return r.toLowerCase() === n.toLowerCase();
      },
      An = (function () {
        function e() {}
        return (
          (e.prototype.parse = function () {
            return r(this, void 0, void 0, function () {
              return n(this, function (e) {
                return [
                  2,
                  t(
                    t(t(t({}, bn), this.getUtmParam()), this.getReferrer()),
                    this.getClickIds()
                  ),
                ];
              });
            });
          }),
          (e.prototype.getUtmParam = function () {
            var e = Sn();
            return {
              utm_campaign: e.utm_campaign,
              utm_content: e.utm_content,
              utm_id: e.utm_id,
              utm_medium: e.utm_medium,
              utm_source: e.utm_source,
              utm_term: e.utm_term,
            };
          }),
          (e.prototype.getReferrer = function () {
            var e,
              t,
              r = { referrer: void 0, referring_domain: void 0 };
            try {
              (r.referrer = document.referrer || void 0),
                (r.referring_domain =
                  null !==
                    (t =
                      null === (e = r.referrer) || void 0 === e
                        ? void 0
                        : e.split("/")[2]) && void 0 !== t
                    ? t
                    : void 0);
            } catch (e) {}
            return r;
          }),
          (e.prototype.getClickIds = function () {
            var e,
              t = Sn();
            return (
              ((e = {})[ln] = t[ln]),
              (e[un] = t[un]),
              (e[cn] = t[cn]),
              (e[dn] = t[dn]),
              (e[fn] = t[fn]),
              (e[pn] = t[pn]),
              (e[vn] = t[vn]),
              (e[hn] = t[hn]),
              (e[gn] = t[gn]),
              (e[mn] = t[mn]),
              (e[yn] = t[yn]),
              e
            );
          }),
          e
        );
      })(),
      Pn = function (e, t) {
        var r;
        try {
          var n = null === (r = Tn(e)) || void 0 === r ? void 0 : r.getItem(t);
          return n ? JSON.parse(n) : null;
        } catch (t) {
          return (
            console.warn(
              "Failed to get and parse JSON from ".concat(e, ":"),
              t
            ),
            null
          );
        }
      },
      Cn = function (e, t, r) {
        var n;
        try {
          var i = JSON.stringify(r);
          null === (n = Tn(e)) || void 0 === n || n.setItem(t, i);
        } catch (t) {
          console.warn(
            "Failed to stringify and set JSON in ".concat(e, ":"),
            t
          );
        }
      },
      Mn = function (e, t) {
        var r;
        try {
          null === (r = Tn(e)) || void 0 === r || r.removeItem(t);
        } catch (t) {
          console.warn("Failed to remove item from ".concat(e, ":"), t);
        }
      },
      Tn = function (e) {
        var t = be();
        return t ? t[e] : null;
      };
    function In(e, a) {
      return r(this, void 0, void 0, function () {
        var r, s, l, u, c, d, f, p, v, h, g, m, y, b, w, x, S, k, E;
        return n(this, function (n) {
          switch (n.label) {
            case 0:
              return (
                (r = "EXP_".concat(wn, "_").concat(e.substring(0, 10))),
                [4, jn(e)]
              );
            case 1:
              (s = o.apply(void 0, [n.sent(), 2])),
                (l = s[0]),
                (u = s[1]),
                (c = Pn("localStorage", r)),
                (d = {}),
                (f = [u, c, l]);
              try {
                for (p = i(f), v = p.next(); !v.done; v = p.next())
                  if ((h = v.value))
                    try {
                      for (
                        k = void 0, g = i(Object.entries(h)), m = g.next();
                        !m.done;
                        m = g.next()
                      )
                        (y = o(m.value, 2)),
                          (b = y[0]),
                          (w = y[1]),
                          b.startsWith("utm_") && void 0 !== w && (d[b] = w);
                    } catch (e) {
                      k = { error: e };
                    } finally {
                      try {
                        m && !m.done && (E = g.return) && E.call(g);
                      } finally {
                        if (k) throw k.error;
                      }
                    }
              } catch (e) {
                x = { error: e };
              } finally {
                try {
                  v && !v.done && (S = p.return) && S.call(p);
                } finally {
                  if (x) throw x.error;
                }
              }
              return Object.keys(d).length > 0
                ? ((function (e, t) {
                    var r = "EXP_".concat(wn, "_").concat(e.substring(0, 10));
                    Cn("localStorage", r, t);
                  })(e, d),
                  [2, t(t({}, a), { persisted_url_param: d })])
                : [2, a];
          }
        });
      });
    }
    function jn(e) {
      return r(this, void 0, void 0, function () {
        var t, r, i, o;
        return n(this, function (n) {
          switch (n.label) {
            case 0:
              return (
                (t = new En()),
                (r = (function (e, t, r) {
                  return (
                    void 0 === t && (t = ""),
                    void 0 === r && (r = 10),
                    [sn, t, e.substring(0, r)].filter(Boolean).join("_")
                  );
                })(e, wn)),
                [4, new An().parse()]
              );
            case 1:
              return (i = n.sent()), [4, t.get(r)];
            case 2:
              return (o = n.sent()), [2, [i, o]];
          }
        });
      });
    }
    var Nn,
      Vn = "amp-exp-loading",
      Ln = function () {
        if (!document.getElementById(Vn)) {
          var e = document.createElement("div");
          (e.id = Vn),
            (Nn = setTimeout(function () {
              Dn();
            }, 1e4)),
            (e.innerHTML = "\n    <style>\n      #"
              .concat(
                Vn,
                " {\n        position: fixed;\n        inset: 0;\n        background: rgba(33, 33, 36, 0.4);\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        z-index: 2147483647;\n      }\n\n      #"
              )
              .concat(
                Vn,
                " .modal {\n        background: white;\n        border-radius: 8px;\n        padding: 32px 48px;\n        display: flex;\n        flex-direction: column;\n        align-items: center;\n        gap: 16px;\n        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.15);\n      }\n\n      #"
              )
              .concat(
                Vn,
                " .spinner {\n        width: 32px;\n        height: 32px;\n        border: 3px solid #e5e7eb;\n        border-top-color: "
              )
              .concat(
                "#1e61f0",
                ";\n        border-radius: 50%;\n        animation: amp-spin 1s linear infinite;\n      }\n\n      @keyframes amp-spin {\n        to { transform: rotate(360deg); }\n      }\n\n      #"
              )
              .concat(
                Vn,
                ' .text {\n        color: #212124;\n        font-size: 16px;\n        font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif;\n      }\n    </style>\n\n    <div class="modal">\n      <div class="spinner"></div>\n      <div class="text">Loading Visual Editor</div>\n    </div>\n  '
              ));
          var t = function () {
            document.getElementById(Vn) ||
              void 0 === Nn ||
              document.body.appendChild(e);
          };
          document.body
            ? t()
            : document.addEventListener("DOMContentLoaded", t, { once: !0 });
        }
      },
      Dn = function () {
        var e;
        Nn && (clearTimeout(Nn), (Nn = void 0)),
          null === (e = document.getElementById(Vn)) ||
            void 0 === e ||
            e.remove();
      },
      Un = "visual-editor-state",
      Fn = (function () {
        function e() {}
        return (
          (e.setup = function () {
            var t,
              r = "closed",
              n = e.getStoredSession();
            if (n)
              return (
                qr(
                  "setup",
                  "stored session found, loading ".concat(n.injectSrc)
                ),
                zr("loading"),
                (r = "opening"),
                Ln(),
                void Rn(n.injectSrc)
                  .then(function () {
                    (r = "open"),
                      zr("loaded"),
                      qr("script_load_success", "from stored session");
                  })
                  .catch(function (e) {
                    console.warn(
                      "Failed to load overlay from stored session:",
                      e
                    ),
                      (r = "closed"),
                      zr("error"),
                      qr(
                        "script_load_error",
                        "from stored session: ".concat(
                          (null == e ? void 0 : e.message) || e
                        )
                      ),
                      Dn();
                  })
              );
            qr("setup", "no stored session, registering message listener"),
              zr("waiting"),
              null === (t = be()) ||
                void 0 === t ||
                t.addEventListener("message", function (e) {
                  var t = /^.*\.amplitude\.com$/;
                  try {
                    if (!e.origin || !t.test(new URL(e.origin).hostname))
                      return void qr(
                        "origin_validation",
                        "FAIL: ".concat(e.origin || "(empty)")
                      );
                  } catch (t) {
                    return void qr(
                      "origin_validation",
                      "FAIL: exception parsing origin ".concat(e.origin)
                    );
                  }
                  if ("OpenOverlay" === e.data.type) {
                    qr(
                      "message_received",
                      "origin=".concat(e.origin, ", type=OpenOverlay")
                    ),
                      qr("origin_validation", "PASS");
                    var n = new URL(e.data.context.injectSrc);
                    if ("closed" !== r)
                      return void qr(
                        "state_guard",
                        "rejected: state=".concat(r)
                      );
                    if ("https:" !== n.protocol || !t.test(n.hostname))
                      return void qr(
                        "injectSrc_validation",
                        "FAIL: ".concat(n.href)
                      );
                    qr(
                      "injectSrc_validation",
                      "PASS (".concat(n.hostname, ")")
                    ),
                      zr("loading"),
                      (r = "opening"),
                      Ln(),
                      Rn(e.data.context.injectSrc)
                        .then(function () {
                          (r = "open"), zr("loaded"), qr("script_load_success");
                        })
                        .catch(function () {
                          (r = "closed"),
                            zr("error"),
                            qr(
                              "script_load_error",
                              "Failed to load ".concat(e.data.context.injectSrc)
                            ),
                            Dn();
                        });
                  }
                });
          }),
          (e.getStoredSession = function () {
            var e = Pn("sessionStorage", Un);
            if (!e) return null;
            try {
              var t = new URL(e.injectSrc);
              if (
                "https:" !== t.protocol ||
                !/^.*\.amplitude\.com$/.test(t.hostname)
              )
                return null;
            } catch (e) {
              return null;
            }
            return e;
          }),
          e
        );
      })(),
      Rn = function (e) {
        return new Promise(function (t, r) {
          qr("script_load_start", "loading ".concat(e));
          qr("readyState", document.readyState),
            (function () {
              var n;
              try {
                var i = document.createElement("script");
                (i.type = "text/javascript"), (i.async = !0), (i.src = e);
                var o = document.querySelector("[nonce]");
                if (o) {
                  var a = o.nonce || o.nonce || o.getAttribute("nonce");
                  i.setAttribute("nonce", a),
                    qr("nonce_check", "found: ".concat(a));
                } else qr("nonce_check", "not found, skipping");
                i.addEventListener(
                  "load",
                  function () {
                    t({ status: !0 });
                  },
                  { once: !0 }
                ),
                  i.addEventListener("error", function () {
                    r({
                      status: !1,
                      message: "Failed to load the script ".concat(e),
                    });
                  }),
                  null === (n = document.head) ||
                    void 0 === n ||
                    n.appendChild(i);
              } catch (e) {
                r(e);
              }
            })();
        });
      },
      Bn = function () {
        var e,
          t,
          r = be(),
          n = new URLSearchParams(null == r ? void 0 : r.location.search),
          a = {};
        try {
          for (var s = i(n), l = s.next(); !l.done; l = s.next()) {
            var u = o(l.value, 2),
              c = u[0],
              d = u[1];
            a[c] = d;
          }
        } catch (t) {
          e = { error: t };
        } finally {
          try {
            l && !l.done && (t = s.return) && t.call(s);
          } finally {
            if (e) throw e.error;
          }
        }
        return a;
      },
      Kn = function (e) {
        if (!e) return "";
        var t = new URL(e);
        return (t.search = ""), (t.hash = ""), t.toString();
      },
      qn = function (e, t) {
        var r,
          n,
          o = new URL(e);
        try {
          for (var a = i(t), s = a.next(); !s.done; s = a.next()) {
            var l = s.value;
            o.searchParams.delete(l);
          }
        } catch (e) {
          r = { error: e };
        } finally {
          try {
            s && !s.done && (n = a.return) && n.call(a);
          } finally {
            if (r) throw r.error;
          }
        }
        return o.toString();
      },
      zn = function (e, t) {
        return (
          (t = t.replace(/\/$/, "")),
          e.some(function (e) {
            e = (e = (e = e.replace(/\/$/, "")).replace(
              /[.*+?^${}()|[\]\\]/g,
              "\\$&"
            )).replace(/\\\*/, ".*");
            var r = new RegExp("^".concat(e, "$"));
            return r.test(t) || r.test(t + "/");
          })
        );
      },
      Wn = function (e) {
        return e
          ? (e ^ ((16 * Math.random()) >> (e / 4))).toString(16)
          : (
              String(1e7) +
              String(-1e3) +
              String(-4e3) +
              String(-8e3) +
              String(-1e11)
            ).replace(/[018]/g, Wn);
      },
      Hn = "mutate",
      Jn = "inject",
      Gn = "PREVIEW",
      Xn = "amp-preview-mode",
      Qn = "VISUAL_EDITOR";
    ye.Experiment = It;
    var $n = (function () {
      function e(e, r, n) {
        void 0 === n && (n = {});
        var i,
          o = this;
        (this.appliedInjections = new Set()),
          (this.appliedMutations = {}),
          (this.previousUrl = void 0),
          (this.urlExposureCache = {}),
          (this.flagVariantMap = {}),
          (this.localFlagKeys = []),
          (this.remoteFlagKeys = []),
          (this.isRemoteBlocking = !1),
          (this.isRunning = !1),
          (this.activePages = {}),
          (this.isVisualEditorMode = !1),
          (this.isDebugActive = !1),
          (this.isPreviewMode = !1),
          (this.previewFlags = {});
        var a = be();
        if (!a || !we())
          throw new Error(
            "Amplitude Web Experiment Client could not be initialized."
          );
        (this.globalScope = a),
          (this.apiKey = e),
          (this.initialFlags = JSON.parse(r.initialFlags)),
          (this.pageObjects = JSON.parse(r.pageObjects)),
          (this.config = t(
            t(t({}, on), n),
            null !== (i = this.globalScope.experimentConfig) && void 0 !== i
              ? i
              : {}
          )),
          this.initialFlags.forEach(function (e) {
            var t = e.key,
              r = e.variants,
              n = e.metadata,
              i = void 0 === n ? {} : n;
            (o.flagVariantMap[t] = {}),
              Object.keys(r).forEach(function (e) {
                (o.flagVariantMap[t][e] = (function (e) {
                  if (!e) return {};
                  var t = void 0;
                  e.metadata &&
                    (t =
                      "string" == typeof e.metadata.experimentKey
                        ? e.metadata.experimentKey
                        : void 0);
                  var r = {};
                  return (
                    e.key && (r.key = e.key),
                    e.value && (r.value = e.value),
                    e.payload && (r.payload = e.payload),
                    t && (r.expKey = t),
                    e.metadata && (r.metadata = e.metadata),
                    r
                  );
                })(r[e])),
                  (o.flagVariantMap[t][e].metadata = { deliveryMethod: "web" });
              }),
              "local" !== i.evaluationMode && o.remoteFlagKeys.push(t);
          });
        var s = JSON.stringify(this.initialFlags);
        this.experimentClient = Mt.initialize(
          this.apiKey,
          t(
            {
              internalInstanceNameSuffix: "web",
              initialFlags: s,
              fetchTimeoutMillis: 1e3,
              pollOnStart: !1,
              fetchOnStart: !1,
              automaticExposureTracking: !1,
            },
            this.config
          )
        );
        var l = this.experimentClient.all();
        (this.localFlagKeys = Object.keys(l).filter(function (e) {
          var t, r;
          return (
            "local" ===
            (null ===
              (r = null === (t = l[e]) || void 0 === t ? void 0 : t.metadata) ||
            void 0 === r
              ? void 0
              : r.evaluationMode)
          );
        })),
          (this.messageBus = new Lr());
      }
      return (
        (e.prototype.start = function () {
          return r(this, void 0, void 0, function () {
            var e,
              r,
              a,
              s,
              l,
              u,
              c,
              d,
              f,
              p,
              v,
              h,
              g,
              m,
              y,
              b,
              w,
              x,
              S = this;
            return n(this, function (n) {
              switch (n.label) {
                case 0:
                  return this.isRunning
                    ? [2]
                    : ((HTMLElement.prototype.removeChild = function (e) {
                        return e && e.parentNode !== this
                          ? e
                          : Node.prototype.removeChild.call(this, e);
                      }),
                      (e = Bn()),
                      this.globalScope.self !== this.globalScope.top && Qr()
                        ? ((this.globalScope.ampDomMutator = jr),
                          (this.isRunning = !0),
                          [2])
                        : ((this.isVisualEditorMode =
                            "true" === e[Qn] ||
                            null !== Pn("sessionStorage", Un)),
                          Br(this.globalScope),
                          (this.isDebugActive = Kr()),
                          (this.subscriptionManager = new nn(
                            this,
                            this.messageBus,
                            this.pageObjects,
                            t(t({}, this.config), {
                              isVisualEditorMode: this.isVisualEditorMode,
                              isDebugActive: this.isDebugActive,
                            }),
                            this.globalScope
                          )),
                          this.setupPreviewMode(e),
                          this.subscriptionManager.initSubscriptions(),
                          Wr(function () {
                            return {
                              flags: S.buildFlagDebugInfo(),
                              visualEditor: {
                                isActive: S.isVisualEditorMode,
                                source: S.isVisualEditorMode
                                  ? null !== Pn("sessionStorage", Un)
                                    ? "session_storage"
                                    : "url_param"
                                  : null,
                              },
                              currentUrl: S.globalScope.location.href,
                            };
                          }),
                          this.isVisualEditorMode
                            ? Qr()
                              ? [4, Yr(this.globalScope)]
                              : [3, 2]
                            : [3, 3]));
                case 1:
                  n.sent(), (n.label = 2);
                case 2:
                  return (
                    Fn.setup(),
                    (r = "true" === e[Qn] ? "url_param" : "session_storage"),
                    qr("ve_mode_detected", "source=".concat(r)),
                    this.globalScope.history.replaceState(
                      {},
                      "",
                      qn(this.globalScope.location.href, [Qn])
                    ),
                    qr(
                      "url_param_removed",
                      "cleaned URL: ".concat(this.globalScope.location.href)
                    ),
                    this.subscriptionManager.markUrlAsPublished(
                      this.globalScope.location.href
                    ),
                    this.messageBus.publish("url_change", {
                      updateActivePages: !0,
                    }),
                    (this.isRunning = !0),
                    oi(this),
                    [2]
                  );
                case 3:
                  this.subscriptionManager.markUrlAsPublished(
                    this.globalScope.location.href
                  ),
                    this.messageBus.publish("url_change", {
                      updateActivePages: !0,
                    }),
                    (a = "EXP_".concat(this.apiKey.slice(0, 10))),
                    (s = Pn("localStorage", a) || {}).web_exp_id
                      ? s.web_exp_id &&
                        s.device_id &&
                        (delete s.device_id, Cn("localStorage", a, s))
                      : ((s.web_exp_id = s.device_id || Wn()),
                        delete s.device_id,
                        Cn("localStorage", a, s)),
                    (l = this.getVariants());
                  try {
                    for (
                      u = i(Object.entries(l)), c = u.next();
                      !c.done;
                      c = u.next()
                    )
                      (d = o(c.value, 2)),
                        (f = d[0]),
                        (p = d[1]),
                        this.remoteFlagKeys.includes(f) &&
                          (null === (y = p.metadata) || void 0 === y
                            ? void 0
                            : y.blockingEvaluation) &&
                          Object.keys(this.activePages).includes(f) &&
                          !this.remoteFlagKeys.every(function (e) {
                            return Object.keys(S.previewFlags).includes(e);
                          }) &&
                          ((this.isRemoteBlocking = !0), an());
                  } catch (e) {
                    g = { error: e };
                  } finally {
                    try {
                      c && !c.done && (m = u.return) && m.call(u);
                    } finally {
                      if (g) throw g.error;
                    }
                  }
                  return [4, In(this.apiKey, s)];
                case 4:
                  return (
                    (v = n.sent()),
                    this.globalScope.experimentIntegration ||
                      ((h = Te.getInstance("$default_instance")),
                      (this.globalScope.experimentIntegration = new Je(
                        this.apiKey,
                        h,
                        1e3
                      ))),
                    (this.globalScope.experimentIntegration.type =
                      "integration"),
                    this.experimentClient.addPlugin(
                      this.globalScope.experimentIntegration
                    ),
                    this.experimentClient.setUser(v),
                    this.isRemoteBlocking ||
                      null ===
                        (x =
                          null ===
                            (w = (b = this.globalScope.document)
                              .getElementById) || void 0 === w
                            ? void 0
                            : w.call(b, "amp-exp-css")) ||
                      void 0 === x ||
                      x.remove(),
                    this.applyVariants({ flagKeys: this.localFlagKeys }),
                    this.previewVariants({ keyToVariant: this.previewFlags }),
                    this.remoteFlagKeys.every(function (e) {
                      return Object.keys(S.previewFlags).includes(e);
                    })
                      ? ((this.isRunning = !0), oi(this), [2])
                      : [4, this.fetchRemoteFlags()]
                  );
                case 5:
                  return (
                    n.sent(),
                    this.applyVariants({ flagKeys: this.remoteFlagKeys }),
                    (this.isRunning = !0),
                    oi(this),
                    [2]
                  );
              }
            });
          });
        }),
        (e.getInstance = function (t, r, n) {
          void 0 === n && (n = {});
          var i = be();
          if (!i)
            throw new Error(
              "Amplitude Web Experiment Client could not be initialized."
            );
          if (i.webExperiment && !i.webExperiment.isStub) {
            var o = i.webExperiment;
            return o.isRunning && oi(o), o;
          }
          var a = new e(t, r, n);
          return (i.webExperiment = a), a;
        }),
        (e.prototype.getExperimentClient = function () {
          return this.experimentClient;
        }),
        (e.prototype.hideLoadingIndicator = function () {
          Dn();
        }),
        (e.prototype.applyVariants = function (e) {
          var t,
            r,
            n = (e || {}).flagKeys,
            i = this.getVariants();
          if (0 !== Object.keys(i).length) {
            var o = Kn(this.globalScope.location.href);
            for (var a in ((null === (t = this.urlExposureCache) || void 0 === t
              ? void 0
              : t[o]) ||
              ((this.urlExposureCache = {}), (this.urlExposureCache[o] = {})),
            this.fireStoredRedirectImpressions(),
            i))
              if (!((n && !n.includes(a)) || this.previewFlags[a])) {
                var s = i[a],
                  l = s.key || "";
                if (this.appliedMutations[a]) {
                  var u = Object.keys(this.appliedMutations[a]);
                  u.length > 0 &&
                    !u.includes(l) &&
                    (this.revertVariants({ flagKeys: [a] }),
                    delete this.appliedMutations[a]);
                }
                if (
                  "web" ===
                  (null === (r = s.metadata) || void 0 === r
                    ? void 0
                    : r.deliveryMethod)
                ) {
                  var c = Array.isArray(s.payload);
                  if (
                    ("off" === s.key || "control" === s.key) &&
                    (this.isActionActiveOnPage(a, void 0) &&
                      this.exposureWithDedupe(a, s),
                    "off" === s.key)
                  ) {
                    this.revertVariants({ flagKeys: [a] });
                    continue;
                  }
                  c && this.handleVariantAction(a, s);
                }
              }
          }
        }),
        (e.prototype.revertVariants = function (e) {
          var t, r, n, o;
          if (this.appliedMutations) {
            var a = (e || {}).flagKeys;
            a || (a = Object.keys(this.appliedMutations));
            try {
              for (var s = i(a), l = s.next(); !l.done; l = s.next()) {
                var u = l.value,
                  c = this.appliedMutations[u];
                if (c) {
                  for (var d in c) {
                    var f = c[d];
                    if (f)
                      for (var p in f)
                        for (var v in f[p])
                          null ===
                            (o =
                              null === (n = f[p][v]) || void 0 === n
                                ? void 0
                                : n.revert) ||
                            void 0 === o ||
                            o.call(n);
                  }
                  delete this.appliedMutations[u];
                }
              }
            } catch (e) {
              t = { error: e };
            } finally {
              try {
                l && !l.done && (r = s.return) && r.call(s);
              } finally {
                if (t) throw t.error;
              }
            }
          }
        }),
        (e.prototype.previewVariants = function (e) {
          var t = e.keyToVariant;
          if (t)
            for (var r in (this.revertVariants({ flagKeys: Object.keys(t) }),
            t)) {
              var n = t[r],
                i = this.flagVariantMap[r];
              if (!i) return;
              var o = i[n];
              if (!o) return;
              this.isPreviewMode &&
                (this.exposureWithDedupe(r, o, !0),
                Vr({ flags: this.previewFlags }));
              var a = o.payload;
              if (!a || !Array.isArray(a)) return;
              this.handleVariantAction(r, o);
            }
        }),
        (e.prototype.getVariants = function () {
          var e,
            t,
            r = {};
          try {
            for (
              var n = i(
                  a(
                    a([], o(this.localFlagKeys), !1),
                    o(this.remoteFlagKeys),
                    !1
                  )
                ),
                s = n.next();
              !s.done;
              s = n.next()
            ) {
              var l = s.value;
              r[l] = this.experimentClient.variant(l);
            }
          } catch (t) {
            e = { error: t };
          } finally {
            try {
              s && !s.done && (t = n.return) && t.call(n);
            } finally {
              if (e) throw e.error;
            }
          }
          return r;
        }),
        (e.prototype.getActiveExperiments = function () {
          return Object.keys(this.appliedMutations);
        }),
        (e.prototype.getActivePages = function () {
          return this.activePages;
        }),
        (e.prototype.addPageChangeSubscriber = function (e) {
          if (this.subscriptionManager)
            return this.subscriptionManager.addPageChangeSubscriber(e);
        }),
        (e.prototype.setPageObjects = function (e) {
          var t, r;
          this.isVisualEditorMode &&
            ((this.pageObjects = e),
            null === (t = this.subscriptionManager) ||
              void 0 === t ||
              t.setPageObjects(e),
            (this.activePages = {}),
            this.messageBus.unsubscribeAll(),
            null === (r = this.subscriptionManager) ||
              void 0 === r ||
              r.initSubscriptions(),
            this.messageBus.publish("url_change", { updateActivePages: !0 }));
        }),
        (e.prototype.setRedirectHandler = function (e) {
          this.customRedirectHandler = e;
        }),
        (e.prototype.toggleManualPageObject = function (e, t) {
          var r;
          void 0 === t && (t = !0),
            null === (r = this.subscriptionManager) ||
              void 0 === r ||
              r.toggleManualPageObject(e, t);
        }),
        (e.prototype.getDebugState = function () {
          return Hr();
        }),
        (e.prototype.buildFlagDebugInfo = function () {
          var e,
            t,
            r,
            n,
            s,
            l,
            u = {},
            c = this.getVariants(),
            d =
              null !==
                (n =
                  null === (r = this.subscriptionManager) || void 0 === r
                    ? void 0
                    : r.getDebugPageObjects()) && void 0 !== n
                ? n
                : {},
            f =
              this.localFlagKeys.length > 0
                ? this.experimentClient.getEvaluationTraces(this.localFlagKeys)
                : void 0;
          try {
            for (
              var p = i(
                  a(
                    a([], o(this.localFlagKeys), !1),
                    o(this.remoteFlagKeys),
                    !1
                  )
                ),
                v = p.next();
              !v.done;
              v = p.next()
            ) {
              var h = v.value,
                g = c[h],
                m = this.activePages[h],
                y = void 0,
                b = null == f ? void 0 : f[h];
              b
                ? (y = {
                    matched: b.matched,
                    matchedSegment: b.matchedSegment,
                    steps: b.steps,
                  })
                : (null === (s = null == g ? void 0 : g.metadata) ||
                  void 0 === s
                    ? void 0
                    : s.segmentName) &&
                  (y = {
                    matched: !0,
                    matchedSegment: g.metadata.segmentName,
                    steps: [],
                  }),
                (u[h] = {
                  flagKey: h,
                  variant: (null == g ? void 0 : g.key)
                    ? { key: g.key, value: g.value, metadata: g.metadata }
                    : null,
                  isActive: !!m && Object.keys(m).length > 0,
                  audienceEvaluation: y,
                  pageObjects: null !== (l = d[h]) && void 0 !== l ? l : [],
                });
            }
          } catch (t) {
            e = { error: t };
          } finally {
            try {
              v && !v.done && (t = p.return) && t.call(p);
            } finally {
              if (e) throw e.error;
            }
          }
          return u;
        }),
        (e.prototype.addDebugStateSubscriber = function (e) {
          if (this.subscriptionManager)
            return this.subscriptionManager.addDebugStateSubscriber(e);
        }),
        (e.prototype.plugin = function () {
          var e = this;
          return {
            name: "@amplitude/experiment-tag",
            type: "enrichment",
            setup: function () {
              return r(e, void 0, void 0, function () {
                return n(this, function (e) {
                  return [2];
                });
              });
            },
            execute: function (t) {
              return r(e, void 0, void 0, function () {
                return n(this, function (e) {
                  return (
                    this.trackEvent(t.event_type, t.event_properties), [2, t]
                  );
                });
              });
            },
          };
        }),
        (e.prototype.trackEvent = function (e, t) {
          this.messageBus.publish("analytics_event", {
            event: e,
            properties: t || {},
          });
        }),
        (e.prototype.fetchRemoteFlags = function () {
          return r(this, void 0, void 0, function () {
            var e;
            return n(this, function (t) {
              switch (t.label) {
                case 0:
                  return (
                    t.trys.push([0, 2, , 3]),
                    [4, this.experimentClient.doFlags()]
                  );
                case 1:
                  return t.sent(), [3, 3];
                case 2:
                  return (
                    (e = t.sent()),
                    console.warn("Error fetching remote flags:", e),
                    [3, 3]
                  );
                case 3:
                  return [2];
              }
            });
          });
        }),
        (e.prototype.handleVariantAction = function (e, t) {
          var r, n;
          try {
            for (var o = i(t.payload), a = o.next(); !a.done; a = o.next()) {
              var s = a.value;
              "redirect" === s.action
                ? this.handleRedirect(s, e, t)
                : s.action === Hn
                ? this.handleMutate(s, e, t)
                : s.action === Jn && this.handleInject(s, e, t);
            }
          } catch (e) {
            r = { error: e };
          } finally {
            try {
              a && !a.done && (n = o.return) && n.call(o);
            } finally {
              if (r) throw r.error;
            }
          }
        }),
        (e.prototype.handleRedirect = function (e, t, i) {
          var o, a, s;
          if (
            this.isActionActiveOnPage(
              t,
              null ===
                (a =
                  null === (o = null == e ? void 0 : e.data) || void 0 === o
                    ? void 0
                    : o.metadata) || void 0 === a
                ? void 0
                : a.scope
            )
          ) {
            var l = Kn(this.previousUrl || this.globalScope.document.referrer),
              u =
                null === (s = null == e ? void 0 : e.data) || void 0 === s
                  ? void 0
                  : s.url;
            if (Kn(this.globalScope.location.href) !== l) {
              var c = (function (e, t) {
                var r = new URL(e),
                  n = new URL(t),
                  i = new URL(t);
                return (
                  r.searchParams.forEach(function (e, t) {
                    n.searchParams.has(t) || i.searchParams.append(t, e);
                  }),
                  i.toString()
                );
              })(this.globalScope.location.href, u);
              this.globalScope.location.href !== c &&
                (this.storeRedirectImpressions(t, i, u),
                (this.previousUrl = this.globalScope.location.href),
                (function (e) {
                  return r(this, void 0, void 0, function () {
                    var t, r, i, o;
                    return n(this, function (n) {
                      switch (n.label) {
                        case 0:
                          return (
                            (t = new En({ sameSite: "Lax" })),
                            (r = new An()),
                            (i = "AMP_"
                              .concat(wn, "_ORIGINAL_")
                              .concat(e.substring(0, 10))),
                            [4, r.parse()]
                          );
                        case 1:
                          return (o = n.sent()), [4, t.set(i, o)];
                        case 2:
                          return n.sent(), [2];
                      }
                    });
                  });
                })(this.apiKey).then(),
                this.customRedirectHandler
                  ? this.customRedirectHandler(c)
                  : this.globalScope.location.replace(c));
            }
          }
        }),
        (e.prototype.handleMutate = function (e, r, n) {
          var i,
            o,
            a,
            s,
            l,
            u = this,
            c =
              (null === (i = e.data) || void 0 === i ? void 0 : i.mutations) ||
              [],
            d = n.key || "";
          if (0 !== c.length) {
            var f = {};
            c.forEach(function (e, t) {
              var i, o, a, s, l, c, p, v, h, g, m;
              u.isActionActiveOnPage(
                r,
                null === (i = null == e ? void 0 : e.metadata) || void 0 === i
                  ? void 0
                  : i.scope
              )
                ? (u.exposureWithDedupe(r, n),
                  (null ===
                    (m =
                      null ===
                        (g =
                          null === (h = u.appliedMutations[r]) || void 0 === h
                            ? void 0
                            : h[d]) || void 0 === g
                        ? void 0
                        : g[Hn]) || void 0 === m
                    ? void 0
                    : m[t]) || (f[t] = Ir.declarative(e)))
                : (null ===
                    (s =
                      null ===
                        (a =
                          null === (o = u.appliedMutations[r]) || void 0 === o
                            ? void 0
                            : o[d]) || void 0 === a
                        ? void 0
                        : a[Hn]) || void 0 === s
                    ? void 0
                    : s[t]) &&
                  (null ===
                    (v =
                      null ===
                        (p =
                          null ===
                            (c =
                              null === (l = u.appliedMutations[r]) ||
                              void 0 === l
                                ? void 0
                                : l[d]) || void 0 === c
                            ? void 0
                            : c[Hn]) || void 0 === p
                        ? void 0
                        : p[t]) ||
                    void 0 === v ||
                    v.revert(),
                  delete u.appliedMutations[r][d][Hn][t]);
            }),
              (null !== (o = (s = this.appliedMutations)[r]) && void 0 !== o) ||
                (s[r] = {}),
              (null !== (a = (l = this.appliedMutations[r])[d]) &&
                void 0 !== a) ||
                (l[d] = {}),
              (this.appliedMutations[r][d][Hn] = t(
                t({}, this.appliedMutations[r][d][Hn]),
                f
              )),
              0 === Object.keys(this.appliedMutations[r][d][Hn] || {}).length &&
                delete this.appliedMutations[r][d][Hn],
              0 === Object.keys(this.appliedMutations[r][d] || {}).length &&
                delete this.appliedMutations[r];
          }
        }),
        (e.prototype.handleInject = function (e, t, i) {
          var o,
            a,
            s,
            l,
            u,
            c,
            d,
            f,
            p,
            v,
            h,
            g,
            m = this,
            y = i.key || "";
          if (
            this.isActionActiveOnPage(
              t,
              null === (o = null == e ? void 0 : e.data) || void 0 === o
                ? void 0
                : o.scope
            )
          ) {
            var b = e.data.id;
            if (
              b &&
              "string" == typeof b &&
              0 !== b.length &&
              ((b = b.replace(/-/g, "")), !this.appliedInjections.has(b))
            ) {
              var w,
                x = e.data.js;
              x &&
                (w = this.globalScope.document.createElement("script")) &&
                ((w.innerHTML = "function "
                  .concat(b, "(html, utils, id){")
                  .concat(x, "};")),
                (w.id = "js-".concat(b)),
                this.globalScope.document.head.appendChild(w));
              var S,
                k = e.data.css;
              k &&
                (S = this.globalScope.document.createElement("style")) &&
                ((S.innerHTML = k),
                (S.id = "css-".concat(b)),
                this.globalScope.document.head.appendChild(S));
              var E,
                _ = e.data.html;
              _ &&
                (E =
                  null !==
                    (c = new DOMParser().parseFromString(_, "text/html").body
                      .firstElementChild) && void 0 !== c
                    ? c
                    : void 0);
              var O = { cancelled: !1 },
                A = (function (e) {
                  return {
                    waitForElement: function (t) {
                      return r(this, void 0, void 0, function () {
                        var r, i, o;
                        return n(this, function (n) {
                          return (
                            (r = void 0),
                            (o = (i = function () {
                              if (!e.cancelled)
                                return document.querySelector(t);
                              null == r || r.disconnect();
                            })())
                              ? [2, o]
                              : [
                                  2,
                                  new Promise(function (e) {
                                    (r = new MutationObserver(function () {
                                      var t = i();
                                      t && (null == r || r.disconnect(), e(t));
                                    })),
                                      r.observe(document.documentElement, {
                                        childList: !0,
                                        subtree: !0,
                                        attributes: !0,
                                      });
                                  }),
                                ]
                          );
                        });
                      });
                    },
                    insertElement: function (t, r, n) {
                      return new Promise(function (i) {
                        var o = 0,
                          a = void 0,
                          s = function () {
                            if (e.cancelled) null == a || a.disconnect();
                            else if (
                              !(
                                (t.isConnected &&
                                  t.ownerDocument === document) ||
                                o >= 10
                              )
                            ) {
                              o++,
                                setTimeout(function () {
                                  return o--;
                                }, 1e3);
                              var s = document.querySelector(r.parentSelector);
                              if (s) {
                                var l = r.insertBeforeSelector
                                  ? s.querySelector(r.insertBeforeSelector)
                                  : null;
                                (r.insertBeforeSelector && !l) ||
                                  (Er(),
                                  s.insertBefore(t, l),
                                  _r(),
                                  null == n || n(),
                                  i());
                              }
                            }
                          };
                        s(),
                          (a = new MutationObserver(s)).observe(
                            document.documentElement,
                            { childList: !0, subtree: !0, attributes: !0 }
                          );
                      });
                    },
                  };
                })(O);
              this.appliedInjections.add(b);
              try {
                var P = this.globalScope[b];
                P && "function" == typeof P && P(E, A, b);
              } catch (e) {
                null == w || w.remove(),
                  console.error(
                    "Experiment inject failed for "
                      .concat(t, " variant ")
                      .concat(i.key, ". Reason:"),
                    e
                  );
              }
              (null !== (d = (v = this.appliedMutations)[t]) && void 0 !== d) ||
                (v[t] = {}),
                (null !== (f = (h = this.appliedMutations[t])[y]) &&
                  void 0 !== f) ||
                  (h[y] = {}),
                (null !== (p = (g = this.appliedMutations[t][y])[Jn]) &&
                  void 0 !== p) ||
                  (g[Jn] = {}),
                (this.appliedMutations[t][y][Jn][b] = {
                  revert: function () {
                    var e;
                    (O.cancelled = !0),
                      null === (e = A.remove) || void 0 === e || e.call(A),
                      null == S || S.remove(),
                      null == w || w.remove(),
                      m.appliedInjections.delete(b);
                  },
                }),
                this.exposureWithDedupe(t, i);
            }
          } else
            null ===
              (u =
                null ===
                  (l =
                    null ===
                      (s =
                        null === (a = this.appliedMutations[t]) || void 0 === a
                          ? void 0
                          : a[y]) || void 0 === s
                      ? void 0
                      : s[Jn]) || void 0 === l
                  ? void 0
                  : l[0]) ||
              void 0 === u ||
              u.revert();
        }),
        (e.prototype.exposureWithDedupe = function (e, t, r) {
          var n,
            i,
            o,
            a,
            s = Kn(this.globalScope.location.href);
          if (
            !(
              (null ===
                (i =
                  null === (n = this.urlExposureCache) || void 0 === n
                    ? void 0
                    : n[s]) || void 0 === i
                ? void 0
                : i[e]) === t.key
            )
          ) {
            if (r) {
              var l = {
                variant: t,
                source: "local-evaluation",
                hasDefaultVariant: !1,
              };
              this.experimentClient.exposureInternal(e, l);
            } else this.experimentClient.exposure(e);
            (null !== (o = (a = this.urlExposureCache)[s]) && void 0 !== o
              ? o
              : (a[s] = {}))[e] = t.key;
          }
        }),
        (e.prototype.updateActivePages = function (e, t, r) {
          this.activePages[e] || (this.activePages[e] = {}),
            r
              ? (this.activePages[e][t.id] = t)
              : (delete this.activePages[e][t.id],
                0 === Object.keys(this.activePages[e]).length &&
                  delete this.activePages[e]);
        }),
        (e.prototype.isActionActiveOnPage = function (e, t) {
          var r = this.activePages[e];
          return t
            ? t.some(function (e) {
                var t;
                return (
                  null !== (t = null == r ? void 0 : r[e]) && void 0 !== t && t
                );
              })
            : !!r && Object.values(r).some(Boolean);
        }),
        (e.prototype.storeRedirectImpressions = function (e, t, r) {
          var n = "EXP_".concat(this.apiKey.slice(0, 10), "_REDIRECT"),
            i = Pn("sessionStorage", n) || {};
          (i[e] = { redirectUrl: r, variant: t }), Cn("sessionStorage", n, i);
        }),
        (e.prototype.fireStoredRedirectImpressions = function () {
          var e = this,
            t = "EXP_".concat(this.apiKey.slice(0, 10), "_REDIRECT"),
            r = Pn("sessionStorage", t) || {};
          if (Object.keys(r).length > 0)
            for (var n in r) {
              var i = r[n],
                o = i.redirectUrl,
                a = i.variant,
                s = Kn(this.globalScope.location.href),
                l = Kn(o);
              zn([s], l) && (this.exposureWithDedupe(n, a, !0), delete r[n]);
            }
          Object.keys(r).length > 0
            ? this.globalScope.setTimeout(function () {
                var r = Pn("sessionStorage", t) || {};
                for (var n in r) e.exposureWithDedupe(n, r[n].variant, !0);
                Mn("sessionStorage", t);
              }, 500)
            : Mn("sessionStorage", t);
        }),
        (e.prototype.setupPreviewMode = function (e) {
          var t = this;
          if ("true" === e[Gn]) {
            Object.keys(e).forEach(function (r) {
              r !== Gn && e[r] && (t.previewFlags[r] = e[r]);
            }),
              Cn("sessionStorage", Xn, { previewFlags: this.previewFlags });
            var r = a(a([], o(Object.keys(this.previewFlags)), !1), [Gn], !1);
            this.globalScope.history.replaceState(
              {},
              "",
              qn(this.globalScope.location.href, r)
            ),
              Fn.setup();
          } else {
            var n = Pn("sessionStorage", Xn);
            n && (this.previewFlags = n.previewFlags);
          }
          Object.keys(this.previewFlags).length > 0 &&
            (this.isPreviewMode = !0);
        }),
        e
      );
    })();
    var Zn =
        ye.fetch ||
        function (e, t) {
          return (
            (t = t || {}),
            new Promise(function (r, n) {
              var i = new XMLHttpRequest(),
                o = [],
                a = [],
                s = {},
                l = function () {
                  return {
                    ok: 2 == ((i.status / 100) | 0),
                    statusText: i.statusText,
                    status: i.status,
                    url: i.responseURL,
                    text: function () {
                      return Promise.resolve(i.responseText);
                    },
                    json: function () {
                      return Promise.resolve(i.responseText).then(JSON.parse);
                    },
                    blob: function () {
                      return Promise.resolve(new Blob([i.response]));
                    },
                    clone: l,
                    headers: {
                      keys: function () {
                        return o;
                      },
                      entries: function () {
                        return a;
                      },
                      get: function (e) {
                        return s[e.toLowerCase()];
                      },
                      has: function (e) {
                        return e.toLowerCase() in s;
                      },
                    },
                  };
                };
              for (var u in (i.open(t.method || "get", e, !0),
              (i.onload = function () {
                i
                  .getAllResponseHeaders()
                  .replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, function (e, t, r) {
                    o.push((t = t.toLowerCase())),
                      a.push([t, r]),
                      (s[t] = s[t] ? s[t] + "," + r : r);
                  }),
                  r(l());
              }),
              (i.onerror = n),
              (i.withCredentials = "include" == t.credentials),
              t.headers))
                i.setRequestHeader(u, t.headers[u]);
              i.send(t.body || null);
            })
          );
        },
      Yn = {
        request: function (e, t, i, o, a) {
          return r(void 0, void 0, void 0, function () {
            var s;
            return n(this, function (l) {
              return (
                (s = function () {
                  return r(void 0, void 0, void 0, function () {
                    var r, a;
                    return n(this, function (n) {
                      switch (n.label) {
                        case 0:
                          return [4, Zn(e, { method: t, headers: i, body: o })];
                        case 1:
                          return (
                            (r = n.sent()),
                            (a = { status: r.status }),
                            [4, r.text()]
                          );
                        case 2:
                          return [2, ((a.body = n.sent()), a)];
                      }
                    });
                  });
                }),
                [
                  2,
                  ((u = s()),
                  (c = a),
                  !c || c <= 0
                    ? u
                    : Promise.race([
                        u,
                        new Promise(function (e, t) {
                          return setTimeout(function () {
                            return t(new he("Timeout after ".concat(c, "ms")));
                          }, c);
                        }),
                      ])),
                ]
              );
              var u, c;
            });
          });
        },
      },
      ei = (function () {
        function e(e, t, r) {
          (this.deploymentKey = e), (this.serverUrl = t), (this.httpClient = r);
        }
        return (
          (e.prototype.getPreviewFlagsAndPageViewObjects = function () {
            return r(this, void 0, void 0, function () {
              var e, t, r, i;
              return n(this, function (n) {
                switch (n.label) {
                  case 0:
                    return (
                      ((e = {
                        Authorization: "Api-Key ".concat(this.deploymentKey),
                      })["X-Amp-Exp-Library"] = "experiment-tag/".concat(
                        "0.21.0"
                      )),
                      [
                        4,
                        this.httpClient.request(
                          "".concat(this.serverUrl, "/web/v1/configs"),
                          "GET",
                          e,
                          null,
                          1e4
                        ),
                      ]
                    );
                  case 1:
                    if (200 != (t = n.sent()).status)
                      throw Error(
                        "Preview error response: status=".concat(t.status)
                      );
                    return (
                      (r = JSON.parse(t.body).flags),
                      (i = JSON.parse(t.body).pageObjects),
                      [2, { flags: r, pageViewObjects: i }]
                    );
                }
              });
            });
          }),
          e
        );
      })(),
      ti = [],
      ri = function (e, t, r) {
        $n.getInstance(e, t, r)
          .start()
          .finally(function () {
            var e;
            null === (e = document.getElementById("amp-exp-css")) ||
              void 0 === e ||
              e.remove();
          });
      },
      ni = function (e, t) {
        return r(void 0, void 0, void 0, function () {
          return n(this, function (r) {
            return [
              2,
              new ei(
                e,
                "EU" === t
                  ? "https://api.lab.eu.amplitude.com"
                  : "https://api.lab.amplitude.com",
                Yn
              ).getPreviewFlagsAndPageViewObjects(),
            ];
          });
        });
      },
      ii = function () {
        return {
          name: "@amplitude/experiment-tag",
          type: "enrichment",
          execute: function (e) {
            return r(void 0, void 0, void 0, function () {
              var t, r;
              return n(this, function (n) {
                return (
                  (t = be()),
                  (r = null == t ? void 0 : t.webExperiment) &&
                  "function" == typeof r.trackEvent &&
                  r.isRunning
                    ? r.trackEvent(e.event_type, e.event_properties)
                    : ti.push({
                        event_type: e.event_type,
                        event_properties: e.event_properties,
                      }),
                  [2, e]
                );
              });
            });
          },
        };
      },
      oi = function (e) {
        ti.length > 0 &&
          (ti.forEach(function (t) {
            var r = t.event_type,
              n = t.event_properties;
            e.trackEvent(r, n);
          }),
          (ti.length = 0));
      };
    (e.createPlugin = ii),
      (e.flushEventBuffer = oi),
      (e.initialize = function (e, t, r) {
        var n,
          i = be();
        if (!i) throw new Error("Global scope not available");
        i.webExperiment || (i.webExperiment = { plugin: ii, isStub: !0 }),
          (function () {
            if ("true" === Bn()[Gn]) return !0;
            var e = Pn("sessionStorage", Xn);
            return !!(
              (null == e ? void 0 : e.previewFlags) &&
              Object.keys(e.previewFlags).length > 0
            );
          })() ||
          (null === (n = i.WebExperiment) || void 0 === n
            ? void 0
            : n.injectedByExtension)
            ? (an(),
              ni(e, r.serverZone)
                .then(function (t) {
                  var n = JSON.stringify(t.flags),
                    i = JSON.stringify(t.pageViewObjects);
                  ri(e, { initialFlags: n, pageObjects: i }, r);
                })
                .catch(function (n) {
                  console.warn(
                    "Failed to fetch latest configs for preview:",
                    n
                  ),
                    ri(e, t, r);
                })
                .finally(function () {
                  var e;
                  null === (e = document.getElementById("amp-exp-css")) ||
                    void 0 === e ||
                    e.remove();
                }))
            : ri(e, t, r);
      }),
      Object.defineProperty(e, "__esModule", { value: !0 });
  })((this.WebExperiment = this.WebExperiment || {}));
  ("use strict");
  (function (f) {
    (() => {
      try {
        "function" === typeof window.WebExperiment.initialize
          ? (window.WebExperiment.initialize(
              "b2903bdddb544d4b712bee3739f3cafd",
              {
                initialFlags:
                  '[{"key":"demo-page-h1-copy-test","metadata":{"deliveryMethod":"web","deployed":true,"evaluationMode":"local","experimentKey":"exp-1","exposureEvent":"$impression","flagType":"experiment","flagVersion":5,"urlMatch":["https://strapi.io/demo"]},"segments":[{"metadata":{"segmentName":"All Other Users"},"variant":"control"}],"variants":{"control":{"key":"control","value":"control"},"off":{"key":"off","metadata":{"default":true}},"treatment":{"key":"treatment","payload":[{"action":"mutate","data":{"mutations":[{"action":"set","attribute":"html","metadata":{"type":"text"},"selector":".typography_HeroTitle__iMpVM","value":"Experience Strapi - Launch the Demo"}]}}],"value":"treatment"}}},{"key":"test-doc-homepae","metadata":{"deliveryMethod":"web","deployed":true,"evaluationMode":"local","experimentKey":"exp-1","exposureEvent":"$impression","flagType":"experiment","flagVersion":7,"urlMatch":["https://docs.strapi.io/"]},"segments":[{"metadata":{"segmentName":"All Other Users"},"variant":"control"}],"variants":{"control":{"key":"control","value":"control"},"off":{"key":"off","metadata":{"default":true}},"treatment":{"key":"treatment","payload":[{"action":"mutate","data":{"mutations":[{"action":"set","attribute":"html","metadata":{"scope":["c85c2bff-9ff8-40aa-8b68-9cb3c20f57b2"],"type":"text"},"selector":".hero__title_ducK","value":"Strapi 5 Documentation"}]}}],"value":"treatment"}}},{"key":"contact-sales-h1-test","metadata":{"deliveryMethod":"web","deployed":true,"evaluationMode":"local","experimentKey":"exp-1","exposureEvent":"$impression","flagType":"experiment","flagVersion":10,"urlMatch":["https://strapi.io/contact-sales"]},"segments":[{"metadata":{"segmentName":"All Other Users"},"variant":"control"}],"variants":{"control":{"key":"control","value":"control"},"off":{"key":"off","metadata":{"default":true}},"treatment":{"key":"treatment","payload":[{"action":"mutate","data":{"mutations":[{"action":"set","attribute":"html","metadata":{"type":"text"},"selector":".typography_HeroTitle__iMpVM","value":"Scale Faster with Strapi Enterprise"}]}}],"value":"treatment"}}},{"key":"docs-homepage-ai-bot","metadata":{"deliveryMethod":"web","deployed":true,"evaluationMode":"local","experimentKey":"exp-2","exposureEvent":"$impression","flagType":"experiment","flagVersion":8,"urlMatch":["https://docs.strapi.io"]},"segments":[{"metadata":{"segmentName":"All Other Users"},"variant":"control"}],"variants":{"control":{"key":"control","value":"control"},"off":{"key":"off","metadata":{"default":true}},"treatment":{"key":"treatment","payload":[{"action":"mutate","data":{"mutations":[{"action":"set","attribute":"html","metadata":{"type":"text"},"selector":".homepage-ai-button_rVX4","value":"<i class=\\"strapi-icons ph-fill ph-sparkle\\" style=\\"color:inherit\\"></i><p>Ask AI</p>"}]}}],"value":"treatment"}}}]',
                pageObjects:
                  '{"contact-sales-h1-test":{"Default Page View":{"conditions":[[{"op":"regex match","selector":["context","page","url"],"values":["^https:\\\\/\\\\/strapi\\\\.io\\\\/contact-sales\\\\/?(\\\\?.*)?(#.*)?$"]}]],"id":"b8866135-d495-43ac-ae37-b19db9acc9d2","name":"Default Page View","trigger_type":"url_change"}},"demo-page-h1-copy-test":{"Default Page View":{"conditions":[[{"op":"regex match","selector":["context","page","url"],"values":["^https:\\\\/\\\\/strapi\\\\.io\\\\/demo\\\\/?(\\\\?.*)?(#.*)?$"]}]],"id":"6472a328-1a62-4593-8045-2299a91ca438","name":"Default Page View","trigger_type":"url_change"}},"docs-homepage-ai-bot":{"Default Page View":{"conditions":[[{"op":"regex match","selector":["context","page","url"],"values":["^https:\\\\/\\\\/docs\\\\.strapi\\\\.io\\\\/?(\\\\?.*)?(#.*)?$"]}]],"id":"ddb0c7df-d435-46ba-ac26-18913e3237a0","name":"Default Page View","trigger_type":"url_change"}},"test-doc-homepae":{"Default Page View":{"conditions":[[{"op":"regex match","selector":["context","page","url"],"values":["^https:\\\\/\\\\/docs\\\\.strapi\\\\.io\\\\/?(\\\\?.*)?(#.*)?$"]}]],"id":"c85c2bff-9ff8-40aa-8b68-9cb3c20f57b2","name":"Default Page View","trigger_type":"url_change"}}}',
              },
              { serverZone: "US" }
            ),
            "true" === f &&
              ((a, b, c) => {
                let d = 0;
                const e = setInterval(() => {
                  d += b;
                  window.amplitude
                    ? (clearInterval(e), a())
                    : d >= c &&
                      (clearInterval(e),
                      console.warn(
                        "Amplitude SDK not found after " +
                          c +
                          "ms. Plugin not installed."
                      ));
                }, b);
              })(
                () => {
                  "function" === typeof window.webExperiment?.plugin &&
                    window.amplitude.add(window.webExperiment.plugin());
                },
                100,
                1e3
              ))
          : console.error("Web Experiment initialize function not found");
      } catch (a) {
        console.error("Error initializing web experiment:", a);
      }
    })();
  })("true");
} catch (e) {
  console.log(e);
}
try {
  ("use strict");
  (function (c, k) {
    var d = c.amplitude || { _q: [], _iq: {} };
    if (d.invoked)
      c.console &&
        console.error &&
        console.error("Amplitude snippet has been loaded.");
    else {
      var f = function (b, a) {
          b.prototype[a] = function () {
            this._q.push({
              name: a,
              args: Array.prototype.slice.call(arguments, 0),
            });
            return this;
          };
        },
        t = function (b, a, l) {
          return function (m) {
            b._q.push({
              name: a,
              args: Array.prototype.slice.call(l, 0),
              resolve: m,
            });
          };
        },
        n = function (b, a, l) {
          b[a] = function () {
            if (l)
              return {
                promise: new Promise(
                  t(b, a, Array.prototype.slice.call(arguments))
                ),
              };
            var m = Array.prototype.slice.call(arguments);
            b._q.push({ name: a, args: Array.prototype.slice.call(m, 0) });
          };
        },
        r = function (b) {
          for (var a = 0; a < p.length; a++) n(b, p[a], !1);
          for (a = 0; a < q.length; a++) n(b, q[a], !0);
        };
      d.invoked = !0;
      for (
        var g = function () {
            this._q = [];
            return this;
          },
          h =
            "add append clearAll prepend set setOnce unset preInsert postInsert remove getUserProperties".split(
              " "
            ),
          e = 0;
        e < h.length;
        e++
      )
        f(g, h[e]);
      d.Identify = g;
      g = function () {
        this._q = [];
        return this;
      };
      h =
        "getEventProperties setProductId setQuantity setPrice setRevenue setRevenueType setEventProperties".split(
          " "
        );
      for (e = 0; e < h.length; e++) f(g, h[e]);
      d.Revenue = g;
      var p =
          "getDeviceId setDeviceId getSessionId setSessionId getUserId setUserId setOptOut setTransport reset extendSession".split(
            " "
          ),
        q =
          "init add remove track logEvent identify groupIdentify setGroup revenue flush".split(
            " "
          );
      r(d);
      d.createInstance = function (b) {
        d._iq[b] = { _q: [] };
        r(d._iq[b]);
        return d._iq[b];
      };
      c.amplitude = d;
      c.sessionReplay = (function (b) {
        return {
          plugin: function (a) {
            return { _STUBBED_PLUGIN_NAME: b, _conf: a };
          },
        };
      })("sr");
    }
    c = k.createElement("script");
    c.src =
      "https://cdn.amplitude.com/script/b2903bdddb544d4b712bee3739f3cafd.async.js";
    c.async = !0;
    c.type = "text/javascript";
    (f = k.querySelector("[nonce]")) &&
      c.setAttribute("nonce", f.nonce || f.getAttribute("nonce"));
    k.head.appendChild(c);
  })(window, document);
} catch (e) {
  console.log(e);
}
