!(function () {
  "use strict";
  const e = "na1",
    n = { APP: "app", APP_API: "app-api" };
  function t(n, t) {
    const o = t && t.hubletOverride ? t.hubletOverride : n,
      i = t && !0 === t.hubletizeNa1;
    return o !== e || i ? `-${o}` : "";
  }
  function o(e, o, i) {
    if (i && i.hubletPostfixLocation && "domain" === i.hubletPostfixLocation)
      return o;
    o === n.APP_API && (o = n.APP);
    return `${o}${t(e, i)}`;
  }
  function i(e, n, t) {
    return `${r(t)}${a(n, t)}${s(e, t)}`;
  }
  function a(e, n) {
    return "qa" === (n && n.envOverride ? n.envOverride : e) ? "qa" : "";
  }
  function r(e) {
    return e && e.domainOverride ? e.domainOverride : "hubspot";
  }
  function s(e, n) {
    return n && n.hubletPostfixLocation && "domain" === n.hubletPostfixLocation
      ? t(e, n)
      : "";
  }
  function d(e) {
    return e && e.tldOverride ? e.tldOverride : "com";
  }
  function c(e) {
    return e === n.APP_API ? "/api" : "";
  }
  function l(e, n, t, a) {
    return `https://${o(n, e, a)}.${i(n, t, a)}.${d(a)}${c(e)}`;
  }
  const u = "data-hsjs-portal",
    p = "data-hsjs-env",
    f = "data-hsjs-hublet",
    w = { PROD: "prod", QA: "qa" };
  function h(e) {
    if (!e) return null;
    const n = document.querySelectorAll(`script[${e}]`);
    return n.length ? n[0].getAttribute(e) : null;
  }
  function v() {
    return h(p) || w.PROD;
  }
  function m() {
    let e = h(u);
    e = parseInt(e, 10);
    if (!e) throw new Error(`HS Pixel Loader can't identify portalId via ${u}`);
    return e;
  }
  function b() {
    return h(f) || e;
  }
  function g() {
    return "withCredentials" in new XMLHttpRequest();
  }
  function _() {
    return l("api", b(), v(), { domainOverride: "hubapi" }).split(
      "https://"
    )[1];
  }
  function O(e, n) {
    !(function (e, n, t, o, i, a, r) {
      if (!e.fbq) {
        i = e.fbq = function () {
          i.callMethod
            ? i.callMethod.apply(i, arguments)
            : i.queue.push(arguments);
        };
        e._fbq || (e._fbq = i);
        i.push = i;
        i.loaded = !0;
        i.version = "2.0";
        i.queue = [];
        (a = n.createElement(t)).async = !0;
        a.src = o;
        (r = n.getElementsByTagName(t)[0]).parentNode.insertBefore(a, r);
      }
    })(
      window,
      document,
      "script",
      "https://connect.facebook.net/en_US/fbevents.js"
    );
    for (var t = 0; t < e.length; t++) {
      e[t].limitedDataUseEnabled && fbq("dataProcessingOptions", ["LDU"], 0, 0);
      fbq("init", `${e[t].pixelId}`, { external_id: n });
      fbq("set", "agent", "hubspot", `${e[t].pixelId}`);
    }
    fbq("track", "PageView");
  }
  function P(e) {
    const n = document.createElement("script");
    n.async = !0;
    n.src = `https://www.googletagmanager.com/gtag/js?id=AW-${e}`;
    document.head.appendChild(n);
  }
  function y(e) {
    window.dataLayer = window.dataLayer || [];
    var n = "qa" === v() ? "dZWU5Zm" : "dZTQ1Zm";
    function t() {
      dataLayer.push(arguments);
    }
    t("js", new Date());
    t("set", "developer_id." + n, !0);
    for (var o = 0; o < e.length; o++) t("config", `AW-${e[o].pixelId}`);
  }
  function E(e) {
    for (var n = 0; n < e.length; n++) {
      const t = e[n].pixelId;
      window._linkedin_data_partner_ids =
        window._linkedin_data_partner_ids || [];
      window._linkedin_data_partner_ids.push(t);
    }
    !(function () {
      var e = document.getElementsByTagName("script")[0],
        n = document.createElement("script");
      n.type = "text/javascript";
      n.async = !0;
      n.src = "https://snap.licdn.com/li.lms-analytics/insight.min.js";
      e.parentNode.insertBefore(n, e);
    })();
  }
  function A(e) {
    !(function (n, t, o) {
      n.TiktokAnalyticsObject = o;
      var i = (n[o] = n[o] || []);
      (i.methods = [
        "page",
        "track",
        "identify",
        "instances",
        "debug",
        "on",
        "off",
        "once",
        "ready",
        "alias",
        "group",
        "enableCookie",
        "disableCookie",
        "holdConsent",
        "revokeConsent",
        "grantConsent",
      ]),
        (i.setAndDefer = function (e, n) {
          e[n] = function () {
            e.push([n].concat(Array.prototype.slice.call(arguments, 0)));
          };
        });
      for (var a = 0; a < i.methods.length; a++) i.setAndDefer(i, i.methods[a]);
      (i.instance = function (e) {
        for (var n = i._i[e] || [], t = 0; t < i.methods.length; t++)
          i.setAndDefer(n, i.methods[t]);
        return n;
      }),
        (i.load = function (e, n) {
          var t = "https://analytics.tiktok.com/i18n/pixel/events.js";
          n && n.partner;
          (i._i = i._i || {}),
            (i._i[e] = []),
            (i._i[e]._u = t),
            (i._t = i._t || {}),
            (i._t[e] = +new Date()),
            (i._o = i._o || {}),
            (i._o[e] = n || {});
          ((n = document.createElement("script")).type = "text/javascript"),
            (n.async = !0),
            (n.src = t + "?sdkid=" + e + "&lib=" + o);
          (e =
            document.getElementsByTagName("script")[0]).parentNode.insertBefore(
            n,
            e
          );
        });
      for (var r = 0; r < e.length; r++) i.load(e[r].pixelInitializer);
      i.page();
      window.ttq = i;
    })(window, document, "ttq");
  }
  function I(e, n) {
    for (var t in e)
      if (e.hasOwnProperty(t) && e[t].length > 0) {
        var o = e[t];
        switch (t) {
          case "FACEBOOK":
            if (n && !e.loadedFbPixel) {
              O(o, n);
              e.loadedFbPixel = !0;
            }
            break;
          case "ADWORDS":
            P(o[0].pixelId);
            y(o);
            break;
          case "LINKEDIN":
            E(o);
            break;
          case "TIKTOK":
            A(o);
        }
      }
  }
  function q(e, n) {
    for (var t in e)
      if (e.hasOwnProperty(t) && e[t].length > 0 && "FACEBOOK" === t)
        if (!e.loadedFbPixel) {
          O(e[t], n);
          e.loadedFbPixel = !0;
        }
  }
  function S(e, n) {
    for (var t in e)
      if (e.hasOwnProperty(t) && e[t].length > 0)
        switch (t) {
          case "FACEBOOK":
            fbq("consent", "grant");
            break;
          case "ADWORDS":
            dataLayer.push("consent", "update", {
              ad_storage: "granted",
              analytics_storage: "granted",
            });
            break;
          case "TIKTOK":
            window.ttq && ttq.grantConsent();
        }
  }
  function k(e) {
    if (e.hasOwnProperty("LINKEDIN")) window.location.reload();
    else
      for (var n in e)
        if (e.hasOwnProperty(n) && e[n].length > 0)
          switch (n) {
            case "FACEBOOK":
              fbq("consent", "revoke");
              break;
            case "ADWORDS":
              dataLayer.push("consent", "update", {
                ad_storage: "denied",
                analytics_storage: "denied",
              });
              break;
            case "TIKTOK":
              window.ttq && ttq.revokeConsent();
          }
  }
  const L = function (e) {
      return `https://${e}?portalId=${m()}`;
    },
    $ = function (e, n) {
      const t = new XMLHttpRequest();
      t.addEventListener("load", () => {
        const e = JSON.parse(t.responseText);
        n(e);
      });
      t.open("GET", L(e));
      t.send();
    },
    x = (e) => `hubspotJsonpCallbackName${e}`,
    C = function (e, n) {
      return `https://${e}?${[`portalId=${m()}`, `callback=${n}`].join("&")}`;
    },
    D = function (e, n, t) {
      const o = document.createElement("script"),
        i = x(t);
      window[i] = function (e) {
        n(e);
        document.body.removeChild(o);
        delete window[i];
      };
      o.src = C(e, i);
      document.body.appendChild(o);
    };
  function j({ jsonUrl: e, jsonpUrl: n }, t, o) {
    if (!e && !n) throw new Error("Missing jsonUrl and jsonpUrl args");
    g() ? $(e, t) : D(n, t, o);
  }
  const F = ["fbclid", "li_fat_id", "gclid", "ttclid"],
    N = /javascript\s*:/i;
  function K() {
    const e = new URL(window.location.href);
    let n = !1;
    F.forEach((t) => {
      const o = e.searchParams.get(t);
      if (null !== o && N.test(o)) {
        e.searchParams.delete(t);
        console.warn(`HubSpot removed the malicious ${t} parameter`);
        n = !0;
      }
    });
    n &&
      window.history &&
      window.history.replaceState &&
      window.history.replaceState(null, "", e.toString());
  }
  const R = (e) =>
      e
        .split("_")
        .map((e) => e.charAt(0).toUpperCase() + e.slice(1).toLowerCase())
        .join(""),
    T = function () {
      K();
      const e = _();
      let n,
        t = null,
        o = null;
      window.enabledEventSettings = { FACEBOOK: [], ADWORDS: [] };
      if (
        !(
          window.disabledHsPopups && window.disabledHsPopups.indexOf("ADS") > -1
        )
      ) {
        window._hsp = window._hsp || [];
        window._hsp.push([
          "addPrivacyConsentListener",
          function (n) {
            n.categories.advertisement
              ? t
                ? S(t, o)
                : j(
                    {
                      jsonUrl: `${e}/hs-script-loader-public/v2/config/pixels-and-events/json`,
                      jsonpUrl: `${e}/hs-script-loader-public/v2/config/pixels-and-events/jsonp`,
                    },
                    (e) => {
                      t = e.pixels;
                      I(e.pixels, o);
                      window.enabledEventSettings =
                        e.enhancedConversionEventSettings;
                    },
                    "addPixels"
                  )
              : t && k(t);
          },
        ]);
        window._hsq = window._hsq || [];
        window._hsq.push([
          "addUserTokenListener",
          function (e) {
            o = e;
            t && q(t, o);
          },
        ]);
        window.addEventListener("hs-form-event:on-submission:success", (e) => {
          const n = HubSpotFormsV4.getFormFromEvent(e);
          r({ conversionId: n.getConversionId(), formGuid: n.getFormId() });
        });
        window.addEventListener(
          "message",
          (e) => {
            e.data &&
              "hsFormCallback" === e.data.type &&
              "onFormSubmitted" === e.data.eventName &&
              r(e.data.data);
          },
          !1
        );
      }
      function i(e, n) {
        if (void 0 === window.fbq) return;
        const { hubSpotFormId: t, eventCategory: o } = e,
          { conversionId: i, formGuid: a } = n;
        if (a === t) {
          const e = R(o);
          window.fbq("track", e, {}, { eventID: i });
        }
      }
      function a(e, t) {
        const { hubSpotFormId: o, pixelId: i, conversionLabel: a } = e,
          { conversionId: r, formGuid: s } = t;
        n = function () {
          window.dataLayer.push(arguments);
        };
        s === o &&
          null !== a &&
          n("event", "conversion", {
            send_to: `AW-${i}/${a}`,
            transaction_id: r,
          });
      }
      function r(e) {
        window.enabledEventSettings.FACEBOOK &&
          window.enabledEventSettings.FACEBOOK.forEach((n) => {
            i(n, e);
          });
        window.enabledEventSettings.ADWORDS &&
          window.enabledEventSettings.ADWORDS.forEach((n) => {
            a(n, e);
          });
      }
    };
  window.PIXELS_RAN = window.PIXELS_RAN || !1;
  if (!window.PIXELS_RAN) {
    window.PIXELS_RAN = !0;
    T();
  }
})();
//# sourceMappingURL=//static.hsappstatic.net/adsscriptloaderstatic/static-1.3031/bundles/pixels-release.js.map
