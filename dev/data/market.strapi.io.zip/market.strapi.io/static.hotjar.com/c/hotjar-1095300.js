window.hjSiteSettings = window.hjSiteSettings || {
  site_id: 1095300,
  rec_value: 2.0000000006820118e-9,
  state_change_listen_mode: "automatic",
  record: true,
  continuous_capture_enabled: true,
  recording_capture_keystrokes: true,
  session_capture_console_consent: true,
  anonymize_digits: true,
  anonymize_emails: true,
  suppress_all: false,
  suppress_all_on_specific_pages: [],
  suppress_text: false,
  suppress_location: false,
  user_attributes_enabled: false,
  legal_name: null,
  privacy_policy_url: null,
  deferred_page_contents: [],
  record_targeting_rules: [],
  heatmaps: [],
  polls: [],
  integrations: {
    google_analytics: { tag_sessions: true, send_hotjar_id: true },
    optimizely: { tag_recordings: false },
    abtasty: { tag_recordings: false },
    kissmetrics: { send_user_id: false },
    mixpanel: { send_events: false },
    unbounce: { tag_recordings: false },
    hubspot: { enabled: true, send_recordings: true, send_surveys: true },
  },
  features: [
    "ask.popover_redesign",
    "client_script.compression.pc",
    "csq_theme",
    "error_reporting",
    "feedback.embeddable_widget",
    "feedback.widgetV2",
    "feedback.widget_telemetry",
    "settings.billing_v2",
    "survey.embeddable_widget",
    "survey.image_question",
    "survey.screenshots",
    "survey.type_button",
    "tcvs_v2",
  ],
  tracking_code_verified: true,
  cs_project_id: null,
  cs_tag_name: null,
  account_id: 693441,
  account_signature:
    "4e087625d0e13a8d4bc5da70b6e1f56df96d52d051258fb6203b0f27bf902f29",
};

!(function () {
  "use strict";
  function e(t) {
    return (
      (e =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e &&
                "function" == typeof Symbol &&
                e.constructor === Symbol &&
                e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            }),
      e(t)
    );
  }
  function t(e, t) {
    for (var r = 0; r < t.length; r++) {
      var i = t[r];
      (i.enumerable = i.enumerable || !1),
        (i.configurable = !0),
        "value" in i && (i.writable = !0),
        Object.defineProperty(e, n(i.key), i);
    }
  }
  function n(t) {
    var n = (function (t, n) {
      if ("object" != e(t) || !t) return t;
      var r = t[Symbol.toPrimitive];
      if (void 0 !== r) {
        var i = r.call(t, "string");
        if ("object" != e(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return String(t);
    })(t);
    return "symbol" == e(n) ? n : String(n);
  }
  var r,
    i = (function () {
      function e(t) {
        var n =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10,
          r =
            arguments.length > 2 && void 0 !== arguments[2]
              ? arguments[2]
              : 1e3;
        !(function (e, t) {
          if (!(e instanceof t))
            throw new TypeError("Cannot call a class as a function");
        })(this, e),
          (this.send = t),
          (this.batchSize = n),
          (this.flushInterval = r),
          (this.buffer = []),
          (this.flushTimer = null);
      }
      var n, r;
      return (
        (n = e),
        (r = [
          {
            key: "getBuffer",
            value: function () {
              return this.buffer;
            },
          },
          {
            key: "add",
            value: function (e) {
              var t = this;
              this.buffer.push(e),
                this.buffer.length >= this.batchSize
                  ? this.flush()
                  : this.flushTimer ||
                    (this.flushTimer = setTimeout(function () {
                      t.flush();
                    }, this.flushInterval));
            },
          },
          {
            key: "flush",
            value: function () {
              this.buffer.length > 0 &&
                (this.send(this.buffer), (this.buffer = [])),
                this.flushTimer &&
                  (clearTimeout(this.flushTimer), (this.flushTimer = null));
            },
          },
        ]) && t(n.prototype, r),
        Object.defineProperty(n, "prototype", { writable: !1 }),
        e
      );
    })();
  function a() {
    return (
      (a = Object.assign
        ? Object.assign.bind()
        : function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var r in n)
                Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
            }
            return e;
          }),
      a.apply(this, arguments)
    );
  }
  var o,
    s = function () {
      try {
        return "performance" in window && "now" in window.performance;
      } catch (e) {
        return !1;
      }
    },
    u = {
      version: 6,
      metricsUrl:
        (null === (r = window._hjSettings) || void 0 === r
          ? void 0
          : r.metricsUrl) || "https://metrics.hotjar.io",
      sampling: {
        metrics: 0.1,
        fieldMetrics: 0.01,
        debug: 0.5,
        universalDebug: 0.05 * 0.1,
      },
      browser: { hasPerformance: !1, shouldLogMetrics: !1, inLab: !1 },
      buffer: { bufferSize: 40, flushInterval: 3e3 },
    },
    c = {
      isDebugEnabled: !1,
      isMetricsEnabled: !1,
      isFieldMetricsEnabled: !1,
      loggedMetrics: {},
      genericTags: {},
    },
    l = function (e, t, n) {
      var r;
      c.loggedMetrics[e] = a(
        a({}, c.loggedMetrics[e]),
        {},
        (((r = {})[t] = n || {}), r)
      );
    },
    d = function (e) {
      if (!e) return "value";
      var t = Object.keys(e)[0];
      return (t && e[t]) || "value";
    },
    g = function (e) {
      var t,
        n = null !== (t = e.tag) && void 0 !== t ? t : void 0;
      return c.isDebugEnabled ? a(a(a({}, n), e.extraTags), c.genericTags) : n;
    },
    f = function (e, t) {
      if (!o) return !1;
      var n = c.isMetricsEnabled || c.isDebugEnabled;
      return (
        "lab" === e && (n = u.browser.inLab),
        "field" === e && (n = c.isFieldMetricsEnabled),
        t ? n && t.flush : n
      );
    },
    h = function (e) {
      var t = !1,
        n = "v=".concat(u.version),
        r =
          ""
            .concat(u.metricsUrl, "?")
            .concat(n, "&site_id=")
            .concat(window.hjSiteSettings.site_id) +
          (c.isDebugEnabled ? "&debug=true" : ""),
        i = JSON.stringify(e);
      if ("sendBeacon" in navigator)
        try {
          t = navigator.sendBeacon.bind(navigator)(r, i);
        } catch (e) {}
      if (!1 === t)
        try {
          var a = new XMLHttpRequest();
          a.open("POST", r), (a.timeout = 1e4), a.send(i);
        } catch (e) {}
      u.browser.shouldLogMetrics && console.debug("New Metrics: ", e);
    },
    p = {
      getConfig: function (e) {
        return u[e];
      },
      getState: function (e) {
        return c[e];
      },
      start: function () {
        try {
          u.browser = {
            hasPerformance: s(),
            shouldLogMetrics: /hjMetrics=1/.test(location.search),
            inLab: /hjLab=true/.test(location.search),
          };
          var e = p.time(),
            t = window.hjSiteSettings || {},
            n = t.features,
            r = t.site_id,
            a = new Set(n),
            l = u.sampling;
          return (
            (c.genericTags = { site_id: r }),
            (c.isDebugEnabled =
              Math.random() <= l.universalDebug ||
              (a.has("client_script.metrics.debug") &&
                Math.random() <= l.debug)),
            (c.isMetricsEnabled = Math.random() <= l.metrics),
            (c.isFieldMetricsEnabled =
              c.isMetricsEnabled && Math.random() <= l.fieldMetrics),
            (o = new i(h, u.buffer.bufferSize, u.buffer.flushInterval)),
            e
          );
        } catch (e) {
          console.debug("Error in metrics.start", { error: e });
        }
      },
      reset: function () {
        c.loggedMetrics = {};
      },
      stop: function () {
        (c.isDebugEnabled = !1),
          (c.isMetricsEnabled = !1),
          (c.genericTags = {});
      },
      count: function (e, t) {
        var n = t.incr,
          r = t.tag,
          i = t.extraTags,
          s = t.type;
        try {
          var u,
            l = d(r),
            h = c.loggedMetrics[e],
            p = 0;
          if (
            (n
              ? ((p = ((h && h[l]) || 0) + (n.value || 1)),
                (c.loggedMetrics[e] = a(
                  a({}, h),
                  {},
                  (((u = {})[l] = null != n && n.flush ? 0 : p), u)
                )))
              : (p = 1),
            f(s, n))
          ) {
            var v = {
              name: e,
              type: "count",
              value: p,
              tags: g({ tag: r, extraTags: i }),
            };
            o.add(v);
          }
        } catch (e) {}
      },
      distr: function (e, t) {
        var n = t.task,
          r = t.value,
          i = t.extraTags;
        f() &&
          o.add({
            name: e,
            type: "distribution",
            value: r,
            tags: g({ tag: { task: n }, extraTags: i }),
          });
      },
      time: function () {
        try {
          if (!u.browser.hasPerformance) return;
          return performance.now();
        } catch (e) {}
      },
      timeEnd: function (e, t) {
        var n = t.tag,
          r = t.start,
          i = t.total,
          a = t.extraTags,
          s = t.type;
        try {
          var u = p.time();
          if (!i && !u) return;
          var c = d(n),
            h = i || (r && u ? u - r : void 0);
          if ((l(e, c, {}), h && h > 0 && f(s))) {
            var v = {
              name: e,
              type: "distribution",
              value: Math.round(h),
              tags: g({ tag: n, extraTags: a }),
            };
            o.add(v);
          }
          return u;
        } catch (t) {
          console.debug("Failed to send timer metric: ", {
            name: e,
            tag: n,
            error: t,
          });
        }
      },
      timeIncr: function (e, t) {
        var n,
          r,
          i,
          a,
          o = t.tag,
          s = t.start,
          u = t.flush,
          g = t.extraTags,
          f = t.type,
          h = hj.metrics.time(),
          v = s && h ? h - s : void 0,
          m =
            ((n = e),
            {
              tagName: (r = d(o)),
              start: (a = ((i = c.loggedMetrics[n]) && i[r]) || {}).start,
              total: a.total,
            }),
          w = v ? v + (m.total || 0) : m.total;
        return (
          l(e, m.tagName, { total: w }),
          u && p.timeEnd(e, { tag: o, total: w, extraTags: g, type: f }),
          w
        );
      },
      timeWatcher: function () {
        var e,
          t = 0,
          n = !1,
          r = function () {
            var n,
              r = p.time();
            return (
              (t += null !== (n = e && r && r - e) && void 0 !== n ? n : 0),
              (e = p.time()),
              t
            );
          };
        return {
          start: function () {
            if (!n) return (n = !0), (e = p.time());
          },
          incr: r,
          end: function () {
            var n = r();
            return (t = 0), (e = void 0), n;
          },
        };
      },
      getErrorMessage: function (e) {
        return e instanceof Error ? e.message : "string" == typeof e ? e : "";
      },
    },
    v = (function (e) {
      return (
        (e.replayRecordingMaskedUrlRegex = "replayRecordingMaskedUrlRegex"),
        (e.replayRecordingMaskedUrlRegexRules =
          "replayRecordingMaskedUrlRegexRules"),
        e
      );
    })({}),
    m = (function (e) {
      return (
        (e.START = "start"),
        (e.NOT_START = "not-start"),
        (e.END = "end"),
        (e.NOT_END = "not-end"),
        (e.CONTAIN = "contain"),
        (e.NOT_CONTAIN = "not-contain"),
        (e.EXACT = "exact"),
        (e.NOT_EXACT = "not-exact"),
        e
      );
    })({});
  function w() {
    return (
      (w = Object.assign
        ? Object.assign.bind()
        : function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var r in n)
                Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
            }
            return e;
          }),
      w.apply(this, arguments)
    );
  }
  var b = "https://voc.hotjar.com",
    y = [
      b,
      "https://voc.ew1-integration-1.hotjarians.net",
      "https://hj-engage-unmoderated-review.s3.eu-west-1.amazonaws.com",
    ],
    j = "hj-uut",
    _ = {
      get: function () {
        var e = window.sessionStorage.getItem(j);
        return e ? JSON.parse(e) : null;
      },
      getValue: function (e) {
        var t = _.get();
        return null == t ? void 0 : t[e];
      },
      set: function (e) {
        if (e) {
          var t,
            n = null !== (t = _.get()) && void 0 !== t ? t : {};
          window.sessionStorage.setItem(j, JSON.stringify(w(w({}, n), e)));
        }
      },
      clear: function () {
        window.sessionStorage.removeItem(j);
      },
      validDomains: y,
    },
    S = function (e) {
      var t = new URLSearchParams(e);
      return (
        !!t.has("project_uuid") ||
        ("1" === t.get("is_preview")
          ? t.has("task_uuid")
          : t.has("response_uuid") &&
            t.has("task_uuid") &&
            t.has("participation_uuid"))
      );
    },
    T = function () {
      var e,
        t =
          null !==
            (e = (function () {
              var e = document.referrer;
              if (
                "string" == typeof e &&
                (function (e) {
                  if ("string" != typeof e) return !1;
                  try {
                    var t = new URL(e),
                      n = "1" === t.searchParams.get("is_preview");
                    return (
                      !!y.some(function (t) {
                        return null == e ? void 0 : e.includes(t);
                      }) ||
                      (!!n &&
                        t.hostname.endsWith(".hotjar.com") &&
                        t.pathname.includes("research/projects/tests"))
                    );
                  } catch (e) {
                    return !1;
                  }
                })(e) &&
                S(new URL(e).search)
              )
                return e;
            })()) && void 0 !== e
            ? e
            : (function () {
                var e = new URLSearchParams(window.location.search).get(
                  "hj_uut"
                );
                if (
                  y.some(function (e) {
                    var t;
                    return null === (t = document.referrer) || void 0 === t
                      ? void 0
                      : t.includes(e);
                  }) &&
                  e
                ) {
                  var t = window.atob(e);
                  if (S(t)) {
                    var n = new URL(b);
                    return (n.search = t), n.toString();
                  }
                }
              })(),
        n = void 0 !== t,
        r = null !== _.get();
      return n && _.set({ referrer: t }), r || n;
    };
  function R(e, t, n) {
    if (t && !Array.isArray(t) && "number" == typeof t.length) {
      var r = t.length;
      return M(t, void 0 !== n && n < r ? n : r);
    }
    return e(t, n);
  }
  function E(e) {
    return (
      (function (e) {
        if (Array.isArray(e)) return M(e);
      })(e) ||
      (function (e) {
        if (
          ("undefined" != typeof Symbol && null != e[Symbol.iterator]) ||
          null != e["@@iterator"]
        )
          return Array.from(e);
      })(e) ||
      (function (e, t) {
        if (e) {
          if ("string" == typeof e) return M(e, t);
          var n = Object.prototype.toString.call(e).slice(8, -1);
          return (
            "Object" === n && e.constructor && (n = e.constructor.name),
            "Map" === n || "Set" === n
              ? Array.from(e)
              : "Arguments" === n ||
                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
              ? M(e, t)
              : void 0
          );
        }
      })(e) ||
      (function () {
        throw new TypeError(
          "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      })()
    );
  }
  function M(e, t) {
    (null == t || t > e.length) && (t = e.length);
    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
    return r;
  }
  var O,
    x = function () {
      var e,
        t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        n = null === (e = _hjSettings) || void 0 === e ? void 0 : e.environment,
        r = "t.contentsquare.net";
      n && "live" !== n && (r = "t-staging.contentsquare.net");
      var i = t.isCSQLite ? "smb/tag" : hjSiteSettings.cs_tag_name;
      if (i) {
        var a = document.createElement("script");
        (a.type = "text/javascript"),
          (a.async = !0),
          (a.src = "//".concat(r, "/uxa/").concat(i, ".js")),
          document.getElementsByTagName("head")[0].appendChild(a);
      }
    };
  function C() {
    var e, t, n;
    (window.hj =
      window.hj ||
      function () {
        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
          t[n] = arguments[n];
        (window.hj.q = window.hj.q || []).push(t);
      }),
      (window.hj.metrics = p),
      hj.metrics.start();
    var r,
      i,
      a,
      o,
      s,
      u,
      c,
      l,
      d,
      g,
      f,
      h,
      w = !(
        !window.CS_CONF ||
        null === (e = window.CS_CONF.voc) ||
        void 0 === e ||
        !e.enabled
      ),
      b = !(
        window.CS_CONF ||
        null === (t = window.hjSiteSettings) ||
        void 0 === t ||
        null === (n = t.features) ||
        void 0 === n ||
        !n.includes("cs_lite")
      );
    if (w && window._uxa)
      window._uxa.push(["start:hotjar", hjSiteSettings]),
        (window.hj.scriptLoaded = !0);
    else if (b) {
      var y =
          ((u =
            (r = hjSiteSettings).suppress_all ||
            r.suppress_text ||
            (null === (i = r.suppress_all_on_specific_pages) || void 0 === i
              ? void 0
              : i.length)),
          (c = (function (e) {
            var t,
              n,
              r,
              i,
              a,
              o = {
                anonymisationMethod: null,
                replayRecordingMaskedUrlRegex: null,
                replayRecordingMaskedUrlRegexRules: null,
              };
            if (
              ((e.suppress_all || e.suppress_text) &&
                ((o.anonymisationMethod = v.replayRecordingMaskedUrlRegex),
                (o.replayRecordingMaskedUrlRegex = ".*")),
              null !== (t = e.suppress_all_on_specific_pages) &&
                void 0 !== t &&
                t.length)
            ) {
              o.anonymisationMethod = v.replayRecordingMaskedUrlRegexRules;
              var s =
                ((n = e.suppress_all_on_specific_pages),
                (r = {
                  contains: m.CONTAIN,
                  regex: m.CONTAIN,
                  simple: m.CONTAIN,
                  ends_with: m.END,
                  exact: m.EXACT,
                  starts_with: m.START,
                }),
                (i = []),
                (a = Object.keys(r)),
                n.forEach(function (e) {
                  if (e.pattern && a.includes(e.match_operation)) {
                    var t = {
                      operator: r[e.match_operation],
                      value: e.pattern,
                      ignoreQueryParams: "simple" === e.match_operation,
                      ignoreURIFragments: "simple" === e.match_operation,
                      ignoreCaseSensitivity: "simple" === e.match_operation,
                      notOperator: e.negate,
                    };
                    i.push(t);
                  }
                }),
                i.length ? i : void 0);
              o.replayRecordingMaskedUrlRegexRules = s || null;
            }
            return o;
          })(r)),
          (l = c.anonymisationMethod),
          (d = c.replayRecordingMaskedUrlRegex),
          (g = c.replayRecordingMaskedUrlRegexRules),
          (f = !(
            null === (a = _hjSettings) ||
            void 0 === a ||
            !a.environment ||
            "live" === _hjSettings.environment
          )),
          {
            CS_CONF_BASE: {
              projectId: r.cs_project_id,
              smbConfig: {
                siteId: r.site_id,
                record: !!hjSiteSettings.record,
                useCSTC: !0,
                useSentry: !0,
                csLiteDomain: f
                  ? "insights-integration.live.eks.hotjar.com"
                  : "insights.hotjar.com",
              },
              hostnames: [window.location.hostname],
              voc:
                (null !== (o = r.polls) && void 0 !== o && o.length) || T()
                  ? { enabled: 1, siteId: r.site_id }
                  : { enabled: 0 },
              whitelistedAttributes: [],
              anonymizeDigits: !!u || r.anonymize_digits,
              implementations:
                ((s = r),
                R(
                  E,
                  ((h = s.state_change_listen_mode),
                  "manual" === h
                    ? []
                    : [
                        {
                          template: { name: "ArtificialPageview", args: {} },
                          triggers: [
                            {
                              name: "HistoryChange",
                              args: {
                                listeners:
                                  "popstate, pushState, replaceState" +
                                  ("automatic_with_fragments" === h
                                    ? ", hashchange"
                                    : ""),
                                useDebounce: "no",
                                window: 400,
                              },
                            },
                          ],
                        },
                      ])
                )),
              recordTargetingRules: R(E, r.record_targeting_rules),
              anonymisationMethod: l,
              replayRecordingMaskedUrlRegex: d,
              replayRecordingMaskedUrlRegexRules: g,
            },
            PII_SELECTORS: r.suppress_all
              ? ["picture, img, video, audio"]
              : null,
          }),
        j = y.CS_CONF_BASE,
        _ = y.PII_SELECTORS;
      (window.CS_CONF_BASE = j),
        (window._uxa = window._uxa || []),
        _ && window._uxa.push(["setPIISelectors", { PIISelectors: _ }]),
        x({ isCSQLite: b });
    } else
      (window.hjBootstrap =
        window.hjBootstrap ||
        function (e, t, n) {
          var r,
            i,
            a = new RegExp(
              "bot|google|headless|baidu|bing|msn|duckduckbot|teoma|slurp|yandex|phantomjs|pingdom|ahrefsbot|facebook",
              "i"
            ),
            o =
              (null === (r = window.navigator) || void 0 === r
                ? void 0
                : r.userAgent) || "unknown";
          if (a.test(o))
            return (
              hj.metrics.count("session-rejection", { tag: { reason: "bot" } }),
              void console.warn(
                "Hotjar not launching due to suspicious userAgent:",
                o
              )
            );
          var s = "http:" === window.location.protocol,
            u = Boolean(
              null === (i = _hjSettings) || void 0 === i ? void 0 : i.preview
            );
          if (s && !u)
            return (
              hj.metrics.count("session-rejection", {
                tag: { reason: "https" },
              }),
              void console.warn(
                "For security reasons, Hotjar only works over HTTPS. Learn more: https://help.hotjar.com/hc/en-us/articles/115011624047"
              )
            );
          (window.hjBootstrap = function (e, t, n) {
            var r;
            (window.hjBootstrapCalled = (window.hjBootstrapCalled || []).concat(
              n
            )),
              window.hj &&
                window.hj._init &&
                (null === (r = hj._init) ||
                  void 0 === r ||
                  r._verifyInstallation());
          }),
            window.hjBootstrap(e, t, n),
            (window.hjBootstrap.revision = "dc32d21");
          var c = window.document,
            l = c.head || c.getElementsByTagName("head")[0];
          hj.scriptDomain = e;
          var d = c.createElement("script");
          (d.async = !0),
            (d.src = hj.scriptDomain + t),
            (d.charset = "utf-8"),
            l.appendChild(d);
        }),
        window.hjBootstrap(
          "https://script.hotjar.com/",
          "modules.6a0f3932cb1341a35c18.js",
          "1095300"
        );
  }
  window.hjLazyModules = window.hjLazyModules || {
    SURVEY_V2: { js: "survey-v2.8b9993fd273bc1f4ea37.js" },
    SURVEY_BOOTSTRAPPER: { js: "survey-bootstrapper.31d6cfe0d16ae931b73c.js" },
    SURVEY_ISOLATED: { js: "survey-isolated.31d6cfe0d16ae931b73c.js" },
    HEATMAP_RETAKER: { js: "heatmap-retaker.f79c0c7bb13d8a14bddc.js" },
    SURVEY_INVITATION: { js: "survey-invitation.1640ce990a427ef8d192.js" },
    NOTIFICATION: { js: "notification.ed2bca043f1d9f8c6b56.js" },
    SENTRY: { js: "sentry.58c81e3e25532810f6fd.js" },
    BROWSER_PERF: { js: "browser-perf.8417c6bba72228fa2e29.js" },
    USER_TEST: { js: "user-test.be884c260517a4fecb41.js" },
  };
  var I = null !== (O = hjSiteSettings.features) && void 0 !== O ? O : [];
  I.indexOf("one_app_tag") > -1
    ? x()
    : I.indexOf("one_app_tag_dc") > -1
    ? (x(),
      window.addEventListener("csq:start-hotjar", function () {
        C();
      }))
    : C();
})();
!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof self
          ? self
          : {},
      n = new Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "e6136707-dd23-50c7-aeff-8472f972b085"));
  } catch (e) {}
})();
//# debugId=e6136707-dd23-50c7-aeff-8472f972b085
